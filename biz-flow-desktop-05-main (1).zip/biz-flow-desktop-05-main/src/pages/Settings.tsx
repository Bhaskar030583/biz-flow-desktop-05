
import React from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { useSettings, CurrencyType, TimeFormat, DateFormat, ColorTheme } from "@/context/SettingsContext";
import { Palette, Clock, Calendar, DollarSign, Check } from "lucide-react";
import { VoiceAlertSettings } from '@/components/settings/VoiceAlertSettings';

const Settings = () => {
  const { 
    currency, setCurrency,
    timeFormat, setTimeFormat,
    dateFormat, setDateFormat,
    colorTheme, setColorTheme
  } = useSettings();

  const colorThemeOptions = [
    { value: 'default', label: 'Ocean Blue', description: 'Classic blue and gray', colors: ['#3b82f6', '#6b7280'] },
    { value: 'professional', label: 'Professional', description: 'Navy and slate', colors: ['#1e40af', '#475569'] },
    { value: 'modern', label: 'Electric Green', description: 'Fresh and modern', colors: ['#059669', '#0d9488'] },
    { value: 'vibrant', label: 'Vibrant Sunset', description: 'Colorful and energetic', colors: ['#ea580c', '#ec4899'] }
  ];

  return (
    <div className="container mx-auto px-4 py-6 space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Settings</h1>
        <p className="text-muted-foreground">
          Manage your application preferences and configurations
        </p>
      </div>

      <div className="grid gap-6">
        {/* Voice Alert Settings */}
        <VoiceAlertSettings />
        
        {/* Color Theme Settings */}
        <Card className="shadow-lg border-0 bg-gradient-to-br from-card to-primary/5 backdrop-blur-sm">
          <CardHeader className="pb-6">
            <CardTitle className="flex items-center gap-3 text-xl font-semibold">
              <div className="p-2 bg-primary/10 rounded-lg">
                <Palette className="h-6 w-6 text-primary" />
              </div>
              Appearance & Theme
            </CardTitle>
            <CardDescription className="text-base leading-relaxed">
              Choose your preferred color scheme to personalize your dashboard experience
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-4">
              <Label htmlFor="color-theme" className="text-sm font-medium text-foreground">
                Color Theme
              </Label>
              <div className="grid grid-cols-1 gap-3">
                {colorThemeOptions.map((option) => (
                  <div
                    key={option.value}
                    className={`relative p-4 rounded-xl border-2 transition-all duration-200 cursor-pointer hover:shadow-md ${
                      colorTheme === option.value
                        ? 'border-primary bg-primary/5 shadow-sm'
                        : 'border-border hover:border-primary/30'
                    }`}
                    onClick={() => setColorTheme(option.value as ColorTheme)}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="flex gap-1">
                          {option.colors.map((color, index) => (
                            <div
                              key={index}
                              className="w-4 h-4 rounded-full border border-white shadow-sm"
                              style={{ backgroundColor: color }}
                            />
                          ))}
                        </div>
                        <div>
                          <div className="font-medium text-foreground">
                            {option.label}
                          </div>
                          <div className="text-sm text-muted-foreground">
                            {option.description}
                          </div>
                        </div>
                      </div>
                      {colorTheme === option.value && (
                        <Check className="h-5 w-5 text-primary" />
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Currency Settings */}
        <Card className="shadow-lg border-0 bg-gradient-to-br from-card to-secondary/5 backdrop-blur-sm">
          <CardHeader className="pb-6">
            <CardTitle className="flex items-center gap-3 text-xl font-semibold">
              <div className="p-2 bg-secondary/10 rounded-lg">
                <DollarSign className="h-6 w-6 text-secondary" />
              </div>
              Currency & Localization
            </CardTitle>
            <CardDescription className="text-base leading-relaxed">
              Configure your preferred currency and regional settings for financial data
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-3">
              <Label htmlFor="currency" className="text-sm font-medium text-foreground">
                Default Currency
              </Label>
              <Select value={currency} onValueChange={(value: CurrencyType) => setCurrency(value)}>
                <SelectTrigger className="w-full h-12 bg-card border-border focus:ring-2 focus:ring-secondary focus:border-transparent">
                  <SelectValue placeholder="Select currency" />
                </SelectTrigger>
                <SelectContent className="bg-card border-border">
                  <SelectItem value="INR" className="text-base py-3">
                    <div className="flex items-center gap-3">
                      <span className="text-lg">₹</span>
                      <div>
                        <div className="font-medium">Indian Rupee</div>
                        <div className="text-sm text-muted-foreground">INR</div>
                      </div>
                    </div>
                  </SelectItem>
                  <SelectItem value="USD" className="text-base py-3">
                    <div className="flex items-center gap-3">
                      <span className="text-lg">$</span>
                      <div>
                        <div className="font-medium">US Dollar</div>
                        <div className="text-sm text-muted-foreground">USD</div>
                      </div>
                    </div>
                  </SelectItem>
                  <SelectItem value="EUR" className="text-base py-3">
                    <div className="flex items-center gap-3">
                      <span className="text-lg">€</span>
                      <div>
                        <div className="font-medium">Euro</div>
                        <div className="text-sm text-muted-foreground">EUR</div>
                      </div>
                    </div>
                  </SelectItem>
                  <SelectItem value="GBP" className="text-base py-3">
                    <div className="flex items-center gap-3">
                      <span className="text-lg">£</span>
                      <div>
                        <div className="font-medium">British Pound</div>
                        <div className="text-sm text-muted-foreground">GBP</div>
                      </div>
                    </div>
                  </SelectItem>
                  <SelectItem value="JPY" className="text-base py-3">
                    <div className="flex items-center gap-3">
                      <span className="text-lg">¥</span>
                      <div>
                        <div className="font-medium">Japanese Yen</div>
                        <div className="text-sm text-muted-foreground">JPY</div>
                      </div>
                    </div>
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Date & Time Settings */}
        <Card className="lg:col-span-2 shadow-lg border-0 bg-gradient-to-br from-card to-accent/5 backdrop-blur-sm">
          <CardHeader className="pb-6">
            <CardTitle className="flex items-center gap-3 text-xl font-semibold">
              <div className="p-2 bg-accent/20 rounded-lg">
                <Clock className="h-6 w-6 text-accent-foreground" />
              </div>
              Date & Time Preferences
            </CardTitle>
            <CardDescription className="text-base leading-relaxed">
              Customize how dates and times are displayed throughout the application
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-8">
              <div className="space-y-3">
                <Label htmlFor="time-format" className="text-sm font-medium text-foreground flex items-center gap-2">
                  <Clock className="h-4 w-4" />
                  Time Format
                </Label>
                <Select value={timeFormat} onValueChange={(value: TimeFormat) => setTimeFormat(value)}>
                  <SelectTrigger className="w-full h-12 bg-card border-border focus:ring-2 focus:ring-accent focus:border-transparent">
                    <SelectValue placeholder="Select time format" />
                  </SelectTrigger>
                  <SelectContent className="bg-card border-border">
                    <SelectItem value="12h" className="text-base py-3">
                      <div>
                        <div className="font-medium">12-hour format</div>
                        <div className="text-sm text-muted-foreground">2:30 PM</div>
                      </div>
                    </SelectItem>
                    <SelectItem value="24h" className="text-base py-3">
                      <div>
                        <div className="font-medium">24-hour format</div>
                        <div className="text-sm text-muted-foreground">14:30</div>
                      </div>
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-3">
                <Label htmlFor="date-format" className="text-sm font-medium text-foreground flex items-center gap-2">
                  <Calendar className="h-4 w-4" />
                  Date Format
                </Label>
                <Select value={dateFormat} onValueChange={(value: DateFormat) => setDateFormat(value)}>
                  <SelectTrigger className="w-full h-12 bg-card border-border focus:ring-2 focus:ring-accent focus:border-transparent">
                    <SelectValue placeholder="Select date format" />
                  </SelectTrigger>
                  <SelectContent className="bg-card border-border">
                    <SelectItem value="DD/MM/YYYY" className="text-base py-3">
                      <div>
                        <div className="font-medium">DD/MM/YYYY</div>
                        <div className="text-sm text-muted-foreground">31/12/2024</div>
                      </div>
                    </SelectItem>
                    <SelectItem value="MM/DD/YYYY" className="text-base py-3">
                      <div>
                        <div className="font-medium">MM/DD/YYYY</div>
                        <div className="text-sm text-muted-foreground">12/31/2024</div>
                      </div>
                    </SelectItem>
                    <SelectItem value="YYYY-MM-DD" className="text-base py-3">
                      <div>
                        <div className="font-medium">YYYY-MM-DD</div>
                        <div className="text-sm text-muted-foreground">2024-12-31</div>
                      </div>
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Footer Information */}
      <div className="mt-12 p-6 bg-gradient-to-r from-primary/5 to-secondary/5 rounded-xl border border-primary/10">
        <div className="flex items-start gap-4">
          <div className="p-2 bg-primary/10 rounded-lg">
            <Check className="h-5 w-5 text-primary" />
          </div>
          <div>
            <h3 className="font-semibold text-foreground mb-2">
              Settings Saved Automatically
            </h3>
            <p className="text-muted-foreground leading-relaxed">
              All your preferences are automatically saved and will be applied across your entire dashboard experience. 
              Changes take effect immediately and persist across browser sessions.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Settings;
