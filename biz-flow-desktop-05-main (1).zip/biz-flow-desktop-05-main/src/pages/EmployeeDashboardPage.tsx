
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useEmployeeAuth } from '@/context/EmployeeAuthContext';
import { Clock, MapPin, LogOut, User, Calendar } from 'lucide-react';

const EmployeeDashboardPage = () => {
  const { employee, signOut } = useEmployeeAuth();

  if (!employee) {
    return <div>Loading...</div>;
  }

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold">Welcome, {employee.first_name}!</h1>
            <p className="text-gray-600">Employee Dashboard</p>
          </div>
          <Button onClick={signOut} variant="outline" className="flex items-center gap-2">
            <LogOut className="h-4 w-4" />
            Logout
          </Button>
        </div>

        {/* Employee Info Card */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <User className="h-5 w-5" />
              Your Information
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium text-gray-500">Full Name</label>
                <p className="text-lg">{employee.first_name} {employee.last_name}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-500">Employee Code</label>
                <p className="text-lg">{employee.employee_code}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-500">Email</label>
                <p className="text-lg">{employee.email}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-500">Department</label>
                <p className="text-lg">{employee.department || 'Not assigned'}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-500">Status</label>
                <Badge className={employee.employment_status === 'active' ? 'bg-green-500' : 'bg-red-500'}>
                  {employee.employment_status}
                </Badge>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-500">Last Login</label>
                <p className="text-lg">
                  {employee.last_login ? new Date(employee.last_login).toLocaleString() : 'First time login'}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="h-5 w-5" />
                Attendance
              </CardTitle>
              <CardDescription>Manage your attendance</CardDescription>
            </CardHeader>
            <CardContent>
              <Button className="w-full">View Attendance</Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="h-5 w-5" />
                Leave Requests
              </CardTitle>
              <CardDescription>Apply for leave</CardDescription>
            </CardHeader>
            <CardContent>
              <Button className="w-full" variant="outline">Apply for Leave</Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MapPin className="h-5 w-5" />
                Check-In
              </CardTitle>
              <CardDescription>Clock in/out</CardDescription>
            </CardHeader>
            <CardContent>
              <Button className="w-full" variant="outline">Clock In/Out</Button>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Recent Activity</CardTitle>
            <CardDescription>Your recent work activities</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-gray-500">No recent activity to display.</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default EmployeeDashboardPage;
