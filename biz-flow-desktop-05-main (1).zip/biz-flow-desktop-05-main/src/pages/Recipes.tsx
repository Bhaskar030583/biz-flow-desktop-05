
import React, { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import IngredientManagement from "@/components/recipe/IngredientManagement";
import RecipeManagement from "@/components/recipe/RecipeManagement";
import IngredientStockManagement from "@/components/recipe/IngredientStockManagement";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/context/AuthContext";

const Recipes = () => {
  const { user } = useAuth();
  const [selectedShopId, setSelectedShopId] = useState<string>("");

  // Fetch HR stores
  const { data: stores } = useQuery({
    queryKey: ['hr-stores'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('hr_stores')
        .select('id, store_name, store_code')
        .order('store_name');
      
      if (error) throw error;
      return data || [];
    },
    enabled: !!user?.id
  });

  const selectedStore = stores?.find(store => store.id === selectedShopId);

  if (!user) {
    return null;
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-6">
        <h1 className="text-2xl font-bold mb-2">Recipe Management System</h1>
        <p className="text-muted-foreground">
          Manage ingredients, create recipes, and track ingredient consumption for your products
        </p>
      </div>
      
      <Tabs defaultValue="ingredients" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="ingredients">Ingredients</TabsTrigger>
          <TabsTrigger value="recipes">Recipes</TabsTrigger>
          <TabsTrigger value="stock">Ingredient Stock</TabsTrigger>
          <TabsTrigger value="overview">Overview</TabsTrigger>
        </TabsList>
        
        <TabsContent value="ingredients" className="space-y-6">
          <IngredientManagement />
        </TabsContent>
        
        <TabsContent value="recipes" className="space-y-6">
          <RecipeManagement />
        </TabsContent>
        
        <TabsContent value="stock" className="space-y-6">
          <Card className="mb-4">
            <CardHeader>
              <CardTitle>Select Store</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="max-w-md">
                <Label htmlFor="store-select">Store</Label>
                <Select value={selectedShopId} onValueChange={setSelectedShopId}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select a store" />
                  </SelectTrigger>
                  <SelectContent>
                    {stores?.map(store => (
                      <SelectItem key={store.id} value={store.id}>
                        {store.store_name} {store.store_code && `(${store.store_code})`}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>
          
          <IngredientStockManagement 
            selectedShopId={selectedShopId}
            shopName={selectedStore?.store_name}
          />
        </TabsContent>
        
        <TabsContent value="overview" className="space-y-6">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base">Getting Started</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 text-sm">
                  <div className="flex items-center gap-2">
                    <div className="w-6 h-6 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-xs">1</div>
                    <span>Add ingredients (milk, sugar, tea powder, etc.)</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-6 h-6 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-xs">2</div>
                    <span>Create recipes for your products</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-6 h-6 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-xs">3</div>
                    <span>Enter morning ingredient quantities</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-6 h-6 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-xs">4</div>
                    <span>Sell products in POS - ingredients auto-consume</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base">Recipe System Benefits</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 text-sm text-muted-foreground">
                  <p>• Automatic ingredient consumption tracking</p>
                  <p>• Real-time stock calculations</p>
                  <p>• Prevent overselling when ingredients run out</p>
                  <p>• Cost tracking and profit analysis</p>
                  <p>• Standardized product recipes</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base">Example Recipe</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 text-sm">
                  <div className="font-medium">Tea Recipe:</div>
                  <div className="space-y-1 text-muted-foreground">
                    <p>• Milk: 0.05 liters</p>
                    <p>• Sugar: 5 grams</p>
                    <p>• Tea Powder: 2 grams</p>
                  </div>
                  <div className="text-xs text-muted-foreground mt-2">
                    When you sell 1 tea, these quantities are automatically deducted from your ingredient stock.
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Recipes;
