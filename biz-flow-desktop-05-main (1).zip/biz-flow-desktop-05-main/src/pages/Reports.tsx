
import React from 'react';
import { Routes, Route } from 'react-router-dom';
import ReportsDashboard from '@/components/reports/ReportsDashboard';
import SalesReport from '@/components/reports/SalesReport';
import ExpenseReport from '@/components/reports/ExpenseReport';
import ProfitLossReport from '@/components/reports/ProfitLossReport';
import InventoryReport from '@/components/reports/InventoryReport';
import CustomerReport from '@/components/reports/CustomerReport';
import HRMSReport from '@/components/reports/HRMSReport';
import KPIDashboard from '@/components/reports/KPIDashboard';
import BusinessAnalytics from '@/components/reports/BusinessAnalytics';

const Reports = () => {
  return (
    <div className="container mx-auto px-4 py-6">
      <Routes>
        <Route index element={<ReportsDashboard />} />
        <Route path="sales" element={<SalesReport />} />
        <Route path="expenses" element={<ExpenseReport />} />
        <Route path="profit-loss" element={<ProfitLossReport />} />
        <Route path="inventory" element={<InventoryReport />} />
        <Route path="customers" element={<CustomerReport />} />
        <Route path="hrms" element={<HRMSReport />} />
        <Route path="kpi" element={<KPIDashboard />} />
        <Route path="analytics" element={<BusinessAnalytics />} />
      </Routes>
    </div>
  );
};

export default Reports;
