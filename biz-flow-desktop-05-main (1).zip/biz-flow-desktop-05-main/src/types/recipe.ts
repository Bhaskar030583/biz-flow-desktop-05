
export interface Ingredient {
  id: string;
  name: string;
  unit: string;
  cost_per_unit: number;
  user_id: string;
  created_at: string;
  updated_at: string;
}

export interface Recipe {
  id: string;
  product_id: string;
  recipe_name: string;
  description?: string;
  user_id: string;
  created_at: string;
  updated_at: string;
  recipe_ingredients?: RecipeIngredient[];
  products?: {
    id: string;
    name: string;
    price: number;
  };
}

export interface RecipeIngredient {
  id: string;
  recipe_id: string;
  ingredient_id: string;
  quantity: number;
  user_id: string;
  created_at: string;
  ingredients?: Ingredient;
}

export interface IngredientStock {
  id: string;
  ingredient_id: string;
  hr_shop_id: string;
  stock_date: string;
  opening_stock: number;
  stock_added: number;
  stock_consumed: number;
  actual_stock: number;
  user_id: string;
  created_at: string;
  updated_at: string;
  ingredients?: Ingredient;
}
