
export interface CartItem {
  id: string;
  name: string;
  price: number;
  category: string;
  quantity: number;
  total: number;
}

export interface StoreInfo {
  storeName: string;
  salespersonName: string;
  shiftName: string;
}

export interface POSCartOperationsProps {
  cart: CartItem[];
  setCart: (cart: CartItem[]) => void;
}

export interface POSSystemStateProps {
  propStoreInfo: StoreInfo | null;
  propSelectedShopId: string;
  propSelectedShiftId: string;
}
