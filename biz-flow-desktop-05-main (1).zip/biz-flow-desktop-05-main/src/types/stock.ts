
export interface Store {
  id: string;
  store_name: string;
}

export interface Product {
  id: string;
  name: string;
  category?: string;
  price?: number;
}

export interface Shop {
  id: string;
  name: string;
  store_code?: string;
}

export interface Shift {
  id: string;
  shift_name: string;
}

// Enhanced Product interface with additional properties for stock management
export interface StockProduct extends Product {
  quantity?: number;
  expectedClosing?: number;
}

// Enhanced Shop interface with additional properties
export interface StockShop extends Shop {
  address?: string;
  phone?: string;
}

// Enhanced Store interface for consistency
export interface HRStore extends Store {
  store_code?: string;
  address?: string;
}
