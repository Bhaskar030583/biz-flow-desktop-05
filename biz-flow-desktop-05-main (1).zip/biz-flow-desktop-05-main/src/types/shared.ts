
// Core Business Types
export interface Product {
  id: string;
  name: string;
  price: number;
  cost_price?: number;
  category: string;
  quantity?: number;
  sku?: string;
  user_id: string;
  created_at: string;
  updated_at: string;
}

export interface Customer {
  id: string;
  name: string;
  phone: string;
  email: string | null;
  address: string | null;
  credit_limit: number;
  user_id: string;
  created_at: string;
  updated_at: string;
}

export interface Shop {
  id: string;
  name: string;
  store_code?: string;
  address?: string;
  phone?: string;
}

export interface Store {
  id: string;
  store_name: string;
  store_code?: string;
  address: string;
  manager_id?: string;
  latitude?: number;
  longitude?: number;
  geo_fence_radius?: number;
  created_at: string;
  updated_at: string;
}

// POS Types
export interface CartItem {
  id: string;
  name: string;
  price: number;
  category: string;
  quantity: number;
  total: number;
}

export interface StoreInfo {
  storeName: string;
  salespersonName: string;
  shiftName: string;
}

export interface Bill {
  id: string;
  bill_number: string;
  total_amount: number;
  payment_method: string;
  payment_status: string;
  bill_date: string;
  customer_id?: string;
}

export interface BillItem {
  id: string;
  bill_id: string;
  product_id: string;
  product_name: string;
  quantity: number;
  unit_price: number;
  total_price: number;
}

// Credit & Financial Types
export interface CreditTransaction {
  id: string;
  customer_id: string;
  amount: number;
  description: string;
  status: 'pending' | 'paid' | 'cancelled';
  transaction_date: string;
  created_at: string;
}

export interface Expense {
  id: string;
  amount: number;
  category: string;
  description: string;
  expense_date: string;
  payment_method: string;
  shop_id: string;
  user_id: string;
}

// Stock & Inventory Types
export interface StockItem {
  id: string;
  product_id: string;
  shop_id: string;
  opening_stock: number;
  closing_stock: number;
  actual_stock: number;
  stock_added?: number;
  stock_date: string;
  shift?: string;
  operator_name?: string;
  user_id: string;
}

export interface StockMovement {
  id: string;
  product_id: string;
  from_shop_id?: string;
  to_shop_id: string;
  quantity: number;
  movement_type: 'transfer' | 'adjustment' | 'loss';
  movement_date: string;
  status: 'pending' | 'approved' | 'rejected';
  notes?: string;
}

// UI & Form Types
export interface FormField {
  label: string;
  name: string;
  type: 'text' | 'number' | 'email' | 'tel' | 'textarea' | 'select' | 'date';
  required?: boolean;
  placeholder?: string;
  options?: Array<{ value: string; label: string }>;
  validation?: (value: any) => string | null;
}

export interface ModalState {
  isOpen: boolean;
  data?: any;
}

export interface TableColumn<T = any> {
  key: keyof T;
  header: string;
  cell?: (item: T) => React.ReactNode;
  sortable?: boolean;
  width?: string;
}

export interface FilterOption {
  label: string;
  value: string;
  count?: number;
}

export interface PaginationConfig {
  page: number;
  pageSize: number;
  total: number;
}

// Settings & Configuration Types
export interface AppSettings {
  currency: 'INR' | 'USD' | 'EUR' | 'GBP' | 'JPY';
  dateFormat: 'DD/MM/YYYY' | 'MM/DD/YYYY' | 'YYYY-MM-DD';
  timeFormat: '12h' | '24h';
  theme: 'light' | 'dark' | 'system';
}

// API Response Types
export interface ApiResponse<T = any> {
  data: T;
  success: boolean;
  message?: string;
  error?: string;
}

export interface ListResponse<T = any> {
  data: T[];
  total: number;
  page: number;
  pageSize: number;
  hasNext: boolean;
  hasPrev: boolean;
}

// Permission & Access Types
export interface UserPermissions {
  canView: string[];
  canEdit: string[];
  canDelete: string[];
  canCreate: string[];
}

export interface PageAccess {
  page: string;
  access: 'read' | 'write' | 'admin';
}

// Utility Types
export type Status = 'pending' | 'approved' | 'rejected' | 'completed' | 'cancelled';
export type PaymentMethod = 'cash' | 'card' | 'upi' | 'credit' | 'split';
export type UserRole = 'admin' | 'lead' | 'sales' | 'user';

// Component Props Types
export interface BaseComponentProps {
  className?: string;
  children?: React.ReactNode;
}

export interface LoadingProps extends BaseComponentProps {
  isLoading: boolean;
  error?: string | null;
  emptyMessage?: string;
}

export interface ActionButtonProps {
  label: string;
  icon?: React.ComponentType<any>;
  onClick: () => void;
  variant?: 'primary' | 'secondary' | 'danger' | 'ghost';
  size?: 'sm' | 'md' | 'lg';
  disabled?: boolean;
  loading?: boolean;
  className?: string;
}
