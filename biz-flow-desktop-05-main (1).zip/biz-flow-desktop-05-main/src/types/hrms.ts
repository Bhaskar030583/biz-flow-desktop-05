
export interface HRMSEmployee {
    id: string;
    employee_code: string;
    first_name: string;
    last_name: string;
    email: string;
    phone?: string;
    address?: string;
    hire_date: string;
    department?: string;
    position?: string;
    employment_status: 'active' | 'inactive' | 'terminated';
    salary?: number;
    user_id: string;
    created_at: string;
    updated_at: string;
}

export interface Employee {
  id: string;
  employee_code: string;
  first_name: string;
  last_name: string;
  email: string;
  phone?: string;
  address?: string;
  hire_date: string;
  date_of_birth?: string;
  date_of_joining?: string;
  department?: string;
  position?: string;
  designation?: string;
  employment_status: 'active' | 'inactive' | 'terminated' | 'on_leave';
  salary?: number;
  hourly_rate?: number;
  bank_account_number?: string;
  bank_name?: string;
  bank_ifsc?: string;
  emergency_contact_name?: string;
  emergency_contact_phone?: string;
  user_id: string;
  created_at: string;
  updated_at: string;
  password_hash?: string;
  is_login_enabled?: boolean;
  last_login?: string;
  created_by?: string;
}

export interface Store {
  id: string;
  store_name: string;
  store_code: string;
  address?: string;
  phone?: string;
  email?: string;
  manager_id?: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
  user_id: string;
  latitude?: number;
  longitude?: number;
  geo_fence_radius?: number;
}

export interface Shift {
  id: string;
  shift_name: string;
  start_time: string;
  end_time: string;
  break_duration?: number;
  is_active: boolean;
  created_at: string;
  updated_at: string;
  user_id: string;
  shift_type?: string;
  store_id?: string;
  grace_period?: number;
}

export interface AttendanceRecord {
  id: string;
  employee_id: string;
  store_id?: string;
  shift_id?: string;
  attendance_date: string;
  check_in_time?: string;
  check_out_time?: string;
  check_in_latitude?: number;
  check_in_longitude?: number;
  check_in_address?: string;
  check_out_latitude?: number;
  check_out_longitude?: number;
  check_out_address?: string;
  total_hours?: number;
  status: 'present' | 'absent' | 'late' | 'on_leave';
  notes?: string;
  created_at: string;
  updated_at: string;
  user_id: string;
  is_late?: boolean;
  late_by_minutes?: number;
  hr_employees?: {
    first_name: string;
    last_name: string;
    employee_code: string;
  };
  hr_stores?: {
    store_name: string;
  };
  hr_shifts?: {
    shift_name: string;
  };
}

export interface LeaveRequest {
  id: string;
  employee_id: string;
  leave_type: 'sick' | 'vacation' | 'personal' | 'emergency' | 'casual' | 'paid' | 'unpaid' | 'maternity' | 'paternity';
  start_date: string;
  end_date: string;
  total_days: number;
  reason?: string;
  status: 'pending' | 'approved' | 'rejected';
  approved_by?: string;
  approved_at?: string;
  approved_on?: string;
  applied_on?: string;
  rejection_reason?: string;
  created_at: string;
  updated_at: string;
  user_id: string;
  is_half_day?: boolean;
  hr_employees?: {
    first_name: string;
    last_name: string;
    employee_code: string;
  };
}

export interface PayslipRaw {
  id: string;
  employee_id: string;
  month: number;
  year: number;
  basic_salary: number;
  total_hours_worked?: number;
  overtime_hours?: number;
  overtime_rate?: number;
  allowances?: number;
  deductions?: number;
  gross_salary: number;
  tax_deduction?: number;
  net_salary: number;
  payment_date?: string;
  status: 'draft' | 'paid' | 'cancelled';
  created_at: string;
  updated_at: string;
  user_id: string;
  is_final: boolean; // Make this required to match PayrollRecord
  total_working_days?: number;
  days_worked?: number;
  total_hours?: number;
  regular_hours?: number;
  advance_deductions?: number;
  penalty_deductions?: number;
  other_deductions?: number;
  unpaid_leave_deductions?: number;
  bonuses?: number;
  generated_by?: string;
  generated_on?: string;
  hr_employees?: {
    first_name: string;
    last_name: string;
    employee_code: string;
    hourly_rate: number;
  };
}

export type PayrollRecord = PayslipRaw;
