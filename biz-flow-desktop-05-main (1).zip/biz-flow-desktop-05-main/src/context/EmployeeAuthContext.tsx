

import React, { createContext, useContext, useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Employee } from "@/types/hrms";
import { useToast } from "@/hooks/use-toast";
import { useNavigate } from "react-router-dom";

interface EmployeeAuthContextType {
  employee: Employee | null;
  loading: boolean;
  signIn: (email: string, password: string) => Promise<{ error: any | null }>;
  signOut: () => Promise<void>;
  sessionToken: string | null;
}

const EmployeeAuthContext = createContext<EmployeeAuthContextType | undefined>(undefined);

export function EmployeeAuthProvider({ children }: { children: React.ReactNode }) {
  const [employee, setEmployee] = useState<Employee | null>(null);
  const [loading, setLoading] = useState(true);
  const [sessionToken, setSessionToken] = useState<string | null>(null);
  const { toast } = useToast();
  const navigate = useNavigate();

  useEffect(() => {
    checkExistingSession();
  }, []);

  const checkExistingSession = async () => {
    try {
      const storedSession = localStorage.getItem('employeeSession');
      if (storedSession) {
        const sessionData = JSON.parse(storedSession);
        
        // Verify session is still valid
        const { data: session, error } = await supabase
          .from('employee_sessions')
          .select(`
            *,
            hr_employees (*)
          `)
          .eq('session_token', sessionData.sessionToken)
          .gt('expires_at', new Date().toISOString())
          .single();

        if (!error && session) {
          // Map the database employee data to our Employee type
          const employeeData = session.hr_employees;
          const mappedEmployee: Employee = {
            ...employeeData,
            hire_date: employeeData.date_of_joining || employeeData.created_at,
            employment_status: employeeData.employment_status as 'active' | 'inactive' | 'terminated' | 'on_leave',
          };
          setEmployee(mappedEmployee);
          setSessionToken(sessionData.sessionToken);
        } else {
          localStorage.removeItem('employeeSession');
        }
      }
    } catch (error) {
      console.error('Error checking session:', error);
      localStorage.removeItem('employeeSession');
    } finally {
      setLoading(false);
    }
  };

  const signIn = async (email: string, password: string) => {
    try {
      setLoading(true);

      // Find employee by email
      const { data: employeeData, error: employeeError } = await supabase
        .from('hr_employees')
        .select('*')
        .eq('email', email.toLowerCase())
        .eq('is_login_enabled', true)
        .single();

      if (employeeError || !employeeData) {
        return { error: { message: 'Invalid email or employee login not enabled' } };
      }

      // For demo purposes, we'll use a simple password check
      // In production, you'd want proper password hashing
      if (!employeeData.password_hash || employeeData.password_hash !== password) {
        return { error: { message: 'Invalid email or password' } };
      }

      // Create session token
      const sessionToken = `emp_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      const expiresAt = new Date(Date.now() + 8 * 60 * 60 * 1000); // 8 hours

      // Get current user (admin) to associate with session
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        return { error: { message: 'Admin authentication required' } };
      }

      // Create employee session
      const { error: sessionError } = await supabase
        .from('employee_sessions')
        .insert({
          employee_id: employeeData.id,
          session_token: sessionToken,
          expires_at: expiresAt.toISOString(),
          user_id: user.id
        });

      if (sessionError) {
        return { error: sessionError };
      }

      // Update last login
      await supabase
        .from('hr_employees')
        .update({ last_login: new Date().toISOString() })
        .eq('id', employeeData.id);

      // Store session
      localStorage.setItem('employeeSession', JSON.stringify({
        sessionToken,
        employeeId: employeeData.id,
        expiresAt: expiresAt.toISOString()
      }));

      // Map the database employee data to our Employee type
      const mappedEmployee: Employee = {
        ...employeeData,
        hire_date: employeeData.date_of_joining || employeeData.created_at,
        employment_status: employeeData.employment_status as 'active' | 'inactive' | 'terminated' | 'on_leave',
      };

      setEmployee(mappedEmployee);
      setSessionToken(sessionToken);

      toast({
        title: "Welcome!",
        description: `Logged in as ${employeeData.first_name} ${employeeData.last_name}`,
      });

      return { error: null };
    } catch (error: any) {
      console.error('Employee login error:', error);
      return { error };
    } finally {
      setLoading(false);
    }
  };

  const signOut = async () => {
    try {
      if (sessionToken) {
        await supabase
          .from('employee_sessions')
          .delete()
          .eq('session_token', sessionToken);
      }
      
      localStorage.removeItem('employeeSession');
      setEmployee(null);
      setSessionToken(null);
      
      toast({
        title: "Logged out",
        description: "You have been logged out successfully",
      });
      
      navigate('/employee-auth');
    } catch (error) {
      console.error('Logout error:', error);
    }
  };

  const value = {
    employee,
    loading,
    signIn,
    signOut,
    sessionToken,
  };

  return <EmployeeAuthContext.Provider value={value}>{children}</EmployeeAuthContext.Provider>;
}

export function useEmployeeAuth() {
  const context = useContext(EmployeeAuthContext);
  if (context === undefined) {
    throw new Error("useEmployeeAuth must be used within an EmployeeAuthProvider");
  }
  return context;
}

