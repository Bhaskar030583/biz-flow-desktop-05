
/**
 * Email validation
 */
export const isValidEmail = (email: string): boolean => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
};

/**
 * Phone number validation (supports various formats)
 */
export const isValidPhone = (phone: string): boolean => {
  // Remove all non-digit characters for validation
  const cleanPhone = phone.replace(/\D/g, '');
  
  // Support various formats: 10 digits, +91 followed by 10 digits, etc.
  return cleanPhone.length >= 10 && cleanPhone.length <= 15;
};

/**
 * Indian phone number validation (specific)
 */
export const isValidIndianPhone = (phone: string): boolean => {
  const cleanPhone = phone.replace(/\D/g, '');
  
  // Indian mobile numbers are 10 digits starting with 6-9
  if (cleanPhone.length === 10) {
    return /^[6-9]/.test(cleanPhone);
  }
  
  // With country code +91
  if (cleanPhone.length === 12 && cleanPhone.startsWith('91')) {
    return /^91[6-9]/.test(cleanPhone);
  }
  
  return false;
};

/**
 * Required field validation
 */
export const isRequired = (value: any): boolean => {
  if (typeof value === 'string') {
    return value.trim().length > 0;
  }
  return value !== null && value !== undefined && value !== '';
};

/**
 * Minimum length validation
 */
export const hasMinLength = (value: string, minLength: number): boolean => {
  return value.trim().length >= minLength;
};

/**
 * Maximum length validation
 */
export const hasMaxLength = (value: string, maxLength: number): boolean => {
  return value.trim().length <= maxLength;
};

/**
 * Numeric validation
 */
export const isNumeric = (value: string): boolean => {
  return !isNaN(Number(value)) && !isNaN(parseFloat(value));
};

/**
 * Positive number validation
 */
export const isPositiveNumber = (value: number | string): boolean => {
  const num = typeof value === 'string' ? parseFloat(value) : value;
  return !isNaN(num) && num > 0;
};

/**
 * Non-negative number validation
 */
export const isNonNegativeNumber = (value: number | string): boolean => {
  const num = typeof value === 'string' ? parseFloat(value) : value;
  return !isNaN(num) && num >= 0;
};

/**
 * Price validation (non-negative with up to 2 decimal places)
 */
export const isValidPrice = (value: number | string): boolean => {
  const num = typeof value === 'string' ? parseFloat(value) : value;
  
  if (isNaN(num) || num < 0) {
    return false;
  }
  
  // Check if it has more than 2 decimal places
  const decimalPlaces = (num.toString().split('.')[1] || '').length;
  return decimalPlaces <= 2;
};

/**
 * Quantity validation (positive integer)
 */
export const isValidQuantity = (value: number | string): boolean => {
  const num = typeof value === 'string' ? parseInt(value) : value;
  return Number.isInteger(num) && num > 0;
};

/**
 * SKU validation (alphanumeric with optional hyphens/underscores)
 */
export const isValidSKU = (sku: string): boolean => {
  const skuRegex = /^[A-Za-z0-9_-]+$/;
  return skuRegex.test(sku) && sku.length >= 2 && sku.length <= 50;
};

/**
 * Credit limit validation
 */
export const isValidCreditLimit = (value: number | string): boolean => {
  const num = typeof value === 'string' ? parseFloat(value) : value;
  return !isNaN(num) && num >= 0 && num <= 10000000; // Max 1 crore
};

/**
 * Percentage validation (0-100)
 */
export const isValidPercentage = (value: number | string): boolean => {
  const num = typeof value === 'string' ? parseFloat(value) : value;
  return !isNaN(num) && num >= 0 && num <= 100;
};

/**
 * Date validation
 */
export const isValidDate = (date: string | Date): boolean => {
  const dateObj = new Date(date);
  return !isNaN(dateObj.getTime());
};

/**
 * Future date validation
 */
export const isFutureDate = (date: string | Date): boolean => {
  const dateObj = new Date(date);
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  return dateObj > today;
};

/**
 * Past date validation
 */
export const isPastDate = (date: string | Date): boolean => {
  const dateObj = new Date(date);
  const today = new Date();
  today.setHours(23, 59, 59, 999);
  return dateObj < today;
};

/**
 * Form validation result interface
 */
export interface ValidationResult {
  isValid: boolean;
  errors: string[];
}

/**
 * Validate form data with multiple rules
 */
export const validateForm = (
  data: Record<string, any>,
  rules: Record<string, Array<(value: any) => boolean | string>>
): ValidationResult => {
  const errors: string[] = [];
  
  Object.entries(rules).forEach(([field, fieldRules]) => {
    const value = data[field];
    
    fieldRules.forEach(rule => {
      const result = rule(value);
      if (typeof result === 'string') {
        errors.push(`${field}: ${result}`);
      } else if (!result) {
        errors.push(`${field}: Invalid value`);
      }
    });
  });
  
  return {
    isValid: errors.length === 0,
    errors
  };
};

/**
 * Common validation rule creators
 */
export const validationRules = {
  required: (fieldName: string) => (value: any) => 
    isRequired(value) || `${fieldName} is required`,
    
  email: (value: string) => 
    isValidEmail(value) || 'Invalid email format',
    
  phone: (value: string) => 
    isValidPhone(value) || 'Invalid phone number',
    
  minLength: (min: number) => (value: string) => 
    hasMinLength(value, min) || `Minimum ${min} characters required`,
    
  maxLength: (max: number) => (value: string) => 
    hasMaxLength(value, max) || `Maximum ${max} characters allowed`,
    
  positiveNumber: (value: number | string) => 
    isPositiveNumber(value) || 'Must be a positive number',
    
  validPrice: (value: number | string) => 
    isValidPrice(value) || 'Invalid price format',
    
  validQuantity: (value: number | string) => 
    isValidQuantity(value) || 'Must be a positive integer'
};
