
import { CartItem, Product, CreditTransaction } from '@/types/shared';

/**
 * Cart management utilities
 */
export const cartUtils = {
  addItem: (cart: CartItem[], product: Product, quantity: number = 1): CartItem[] => {
    const existingItem = cart.find(item => item.id === product.id);
    
    if (existingItem) {
      return cart.map(item =>
        item.id === product.id
          ? { ...item, quantity: item.quantity + quantity, total: (item.quantity + quantity) * item.price }
          : item
      );
    }
    
    return [...cart, {
      id: product.id,
      name: product.name,
      price: product.price,
      category: product.category,
      quantity,
      total: product.price * quantity
    }];
  },

  updateQuantity: (cart: CartItem[], productId: string, quantity: number): CartItem[] => {
    if (quantity <= 0) {
      return cart.filter(item => item.id !== productId);
    }
    
    return cart.map(item =>
      item.id === productId
        ? { ...item, quantity, total: quantity * item.price }
        : item
    );
  },

  removeItem: (cart: CartItem[], productId: string): CartItem[] => {
    return cart.filter(item => item.id !== productId);
  },

  calculateTotal: (cart: CartItem[]): number => {
    return cart.reduce((total, item) => total + item.total, 0);
  },

  getItemCount: (cart: CartItem[]): number => {
    return cart.reduce((count, item) => count + item.quantity, 0);
  },

  clearCart: (): CartItem[] => [],

  applyDiscount: (total: number, discountPercent: number): number => {
    return total - (total * discountPercent / 100);
  }
};

/**
 * Financial calculations
 */
export const financialUtils = {
  calculateTax: (amount: number, taxPercent: number): number => {
    return (amount * taxPercent) / 100;
  },

  calculateTotalWithTax: (amount: number, taxPercent: number): number => {
    const tax = financialUtils.calculateTax(amount, taxPercent);
    return amount + tax;
  },

  calculateDiscount: (originalPrice: number, discountPercent: number): number => {
    return (originalPrice * discountPercent) / 100;
  },

  calculateProfitMargin: (sellingPrice: number, costPrice: number): number => {
    if (sellingPrice === 0) return 0;
    return ((sellingPrice - costPrice) / sellingPrice) * 100;
  },

  roundToCurrency: (amount: number, decimals: number = 2): number => {
    return Math.round(amount * Math.pow(10, decimals)) / Math.pow(10, decimals);
  }
};

/**
 * Credit management utilities
 */
export const creditUtils = {
  calculateTotalCredit: (transactions: CreditTransaction[]): number => {
    return transactions
      .filter(t => t.status === 'pending')
      .reduce((total, t) => total + t.amount, 0);
  },

  canMakeCreditPurchase: (currentCredit: number, creditLimit: number, purchaseAmount: number): boolean => {
    if (creditLimit <= 0) return true; // No credit limit set
    return (currentCredit + purchaseAmount) <= creditLimit;
  },

  getAvailableCredit: (currentCredit: number, creditLimit: number): number => {
    return Math.max(0, creditLimit - currentCredit);
  }
};

/**
 * Inventory utilities
 */
export const inventoryUtils = {
  isLowStock: (currentStock: number, minimumThreshold: number): boolean => {
    return currentStock <= minimumThreshold;
  },

  calculateStockValue: (quantity: number, unitPrice: number): number => {
    return quantity * unitPrice;
  },

  calculateReorderPoint: (averageDailyUsage: number, leadTimeDays: number, safetyStock: number = 0): number => {
    return (averageDailyUsage * leadTimeDays) + safetyStock;
  },

  getStockStatus: (currentStock: number, minimumThreshold: number): 'in_stock' | 'low_stock' | 'out_of_stock' => {
    if (currentStock === 0) return 'out_of_stock';
    if (currentStock <= minimumThreshold) return 'low_stock';
    return 'in_stock';
  }
};

/**
 * Business validation utilities
 */
export const businessValidators = {
  isValidQuantity: (quantity: number): boolean => {
    return Number.isInteger(quantity) && quantity > 0;
  },

  isValidPrice: (price: number): boolean => {
    return !isNaN(price) && price >= 0;
  },

  isValidCreditLimit: (limit: number): boolean => {
    return !isNaN(limit) && limit >= 0 && limit <= 10000000; // Max 1 crore
  },

  isValidPhone: (phone: string): boolean => {
    const cleanPhone = phone.replace(/\D/g, '');
    return cleanPhone.length >= 10 && cleanPhone.length <= 15;
  },

  isValidEmail: (email: string): boolean => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }
};
