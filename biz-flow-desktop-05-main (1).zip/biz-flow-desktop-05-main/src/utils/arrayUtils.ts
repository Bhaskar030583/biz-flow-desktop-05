
/**
 * Remove duplicates from array
 */
export const removeDuplicates = <T>(array: T[]): T[] => {
  return [...new Set(array)];
};

/**
 * Remove duplicates by key
 */
export const removeDuplicatesByKey = <T>(array: T[], key: keyof T): T[] => {
  const seen = new Set();
  return array.filter(item => {
    const value = item[key];
    if (seen.has(value)) {
      return false;
    }
    seen.add(value);
    return true;
  });
};

/**
 * Group array by key
 */
export const groupBy = <T>(array: T[], key: keyof T): Record<string, T[]> => {
  return array.reduce((groups, item) => {
    const value = String(item[key]);
    if (!groups[value]) {
      groups[value] = [];
    }
    groups[value].push(item);
    return groups;
  }, {} as Record<string, T[]>);
};

/**
 * Sort array by key
 */
export const sortBy = <T>(array: T[], key: keyof T, direction: 'asc' | 'desc' = 'asc'): T[] => {
  return [...array].sort((a, b) => {
    const aValue = a[key];
    const bValue = b[key];
    
    if (aValue < bValue) return direction === 'asc' ? -1 : 1;
    if (aValue > bValue) return direction === 'asc' ? 1 : -1;
    return 0;
  });
};

/**
 * Filter array by multiple conditions
 */
export const filterBy = <T>(
  array: T[],
  filters: Record<keyof T, any>
): T[] => {
  return array.filter(item => {
    return Object.entries(filters).every(([key, value]) => {
      if (value === null || value === undefined || value === '') {
        return true;
      }
      return item[key as keyof T] === value;
    });
  });
};

/**
 * Search array by text in multiple fields
 */
export const searchByText = <T>(
  array: T[],
  searchText: string,
  searchFields: (keyof T)[]
): T[] => {
  if (!searchText.trim()) return array;
  
  const searchTerms = searchText.toLowerCase().split(' ');
  
  return array.filter(item => {
    return searchTerms.every(term => {
      return searchFields.some(field => {
        const fieldValue = String(item[field]).toLowerCase();
        return fieldValue.includes(term);
      });
    });
  });
};

/**
 * Paginate array
 */
export const paginate = <T>(
  array: T[],
  page: number,
  pageSize: number
): {
  data: T[];
  currentPage: number;
  totalPages: number;
  totalItems: number;
  hasNext: boolean;
  hasPrev: boolean;
} => {
  const totalItems = array.length;
  const totalPages = Math.ceil(totalItems / pageSize);
  const startIndex = (page - 1) * pageSize;
  const endIndex = startIndex + pageSize;
  const data = array.slice(startIndex, endIndex);
  
  return {
    data,
    currentPage: page,
    totalPages,
    totalItems,
    hasNext: page < totalPages,
    hasPrev: page > 1
  };
};

/**
 * Find item by key-value pair
 */
export const findBy = <T>(array: T[], key: keyof T, value: any): T | undefined => {
  return array.find(item => item[key] === value);
};

/**
 * Get unique values from array by key
 */
export const getUniqueValues = <T>(array: T[], key: keyof T): any[] => {
  return removeDuplicates(array.map(item => item[key]));
};

/**
 * Chunk array into smaller arrays
 */
export const chunk = <T>(array: T[], size: number): T[][] => {
  const chunks: T[][] = [];
  for (let i = 0; i < array.length; i += size) {
    chunks.push(array.slice(i, i + size));
  }
  return chunks;
};

/**
 * Shuffle array randomly
 */
export const shuffle = <T>(array: T[]): T[] => {
  const shuffled = [...array];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  return shuffled;
};

/**
 * Move item in array
 */
export const moveItem = <T>(array: T[], fromIndex: number, toIndex: number): T[] => {
  const result = [...array];
  const [removed] = result.splice(fromIndex, 1);
  result.splice(toIndex, 0, removed);
  return result;
};

/**
 * Calculate sum of array values by key
 */
export const sumBy = <T>(array: T[], key: keyof T): number => {
  return array.reduce((sum, item) => {
    const value = Number(item[key]) || 0;
    return sum + value;
  }, 0);
};

/**
 * Get min value from array by key
 */
export const minBy = <T>(array: T[], key: keyof T): T | undefined => {
  if (array.length === 0) return undefined;
  
  return array.reduce((min, item) => {
    return Number(item[key]) < Number(min[key]) ? item : min;
  });
};

/**
 * Get max value from array by key
 */
export const maxBy = <T>(array: T[], key: keyof T): T | undefined => {
  if (array.length === 0) return undefined;
  
  return array.reduce((max, item) => {
    return Number(item[key]) > Number(max[key]) ? item : max;
  });
};

/**
 * Check if arrays are equal
 */
export const arraysEqual = <T>(a: T[], b: T[]): boolean => {
  if (a.length !== b.length) return false;
  return a.every((val, index) => val === b[index]);
};

/**
 * Get difference between two arrays
 */
export const arrayDifference = <T>(a: T[], b: T[]): T[] => {
  return a.filter(item => !b.includes(item));
};

/**
 * Get intersection of two arrays
 */
export const arrayIntersection = <T>(a: T[], b: T[]): T[] => {
  return a.filter(item => b.includes(item));
};

/**
 * Flatten nested array
 */
export const flatten = <T>(array: (T | T[])[]): T[] => {
  const result: T[] = [];
  
  for (const item of array) {
    if (Array.isArray(item)) {
      result.push(...flatten(item));
    } else {
      result.push(item);
    }
  }
  
  return result;
};
