
import React from 'react';
import { Badge } from '@/components/ui/badge';
import { Calculator, Edit3 } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/context/AuthContext';

interface ProductCostIndicatorProps {
  productId: string;
}

const ProductCostIndicator = ({ productId }: ProductCostIndicatorProps) => {
  const { user } = useAuth();

  // Check if product has a recipe
  const { data: hasRecipe } = useQuery({
    queryKey: ['product-has-recipe', productId],
    queryFn: async () => {
      const { data } = await supabase
        .from('recipes')
        .select('id')
        .eq('product_id', productId)
        .eq('user_id', user?.id)
        .single();

      return !!data;
    },
    enabled: !!productId && !!user?.id
  });

  if (hasRecipe) {
    return (
      <Badge variant="default" className="text-xs">
        <Calculator className="h-3 w-3 mr-1" />
        Auto
      </Badge>
    );
  }

  return (
    <Badge variant="outline" className="text-xs">
      <Edit3 className="h-3 w-3 mr-1" />
      Manual
    </Badge>
  );
};

export default ProductCostIndicator;
