
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Calculator, IndianRupee } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/context/AuthContext';

interface ProductCostBreakdownProps {
  productId: string;
  costPrice?: number;
}

const ProductCostBreakdown = ({ productId, costPrice }: ProductCostBreakdownProps) => {
  const { user } = useAuth();

  // Fetch recipe and ingredient details for cost breakdown
  const { data: recipeData } = useQuery({
    queryKey: ['product-recipe-cost', productId],
    queryFn: async () => {
      const { data: recipe } = await supabase
        .from('recipes')
        .select(`
          id,
          recipe_name,
          recipe_ingredients(
            quantity,
            ingredients(name, unit, cost_per_unit)
          )
        `)
        .eq('product_id', productId)
        .eq('user_id', user?.id)
        .single();

      return recipe;
    },
    enabled: !!productId && !!user?.id
  });

  if (!recipeData || !recipeData.recipe_ingredients || recipeData.recipe_ingredients.length === 0) {
    return (
      <Card className="mt-4">
        <CardHeader className="pb-3">
          <div className="flex items-center gap-2">
            <Calculator className="h-4 w-4" />
            <CardTitle className="text-sm">Cost Breakdown</CardTitle>
            <Badge variant="outline" className="text-xs">Manual</Badge>
          </div>
        </CardHeader>
        <CardContent className="pt-0">
          <p className="text-sm text-muted-foreground">
            No recipe found. Cost price is set manually.
          </p>
          {costPrice && (
            <div className="flex items-center gap-1 mt-2">
              <IndianRupee className="h-3 w-3" />
              <span className="font-medium">{costPrice.toFixed(2)}</span>
            </div>
          )}
        </CardContent>
      </Card>
    );
  }

  const totalCalculatedCost = recipeData.recipe_ingredients.reduce((total, ri) => {
    if (ri.ingredients) {
      return total + (ri.ingredients.cost_per_unit * ri.quantity);
    }
    return total;
  }, 0);

  return (
    <Card className="mt-4">
      <CardHeader className="pb-3">
        <div className="flex items-center gap-2">
          <Calculator className="h-4 w-4" />
          <CardTitle className="text-sm">Cost Breakdown</CardTitle>
          <Badge variant="default" className="text-xs">Auto-calculated</Badge>
        </div>
      </CardHeader>
      <CardContent className="pt-0">
        <div className="space-y-2">
          <p className="text-xs text-muted-foreground mb-3">
            From recipe: {recipeData.recipe_name}
          </p>
          
          {recipeData.recipe_ingredients.map((ri, index) => (
            ri.ingredients && (
              <div key={index} className="flex justify-between items-center text-xs">
                <span>
                  {ri.ingredients.name} ({ri.quantity} {ri.ingredients.unit})
                </span>
                <div className="flex items-center gap-1">
                  <IndianRupee className="h-3 w-3" />
                  <span>{(ri.ingredients.cost_per_unit * ri.quantity).toFixed(2)}</span>
                </div>
              </div>
            )
          ))}
          
          <div className="border-t pt-2 mt-3">
            <div className="flex justify-between items-center font-medium text-sm">
              <span>Total Cost:</span>
              <div className="flex items-center gap-1">
                <IndianRupee className="h-3 w-3" />
                <span>{totalCalculatedCost.toFixed(2)}</span>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default ProductCostBreakdown;
