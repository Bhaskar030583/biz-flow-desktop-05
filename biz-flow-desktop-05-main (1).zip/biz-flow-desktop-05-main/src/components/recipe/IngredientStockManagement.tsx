
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Plus, Package2, AlertTriangle } from 'lucide-react';
import { useIngredientStock, useUpdateIngredientStock, useIngredients } from '@/hooks/useRecipeQueries';

interface IngredientStockManagementProps {
  selectedShopId: string;
  shopName?: string;
}

const IngredientStockManagement: React.FC<IngredientStockManagementProps> = ({ 
  selectedShopId, 
  shopName 
}) => {
  const [isAddStockDialogOpen, setIsAddStockDialogOpen] = useState(false);
  const [formData, setFormData] = useState({
    ingredient_id: '',
    opening_stock: '',
    stock_added: ''
  });

  const { data: ingredientStock, isLoading } = useIngredientStock(selectedShopId);
  const { data: ingredients } = useIngredients();
  const updateStockMutation = useUpdateIngredientStock();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    await updateStockMutation.mutateAsync({
      ingredient_id: formData.ingredient_id,
      hr_shop_id: selectedShopId,
      opening_stock: parseFloat(formData.opening_stock) || 0,
      stock_added: parseFloat(formData.stock_added) || 0
    });

    setFormData({ ingredient_id: '', opening_stock: '', stock_added: '' });
    setIsAddStockDialogOpen(false);
  };

  // Get ingredients that don't have stock entries yet
  const availableIngredients = ingredients?.filter(ingredient => 
    !ingredientStock?.some(stock => stock.ingredient_id === ingredient.id)
  ) || [];

  if (isLoading) {
    return <div className="p-4">Loading ingredient stock...</div>;
  }

  if (!selectedShopId) {
    return (
      <Card>
        <CardContent className="pt-6">
          <div className="text-center py-8 text-muted-foreground">
            <Package2 className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p>Please select a store to manage ingredient stock</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Package2 className="h-5 w-5" />
            <CardTitle>Ingredient Stock - {shopName}</CardTitle>
          </div>
          <Dialog open={isAddStockDialogOpen} onOpenChange={setIsAddStockDialogOpen}>
            <DialogTrigger asChild>
              <Button disabled={!availableIngredients.length}>
                <Plus className="h-4 w-4 mr-2" />
                Add Stock Entry
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Add Ingredient Stock</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <Label htmlFor="ingredient">Ingredient</Label>
                  <Select
                    value={formData.ingredient_id}
                    onValueChange={(value) => setFormData(prev => ({ ...prev, ingredient_id: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select ingredient" />
                    </SelectTrigger>
                    <SelectContent>
                      {availableIngredients.map(ingredient => (
                        <SelectItem key={ingredient.id} value={ingredient.id}>
                          {ingredient.name} ({ingredient.unit})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="opening_stock">Opening Stock</Label>
                  <Input
                    id="opening_stock"
                    type="number"
                    step="0.001"
                    value={formData.opening_stock}
                    onChange={(e) => setFormData(prev => ({ ...prev, opening_stock: e.target.value }))}
                    placeholder="0"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="stock_added">Stock Added (Optional)</Label>
                  <Input
                    id="stock_added"
                    type="number"
                    step="0.001"
                    value={formData.stock_added}
                    onChange={(e) => setFormData(prev => ({ ...prev, stock_added: e.target.value }))}
                    placeholder="0"
                  />
                </div>
                <div className="flex gap-2 pt-4">
                  <Button 
                    type="submit" 
                    disabled={updateStockMutation.isPending}
                    className="flex-1"
                  >
                    {updateStockMutation.isPending ? 'Adding...' : 'Add Stock'}
                  </Button>
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => setIsAddStockDialogOpen(false)}
                  >
                    Cancel
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </CardHeader>
      <CardContent>
        {ingredientStock && ingredientStock.length > 0 ? (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Ingredient</TableHead>
                <TableHead>Unit</TableHead>
                <TableHead>Opening</TableHead>
                <TableHead>Added</TableHead>
                <TableHead>Consumed</TableHead>
                <TableHead>Current Stock</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {ingredientStock.map((stock) => (
                <TableRow key={stock.id}>
                  <TableCell className="font-medium">{stock.ingredients?.name}</TableCell>
                  <TableCell>{stock.ingredients?.unit}</TableCell>
                  <TableCell>{stock.opening_stock}</TableCell>
                  <TableCell>{stock.stock_added}</TableCell>
                  <TableCell>{stock.stock_consumed}</TableCell>
                  <TableCell>{stock.actual_stock}</TableCell>
                  <TableCell>
                    {stock.actual_stock <= 0 ? (
                      <Badge variant="destructive">
                        <AlertTriangle className="h-3 w-3 mr-1" />
                        Out of Stock
                      </Badge>
                    ) : stock.actual_stock < 10 ? (
                      <Badge variant="outline" className="text-orange-600 border-orange-600">
                        Low Stock
                      </Badge>
                    ) : (
                      <Badge variant="secondary">
                        In Stock
                      </Badge>
                    )}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        ) : (
          <div className="text-center py-8 text-muted-foreground">
            <Package2 className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p>No ingredient stock entries for today</p>
            <p className="text-sm">Add your morning ingredient quantities to get started</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default IngredientStockManagement;
