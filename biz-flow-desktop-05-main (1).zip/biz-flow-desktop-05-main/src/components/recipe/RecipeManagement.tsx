import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, ChefHat, Trash2, Edit, AlertCircle } from 'lucide-react';
import { useIngredients, useRecipes, useCreateRecipe, useUpdateRecipe, useDeleteRecipe } from '@/hooks/useRecipeQueries';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/context/AuthContext';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';

const RecipeManagement = () => {
  const { user } = useAuth();
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [editingRecipe, setEditingRecipe] = useState<any>(null);
  const [formData, setFormData] = useState({
    product_id: '',
    recipe_name: '',
    description: ''
  });
  const [recipeIngredients, setRecipeIngredients] = useState<Array<{ ingredient_id: string; quantity: number }>>([]);

  const { data: ingredients } = useIngredients();
  const { data: recipes, isLoading: recipesLoading } = useRecipes();
  const createRecipeMutation = useCreateRecipe();
  const updateRecipeMutation = useUpdateRecipe();
  const deleteRecipeMutation = useDeleteRecipe();

  // Fetch products
  const { data: products } = useQuery({
    queryKey: ['products', user?.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('products')
        .select('id, name, price')
        .eq('user_id', user?.id)
        .order('name');
      
      if (error) throw error;
      return data || [];
    },
    enabled: !!user?.id
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.product_id || !formData.recipe_name || recipeIngredients.length === 0) {
      return;
    }

    if (editingRecipe) {
      await updateRecipeMutation.mutateAsync({
        id: editingRecipe.id,
        product_id: formData.product_id,
        recipe_name: formData.recipe_name,
        description: formData.description,
        ingredients: recipeIngredients
      });
      setIsEditDialogOpen(false);
      setEditingRecipe(null);
    } else {
      await createRecipeMutation.mutateAsync({
        product_id: formData.product_id,
        recipe_name: formData.recipe_name,
        description: formData.description,
        ingredients: recipeIngredients
      });
      setIsCreateDialogOpen(false);
    }

    setFormData({ product_id: '', recipe_name: '', description: '' });
    setRecipeIngredients([]);
  };

  const handleEdit = (recipe: any) => {
    setEditingRecipe(recipe);
    setFormData({
      product_id: recipe.product_id,
      recipe_name: recipe.recipe_name,
      description: recipe.description || ''
    });
    
    // Convert recipe ingredients to the format expected by the form
    const ingredients = recipe.recipe_ingredients?.map((ri: any) => ({
      ingredient_id: ri.ingredient_id,
      quantity: ri.quantity
    })) || [];
    setRecipeIngredients(ingredients);
    setIsEditDialogOpen(true);
  };

  const handleDelete = async (recipeId: string) => {
    await deleteRecipeMutation.mutateAsync(recipeId);
  };

  const resetForm = () => {
    setFormData({ product_id: '', recipe_name: '', description: '' });
    setRecipeIngredients([]);
    setEditingRecipe(null);
  };

  const addIngredient = () => {
    setRecipeIngredients([...recipeIngredients, { ingredient_id: '', quantity: 0 }]);
  };

  const updateIngredient = (index: number, field: 'ingredient_id' | 'quantity', value: string | number) => {
    const updated = [...recipeIngredients];
    updated[index] = { ...updated[index], [field]: value };
    setRecipeIngredients(updated);
  };

  const removeIngredient = (index: number) => {
    setRecipeIngredients(recipeIngredients.filter((_, i) => i !== index));
  };

  const selectedProduct = Array.isArray(products) ? products.find(p => p.id === formData.product_id) : null;

  if (recipesLoading) {
    return <div className="p-4">Loading recipes...</div>;
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ChefHat className="h-5 w-5" />
            <CardTitle>Recipe Management</CardTitle>
          </div>
          <Dialog open={isCreateDialogOpen} onOpenChange={(open) => {
            setIsCreateDialogOpen(open);
            if (!open) resetForm();
          }}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Create Recipe
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Create New Recipe</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <Label htmlFor="product">Product</Label>
                  <Select
                    value={formData.product_id}
                    onValueChange={(value) => setFormData(prev => ({ 
                      ...prev, 
                      product_id: value,
                      recipe_name: selectedProduct?.name ? `${selectedProduct.name} Recipe` : ''
                    }))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select a product" />
                    </SelectTrigger>
                    <SelectContent>
                      {Array.isArray(products) && products.map(product => (
                        <SelectItem key={product.id} value={product.id}>
                          {product.name} (₹{product.price})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <Label htmlFor="recipe_name">Recipe Name</Label>
                  <Input
                    id="recipe_name"
                    value={formData.recipe_name}
                    onChange={(e) => setFormData(prev => ({ ...prev, recipe_name: e.target.value }))}
                    placeholder="e.g., Tea Recipe"
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="description">Description (Optional)</Label>
                  <Input
                    id="description"
                    value={formData.description}
                    onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                    placeholder="Recipe description"
                  />
                </div>

                <div>
                  <div className="flex items-center justify-between mb-2">
                    <Label>Recipe Ingredients</Label>
                    <Button type="button" variant="outline" size="sm" onClick={addIngredient}>
                      <Plus className="h-3 w-3 mr-1" />
                      Add Ingredient
                    </Button>
                  </div>
                  
                  <div className="space-y-2 max-h-40 overflow-y-auto">
                    {recipeIngredients.map((ingredient, index) => (
                      <div key={index} className="flex gap-2 items-center">
                        <Select
                          value={ingredient.ingredient_id}
                          onValueChange={(value) => updateIngredient(index, 'ingredient_id', value)}
                        >
                          <SelectTrigger className="flex-1">
                            <SelectValue placeholder="Select ingredient" />
                          </SelectTrigger>
                          <SelectContent>
                            {ingredients?.map(ing => (
                              <SelectItem key={ing.id} value={ing.id}>
                                {ing.name} ({ing.unit})
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <Input
                          type="number"
                          step="0.01"
                          placeholder="Qty"
                          value={ingredient.quantity || ''}
                          onChange={(e) => updateIngredient(index, 'quantity', parseFloat(e.target.value) || 0)}
                          className="w-20"
                        />
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => removeIngredient(index)}
                        >
                          <Trash2 className="h-3 w-3" />
                        </Button>
                      </div>
                    ))}
                  </div>
                  
                  {recipeIngredients.length === 0 && (
                    <p className="text-sm text-muted-foreground">No ingredients added yet</p>
                  )}
                </div>

                <div className="flex gap-2 pt-4">
                  <Button 
                    type="submit" 
                    disabled={createRecipeMutation.isPending || !formData.product_id || recipeIngredients.length === 0}
                    className="flex-1"
                  >
                    {createRecipeMutation.isPending ? 'Creating...' : 'Create Recipe'}
                  </Button>
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => setIsCreateDialogOpen(false)}
                  >
                    Cancel
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>

          {/* Edit Recipe Dialog */}
          <Dialog open={isEditDialogOpen} onOpenChange={(open) => {
            setIsEditDialogOpen(open);
            if (!open) resetForm();
          }}>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Edit Recipe</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <Label htmlFor="product">Product</Label>
                  <Select
                    value={formData.product_id}
                    onValueChange={(value) => setFormData(prev => ({ 
                      ...prev, 
                      product_id: value,
                      recipe_name: selectedProduct?.name ? `${selectedProduct.name} Recipe` : ''
                    }))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select a product" />
                    </SelectTrigger>
                    <SelectContent>
                      {Array.isArray(products) && products.map(product => (
                        <SelectItem key={product.id} value={product.id}>
                          {product.name} (₹{product.price})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <Label htmlFor="recipe_name">Recipe Name</Label>
                  <Input
                    id="recipe_name"
                    value={formData.recipe_name}
                    onChange={(e) => setFormData(prev => ({ ...prev, recipe_name: e.target.value }))}
                    placeholder="e.g., Tea Recipe"
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="description">Description (Optional)</Label>
                  <Input
                    id="description"
                    value={formData.description}
                    onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                    placeholder="Recipe description"
                  />
                </div>

                <div>
                  <div className="flex items-center justify-between mb-2">
                    <Label>Recipe Ingredients</Label>
                    <Button type="button" variant="outline" size="sm" onClick={addIngredient}>
                      <Plus className="h-3 w-3 mr-1" />
                      Add Ingredient
                    </Button>
                  </div>
                  
                  <div className="space-y-2 max-h-40 overflow-y-auto">
                    {recipeIngredients.map((ingredient, index) => (
                      <div key={index} className="flex gap-2 items-center">
                        <Select
                          value={ingredient.ingredient_id}
                          onValueChange={(value) => updateIngredient(index, 'ingredient_id', value)}
                        >
                          <SelectTrigger className="flex-1">
                            <SelectValue placeholder="Select ingredient" />
                          </SelectTrigger>
                          <SelectContent>
                            {ingredients?.map(ing => (
                              <SelectItem key={ing.id} value={ing.id}>
                                {ing.name} ({ing.unit})
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <Input
                          type="number"
                          step="0.01"
                          placeholder="Qty"
                          value={ingredient.quantity || ''}
                          onChange={(e) => updateIngredient(index, 'quantity', parseFloat(e.target.value) || 0)}
                          className="w-20"
                        />
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => removeIngredient(index)}
                        >
                          <Trash2 className="h-3 w-3" />
                        </Button>
                      </div>
                    ))}
                  </div>
                  
                  {recipeIngredients.length === 0 && (
                    <p className="text-sm text-muted-foreground">No ingredients added yet</p>
                  )}
                </div>

                <div className="flex gap-2 pt-4">
                  <Button 
                    type="submit" 
                    disabled={createRecipeMutation.isPending || !formData.product_id || recipeIngredients.length === 0}
                    className="flex-1"
                  >
                    {createRecipeMutation.isPending ? 'Creating...' : 'Create Recipe'}
                  </Button>
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => setIsEditDialogOpen(false)}
                  >
                    Cancel
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </CardHeader>
      <CardContent>
        {recipes && recipes.length > 0 ? (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Recipe Name</TableHead>
                <TableHead>Product</TableHead>
                <TableHead>Ingredients</TableHead>
                <TableHead>Description</TableHead>
                <TableHead>Created</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {recipes.map((recipe) => (
                <TableRow key={recipe.id}>
                  <TableCell className="font-medium">{recipe.recipe_name}</TableCell>
                  <TableCell>{recipe.products?.name} (₹{recipe.products?.price})</TableCell>
                  <TableCell>
                    <div className="text-sm">
                      {recipe.recipe_ingredients?.map((ri, index) => (
                        <div key={ri.id}>
                          {ri.ingredients?.name}: {ri.quantity} {ri.ingredients?.unit}
                          {index < (recipe.recipe_ingredients?.length || 0) - 1 && ', '}
                        </div>
                      ))}
                    </div>
                  </TableCell>
                  <TableCell>{recipe.description || '-'}</TableCell>
                  <TableCell>{new Date(recipe.created_at).toLocaleDateString()}</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleEdit(recipe)}
                      >
                        <Edit className="h-3 w-3" />
                      </Button>
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button
                            variant="outline"
                            size="sm"
                          >
                            <Trash2 className="h-3 w-3" />
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Delete Recipe</AlertDialogTitle>
                            <AlertDialogDescription>
                              Are you sure you want to delete this recipe? This will reset the product's cost price to manual mode.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                            <AlertDialogAction
                              onClick={() => handleDelete(recipe.id)}
                              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                            >
                              Delete
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        ) : (
          <div className="text-center py-8 text-muted-foreground">
            <ChefHat className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p>No recipes created yet</p>
            <p className="text-sm">Create your first recipe to link products with ingredients</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default RecipeManagement;
