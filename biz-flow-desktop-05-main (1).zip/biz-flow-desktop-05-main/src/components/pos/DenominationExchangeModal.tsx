
import React, { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { ArrowLeftRight, Calculator } from "lucide-react";

interface Denominations {
  [key: string]: number;
}

interface DenominationExchangeModalProps {
  isOpen: boolean;
  onClose: () => void;
  suggestedChange: Denominations;
  onExchangeConfirm: (actualChange: Denominations) => void;
  currentDenominations: Denominations;
}

export const DenominationExchangeModal: React.FC<DenominationExchangeModalProps> = ({
  isOpen,
  onClose,
  suggestedChange,
  onExchangeConfirm,
  currentDenominations
}) => {
  const [actualChange, setActualChange] = useState<Denominations>({ ...suggestedChange });
  
  const denominationValues = [500, 200, 100, 50, 20, 10, 5, 2, 1];

  const calculateTotal = (denominations: Denominations) => {
    return denominationValues.reduce((total, value) => {
      return total + (value * (denominations[value.toString()] || 0));
    }, 0);
  };

  const suggestedTotal = calculateTotal(suggestedChange);
  const actualTotal = calculateTotal(actualChange);

  const handleDenominationChange = (value: number, count: string) => {
    const numCount = parseInt(count) || 0;
    setActualChange(prev => ({
      ...prev,
      [value.toString()]: numCount
    }));
  };

  const handleConfirm = () => {
    if (actualTotal === suggestedTotal) {
      onExchangeConfirm(actualChange);
      onClose();
    }
  };

  const handleClose = () => {
    setActualChange({ ...suggestedChange });
    onClose();
  };

  const getDenominationDifference = (value: number) => {
    const suggested = suggestedChange[value.toString()] || 0;
    const actual = actualChange[value.toString()] || 0;
    return actual - suggested;
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <ArrowLeftRight className="h-5 w-5" />
            Denomination Exchange
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div className="bg-blue-50 p-4 rounded-lg">
            <h3 className="font-medium text-blue-800 mb-2">Suggested Change</h3>
            <div className="flex flex-wrap gap-2">
              {denominationValues.map(value => {
                const count = suggestedChange[value.toString()] || 0;
                if (count === 0) return null;
                return (
                  <Badge key={value} variant="outline" className="bg-blue-100 text-blue-800">
                    ₹{value} × {count} = ₹{value * count}
                  </Badge>
                );
              })}
            </div>
            <div className="text-lg font-bold text-blue-600 mt-2">
              Total: ₹{suggestedTotal}
            </div>
          </div>

          <div className="space-y-3">
            <h3 className="font-medium">Actual Change Given</h3>
            <div className="grid grid-cols-3 gap-3">
              {denominationValues.map(value => {
                const available = currentDenominations[value.toString()] || 0;
                const suggested = suggestedChange[value.toString()] || 0;
                const difference = getDenominationDifference(value);
                
                return (
                  <div key={value} className="space-y-1">
                    <Label htmlFor={`exchange-${value}`} className="text-sm font-medium">
                      ₹{value} notes
                    </Label>
                    <Input
                      id={`exchange-${value}`}
                      type="number"
                      min="0"
                      value={actualChange[value.toString()] || 0}
                      onChange={(e) => handleDenominationChange(value, e.target.value)}
                      placeholder="0"
                      className="text-center"
                    />
                    <div className="text-xs text-gray-500 text-center">
                      = ₹{(value * (actualChange[value.toString()] || 0)).toFixed(0)}
                    </div>
                    {suggested > 0 && (
                      <div className="text-xs text-blue-600 text-center">
                        Suggested: {suggested}
                      </div>
                    )}
                    {difference !== 0 && (
                      <div className={`text-xs text-center ${
                        difference > 0 ? 'text-red-600' : 'text-green-600'
                      }`}>
                        {difference > 0 ? '+' : ''}{difference} from suggested
                      </div>
                    )}
                    <div className="text-xs text-gray-400 text-center">
                      Available: {available}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="bg-gray-50 p-4 rounded-lg">
            <div className="flex justify-between items-center">
              <span className="font-medium">Actual Total:</span>
              <span className={`text-xl font-bold ${
                actualTotal === suggestedTotal ? 'text-green-600' : 'text-red-600'
              }`}>
                ₹{actualTotal}
              </span>
            </div>
            {actualTotal !== suggestedTotal && (
              <div className="text-sm text-red-600 mt-1">
                Difference: ₹{Math.abs(actualTotal - suggestedTotal)} 
                {actualTotal > suggestedTotal ? ' (excess)' : ' (shortage)'}
              </div>
            )}
          </div>

          <div className="flex gap-2 pt-4">
            <Button variant="outline" onClick={handleClose} className="flex-1">
              Cancel
            </Button>
            <Button
              onClick={handleConfirm}
              disabled={actualTotal !== suggestedTotal}
              className="flex-1 bg-green-600 hover:bg-green-700"
            >
              <Calculator className="h-4 w-4 mr-2" />
              Confirm Exchange
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};
