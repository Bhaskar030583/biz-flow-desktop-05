import React from "react";
import { CashPaymentModal } from "./CashPaymentModal";
import { CreditPaymentModal } from "./CreditPaymentModal";
import { SplitPaymentModal } from "./SplitPaymentModal";
import { PendingPaymentModal } from "./PendingPaymentModal";
import { QuickStockUpdateModal } from "./QuickStockUpdateModal";
import { createPaymentActions } from "./POSPaymentActions";
import { useAuth } from "@/context/AuthContext";
import { Product } from "@/types/shared";

interface CartItem {
  id: string;
  name: string;
  price: number;
  category: string;
  quantity: number;
  total: number;
}

interface POSProduct extends Product {
  expectedClosing?: number;
  actualStock?: number;
  openingStock?: number;
  stockAdded?: number;
  soldToday?: number;
}

interface StoreInfo {
  storeName: string;
  salespersonName: string;
  shiftName: string;
}

interface POSModalsProps {
  products: POSProduct[];
  showCashModal: boolean;
  showCreditModal: boolean;
  showSplitModal: boolean;
  showPendingModal: boolean;
  showQuickStockModal: boolean;
  cart: CartItem[];
  totalAmount: number;
  storeInfo: StoreInfo | null;
  selectedShopId: string;
  onCloseCash: () => void;
  onCloseCredit: () => void;
  onCloseSplit: () => void;
  onClosePending: () => void;
  onCloseQuickStock: () => void;
  onPaymentComplete: () => void;
  onStockUpdated: () => void;
  showToasts?: boolean;
  terminalId?: string;
}

export const POSModals: React.FC<POSModalsProps> = ({
  products,
  showCashModal,
  showCreditModal,
  showSplitModal,
  showPendingModal,
  showQuickStockModal,
  cart,
  totalAmount,
  storeInfo,
  selectedShopId,
  onCloseCash,
  onCloseCredit,
  onCloseSplit,
  onClosePending,
  onCloseQuickStock,
  onPaymentComplete,
  onStockUpdated,
  showToasts = true,
  terminalId = 'main'
}) => {
  const { user } = useAuth();

  // Create payment actions with showToasts
  const paymentActions = createPaymentActions({
    cart,
    products: products || [],
    selectedShopId,
    storeInfo,
    userId: user?.id || '',
    onStockUpdated,
    showToasts
  });

  const handleCreditPaymentComplete = async (customerId: string, customerName?: string): Promise<boolean> => {
    try {
      const success = await paymentActions.handleCreditPayment(customerId, customerName);
      if (success) {
        onPaymentComplete();
      }
      return success;
    } catch (error) {
      console.error('Error in credit payment completion:', error);
      return false;
    }
  };

  return (
    <>
      <CashPaymentModal
        isOpen={showCashModal}
        onClose={onCloseCash}
        totalAmount={totalAmount}
        cartItems={cart}
        onPaymentComplete={onPaymentComplete}
        storeInfo={storeInfo}
        selectedShopId={selectedShopId}
        terminalId={terminalId}
      />

      <CreditPaymentModal
        isOpen={showCreditModal}
        onClose={onCloseCredit}
        totalAmount={totalAmount}
        cartItems={cart}
        onPaymentComplete={handleCreditPaymentComplete}
      />

      <SplitPaymentModal
        isOpen={showSplitModal}
        onClose={onCloseSplit}
        totalAmount={totalAmount}
        cartItems={cart}
        onPaymentComplete={onPaymentComplete}
        selectedShopId={selectedShopId}
        terminalId={terminalId}
      />

      <PendingPaymentModal
        isOpen={showPendingModal}
        onClose={onClosePending}
        totalAmount={totalAmount}
        cartItems={cart}
        onPaymentComplete={onPaymentComplete}
      />

      <QuickStockUpdateModal
        isOpen={showQuickStockModal}
        onClose={onCloseQuickStock}
        products={products}
        selectedShopId={selectedShopId}
        onStockUpdated={onStockUpdated}
      />
    </>
  );
};
