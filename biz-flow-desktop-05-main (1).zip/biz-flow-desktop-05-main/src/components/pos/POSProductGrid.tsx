
import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Search, Package } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

interface Product {
  id: string;
  name: string;
  price: number;
  category: string;
  quantity?: number;
  expectedClosing?: number;
}

interface POSProductGridProps {
  searchTerm: string;
  setSearchTerm: (term: string) => void;
  selectedCategory: string;
  setSelectedCategory: (category: string) => void;
  categories: string[];
  filteredProducts: Product[];
  selectedShopId: string;
  onAddToCart: (product: Product) => void;
  showSearch?: boolean;
}

export const POSProductGrid: React.FC<POSProductGridProps> = ({
  searchTerm,
  setSearchTerm,
  selectedCategory,
  setSelectedCategory,
  categories,
  filteredProducts,
  selectedShopId,
  onAddToCart,
  showSearch = false
}) => {
  const getStockStatus = (quantity?: number) => {
    if (quantity === undefined || quantity === 0) return { status: "out", color: "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300" };
    if (quantity <= 5) return { status: "low", color: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300" };
    return { status: "good", color: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300" };
  };

  // Sort products alphabetically by name
  const sortedProducts = [...filteredProducts].sort((a, b) => a.name.localeCompare(b.name));

  return (
    <div className="flex-1 flex flex-col bg-white dark:bg-gray-800 h-screen max-w-full overflow-hidden">
      {/* Search and Filters - Fixed Header */}
      <div className="flex-shrink-0 p-4 border-b border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800">
        <div className="space-y-3">
          <div className="relative max-w-md">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 dark:text-gray-500 h-4 w-4" />
            <Input
              placeholder="Search products..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 bg-gray-50 dark:bg-gray-700 border-gray-200 dark:border-gray-600"
            />
          </div>

          <div className="w-full overflow-hidden">
            <Tabs value={selectedCategory} onValueChange={setSelectedCategory} className="w-full">
              <div className="overflow-x-auto">
                <TabsList className="inline-flex h-10 items-center justify-start rounded-md bg-gray-100 dark:bg-gray-700 p-1 text-gray-500 dark:text-gray-400 min-w-max">
                  {categories.map((category) => (
                    <TabsTrigger
                      key={category}
                      value={category}
                      className="inline-flex items-center justify-center whitespace-nowrap rounded-sm px-3 py-1.5 text-xs font-medium ring-offset-white transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-slate-950 focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 data-[state=active]:bg-blue-600 data-[state=active]:text-white data-[state=active]:shadow-sm dark:ring-offset-slate-950 dark:focus-visible:ring-slate-300 dark:data-[state=active]:bg-blue-700"
                    >
                      {category === "all" ? "All Products" : category}
                    </TabsTrigger>
                  ))}
                </TabsList>
              </div>
            </Tabs>
          </div>
        </div>
      </div>

      {/* Products Grid - Scrollable Content */}
      <div className="flex-1 overflow-hidden">
        {sortedProducts.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-gray-500 dark:text-gray-400 p-4">
            <Package className="h-16 w-16 mb-4 opacity-50" />
            <h3 className="text-lg font-medium mb-2">No Products Found</h3>
            <p className="text-center max-w-md">
              {!selectedShopId ? 
                "Please select a store to view products." :
                searchTerm ? 
                  "No products match your search criteria." : 
                  "No products are assigned to this store."
              }
            </p>
          </div>
        ) : (
          <div className="h-full overflow-y-auto">
            <div className="grid grid-cols-3 sm:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 2xl:grid-cols-7 gap-2 p-3">
              {sortedProducts.map((product) => {
                const stockStatus = getStockStatus(product.quantity);
                const isOutOfStock = product.quantity === 0;
                
                return (
                  <Card
                    key={product.id}
                    className={`group cursor-pointer transition-all duration-200 hover:shadow-lg border ${
                      isOutOfStock 
                        ? 'border-red-300 dark:border-red-700 bg-red-50 dark:bg-red-950/20 hover:border-red-400 dark:hover:border-red-600' 
                        : 'border-gray-200 dark:border-gray-700 hover:border-blue-300 dark:hover:border-blue-600'
                    }`}
                    onClick={() => onAddToCart(product)}
                  >
                    <CardContent className="p-2">
                      <div className="space-y-1.5">
                        {/* Product Name */}
                        <h3 className={`font-semibold text-xs leading-tight line-clamp-2 ${
                          isOutOfStock ? 'text-red-600 dark:text-red-400' : 'text-gray-900 dark:text-gray-100'
                        }`}>
                          {product.name}
                        </h3>

                        {/* Price */}
                        <div className={`text-sm font-bold ${
                          isOutOfStock ? 'text-red-500 dark:text-red-400' : 'text-blue-600 dark:text-blue-400'
                        }`}>
                          ₹{Number(product.price).toFixed(2)}
                        </div>

                        {/* Stock Information */}
                        <div className="space-y-1">
                          <div className="flex items-center justify-between text-xs">
                            <span className={`${
                              isOutOfStock ? 'text-red-500 dark:text-red-400' : 'text-gray-600 dark:text-gray-400'
                            }`}>Qty:</span>
                            <Badge className={`text-xs px-1 py-0.5 ${stockStatus.color}`}>
                              {product.quantity ?? 0}
                            </Badge>
                          </div>
                          
                          {product.expectedClosing !== undefined && (
                            <div className="flex items-center justify-between text-xs">
                              <span className={`${
                                isOutOfStock ? 'text-red-500 dark:text-red-400' : 'text-gray-600 dark:text-gray-400'
                              }`}>Exp:</span>
                              <span className={`font-medium ${
                                isOutOfStock ? 'text-red-600 dark:text-red-400' : 'text-gray-700 dark:text-gray-300'
                              }`}>
                                {product.expectedClosing}
                              </span>
                            </div>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
