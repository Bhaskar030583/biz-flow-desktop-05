import React, { useState, useMemo } from "react";
import { POSProductGrid } from "./POSProductGrid";
import { POSCartSidebar } from "./POSCartSidebar";
import { POSModals } from "./POSModals";
import { usePOSModals } from "@/hooks/usePOSModals";
import { useAuth } from "@/context/AuthContext";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Bell, BellOff, ShoppingCart, Package } from "lucide-react";

interface Product {
  id: string;
  name: string;
  price: number;
  category: string;
  stock?: number;
  expectedClosing?: number;
  actualStock?: number;
  openingStock?: number;
  stockAdded?: number;
  soldToday?: number;
  quantity?: number;
}

interface CartItem {
  id: string;
  name: string;
  price: number;
  category: string;
  quantity: number;
  total: number;
}

interface StoreInfo {
  storeName: string;
  salespersonName: string;
  shiftName: string;
}

interface POSMainViewProps {
  products: Product[];
  onStockAdded: () => void;
  showSearch: boolean;
  toggleSearch: () => void;
  showToasts?: boolean;
  onToggleToasts?: (enabled: boolean) => void;
  selectedShopId?: string;
  storeInfo?: StoreInfo | null;
}

export const POSMainView: React.FC<POSMainViewProps> = ({
  products,
  onStockAdded,
  showSearch,
  toggleSearch,
  showToasts = true,
  onToggleToasts,
  selectedShopId = '',
  storeInfo = null
}) => {
  const { user } = useAuth();
  const [cart, setCart] = useState<CartItem[]>([]);
  const [showMobileCart, setShowMobileCart] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");

  // Use the POS modals hook
  const {
    modalStates,
    openCashModal,
    closeCashModal,
    openCreditModal,
    closeCreditModal,
    openSplitModal,
    closeSplitModal,
    openPendingModal,
    closePendingModal,
    openQuickStockModal,
    closeQuickStockModal,
    closeAllPaymentModals
  } = usePOSModals();

  // Get unique categories from products
  const categories = useMemo(() => {
    const uniqueCategories = Array.from(new Set(products.map(p => p.category)));
    return ["all", ...uniqueCategories];
  }, [products]);

  // Filter products based on search and category
  const filteredProducts = useMemo(() => {
    return products.filter(product => {
      const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesCategory = selectedCategory === "all" || product.category === selectedCategory;
      return matchesSearch && matchesCategory;
    });
  }, [products, searchTerm, selectedCategory]);

  // Convert Product[] to POSProduct[] format for POSModals
  const posProducts = useMemo(() => {
    return products.map(product => ({
      ...product,
      user_id: user?.id || '',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    }));
  }, [products, user?.id]);

  const addToCart = (product: Product) => {
    console.log("🛒 Adding to cart:", product);
    setCart(prevCart => {
      const existingItem = prevCart.find(item => item.id === product.id);
      if (existingItem) {
        const updatedCart = prevCart.map(item =>
          item.id === product.id
            ? { ...item, quantity: item.quantity + 1, total: (item.quantity + 1) * item.price }
            : item
        );
        console.log("🛒 Updated cart (existing item):", updatedCart);
        return updatedCart;
      } else {
        const newItem: CartItem = {
          id: product.id,
          name: product.name,
          price: product.price,
          category: product.category,
          quantity: 1,
          total: product.price
        };
        const updatedCart = [...prevCart, newItem];
        console.log("🛒 Updated cart (new item):", updatedCart);
        return updatedCart;
      }
    });
  };

  const updateQuantity = (productId: string, newQuantity: number) => {
    console.log("🔄 Updating quantity:", productId, newQuantity);
    if (newQuantity <= 0) {
      removeFromCart(productId);
      return;
    }
    
    setCart(prevCart => {
      const updatedCart = prevCart.map(item =>
        item.id === productId
          ? { ...item, quantity: newQuantity, total: newQuantity * item.price }
          : item
      );
      console.log("🔄 Updated cart:", updatedCart);
      return updatedCart;
    });
  };

  const removeFromCart = (productId: string) => {
    console.log("🗑️ Removing from cart:", productId);
    setCart(prevCart => {
      const updatedCart = prevCart.filter(item => item.id !== productId);
      console.log("🗑️ Updated cart:", updatedCart);
      return updatedCart;
    });
  };

  const clearCart = () => {
    console.log("🧹 Clearing cart");
    setCart([]);
  };

  const getTotalAmount = () => {
    const total = cart.reduce((sum, item) => sum + item.total, 0);
    console.log("💰 Total amount:", total);
    return total;
  };

  // Payment handlers with proper logging
  const handleCashPayment = () => {
    console.log("💰 POSMainView: Cash payment clicked!");
    console.log("💰 POSMainView: Cart items:", cart.length);
    console.log("💰 POSMainView: Opening cash modal...");
    openCashModal();
  };

  const handleUPIPayment = () => {
    console.log("📱 POSMainView: UPI payment clicked!");
    console.log("📱 POSMainView: Cart items:", cart.length);
    console.log("📱 POSMainView: UPI payment not implemented yet");
    // TODO: Implement UPI payment
  };

  const handleCreditPayment = () => {
    console.log("💳 POSMainView: Credit payment clicked!");
    console.log("💳 POSMainView: Cart items:", cart.length);
    console.log("💳 POSMainView: Opening credit modal...");
    openCreditModal();
  };

  const handleSplitPayment = () => {
    console.log("🔄 POSMainView: Split payment clicked!");
    console.log("🔄 POSMainView: Cart items:", cart.length);
    console.log("🔄 POSMainView: Opening split modal...");
    openSplitModal();
  };

  const handlePendingPayment = () => {
    console.log("⏳ POSMainView: Pending payment clicked!");
    console.log("⏳ POSMainView: Cart items:", cart.length);
    console.log("⏳ POSMainView: Opening pending modal...");
    openPendingModal();
  };

  const handlePaymentComplete = () => {
    console.log("✅ POSMainView: Payment completed, clearing cart");
    clearCart();
    closeAllPaymentModals();
  };

  const toggleMobileCart = () => {
    setShowMobileCart(!showMobileCart);
  };

  return (
    <div className="flex h-screen bg-gray-50 dark:bg-gray-900">
      {/* Mobile Cart Button */}
      <div className="lg:hidden fixed bottom-4 right-4 z-50">
        <Button
          onClick={toggleMobileCart}
          className="rounded-full h-14 w-14 bg-blue-600 hover:bg-blue-700 shadow-lg"
        >
          <div className="relative">
            <ShoppingCart className="h-6 w-6" />
            {cart.length > 0 && (
              <Badge className="absolute -top-2 -right-2 h-5 w-5 rounded-full p-0 flex items-center justify-center text-xs bg-red-500">
                {cart.length}
              </Badge>
            )}
          </div>
        </Button>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Mobile Header */}
        <div className="lg:hidden bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 px-4 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Package className="h-6 w-6 text-blue-600" />
              <span className="font-semibold text-gray-900 dark:text-gray-100">POS System</span>
            </div>
            
            {onToggleToasts && (
              <div className="flex items-center gap-2">
                <div className="flex items-center gap-1">
                  {showToasts ? (
                    <Bell className="h-4 w-4 text-green-600" />
                  ) : (
                    <BellOff className="h-4 w-4 text-gray-400" />
                  )}
                </div>
                <Switch
                  checked={showToasts}
                  onCheckedChange={onToggleToasts}
                  className="data-[state=checked]:bg-green-600"
                />
              </div>
            )}
          </div>
        </div>

        {/* Product Grid */}
        <div className="flex-1 p-4 overflow-auto">
          <POSProductGrid
            searchTerm={searchTerm}
            setSearchTerm={setSearchTerm}
            selectedCategory={selectedCategory}
            setSelectedCategory={setSelectedCategory}
            categories={categories}
            filteredProducts={filteredProducts}
            selectedShopId={selectedShopId}
            onAddToCart={addToCart}
            showSearch={showSearch}
          />
        </div>
      </div>

      {/* Desktop Cart Sidebar */}
      <div className="hidden lg:block">
        <POSCartSidebar
          cart={cart}
          updateQuantity={updateQuantity}
          removeFromCart={removeFromCart}
          clearCart={clearCart}
          getTotalAmount={getTotalAmount}
          onCashPayment={handleCashPayment}
          onUPIPayment={handleUPIPayment}
          onCreditPayment={handleCreditPayment}
          onSplitPayment={handleSplitPayment}
          onPendingPayment={handlePendingPayment}
        />
      </div>

      {/* Mobile Cart Overlay */}
      {showMobileCart && (
        <div className="lg:hidden fixed inset-0 z-40 bg-black bg-opacity-50" onClick={toggleMobileCart}>
          <div className="absolute right-0 top-0 h-full w-80 bg-white dark:bg-gray-800" onClick={(e) => e.stopPropagation()}>
            <POSCartSidebar
              cart={cart}
              updateQuantity={updateQuantity}
              removeFromCart={removeFromCart}
              clearCart={clearCart}
              getTotalAmount={getTotalAmount}
              onCashPayment={handleCashPayment}
              onUPIPayment={handleUPIPayment}
              onCreditPayment={handleCreditPayment}
              onSplitPayment={handleSplitPayment}
              onPendingPayment={handlePendingPayment}
            />
          </div>
        </div>
      )}

      {/* Payment Modals */}
      <POSModals
        products={posProducts}
        showCashModal={modalStates.showCashModal}
        showCreditModal={modalStates.showCreditModal}
        showSplitModal={modalStates.showSplitModal}
        showPendingModal={modalStates.showPendingModal}
        showQuickStockModal={modalStates.showQuickStockModal}
        cart={cart}
        totalAmount={getTotalAmount()}
        storeInfo={storeInfo}
        selectedShopId={selectedShopId}
        onCloseCash={closeCashModal}
        onCloseCredit={closeCreditModal}
        onCloseSplit={closeSplitModal}
        onClosePending={closePendingModal}
        onCloseQuickStock={closeQuickStockModal}
        onPaymentComplete={handlePaymentComplete}
        onStockUpdated={onStockAdded}
        showToasts={showToasts}
      />
    </div>
  );
};
