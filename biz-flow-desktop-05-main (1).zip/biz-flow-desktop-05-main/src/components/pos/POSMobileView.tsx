
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Search, Package, ShoppingCart, User, History } from "lucide-react";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";

interface Product {
  id: string;
  name: string;
  price: number;
  category: string;
  quantity?: number;
}

interface CartItem {
  id: string;
  name: string;
  price: number;
  quantity: number;
  total: number;
}

interface POSMobileViewProps {
  products: Product[];
  cart: CartItem[];
  totalAmount: number;
  isLoading: boolean;
  showMobileCart: boolean;
  onAddToCart: (product: any) => void;
  onUpdateQuantity: (id: string, quantity: number) => void;
  onRemoveFromCart: (id: string) => void;
  onClearCart: () => void;
  onShowCash: () => void;
  onShowCredit: () => void;
  onShowSplit: () => void;
  onShowPending: () => void;
  onShowQuickStock: () => void;
  onShowStoreInfo: () => void;
  onToggleCart: () => void;
}

export const POSMobileView: React.FC<POSMobileViewProps> = ({
  products,
  cart,
  totalAmount,
  isLoading,
  showMobileCart,
  onAddToCart,
  onUpdateQuantity,
  onRemoveFromCart,
  onClearCart,
  onShowCash,
  onShowCredit,
  onShowSplit,
  onShowPending,
  onShowQuickStock,
  onShowStoreInfo,
  onToggleCart
}) => {
  // Internal state for mobile view
  const [searchTerm, setSearchTerm] = React.useState("");
  const [selectedCategory, setSelectedCategory] = React.useState("all");

  // Get unique categories
  const categories = ["all", ...new Set(products.map(product => product.category))];
  
  // Filter products based on search term and category
  const filteredProducts = products.filter(product => {
    const matchesTerm = product.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === "all" || product.category === selectedCategory;
    return matchesTerm && matchesCategory;
  });

  // Sample store info
  const storeInfo = {
    storeName: "ABC Cafe",
    salespersonName: "John Doe",
    shiftName: "Morning Shift"
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-blue-50 flex flex-col overflow-hidden">
      {/* Professional Mobile Header */}
      <div className="bg-white/95 backdrop-blur-sm border-b border-slate-200 shadow-sm px-4 py-4">
        <div className="flex justify-between items-center mb-4">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-blue-700 rounded-xl flex items-center justify-center shadow-lg">
              <img 
                src="/lovable-uploads/c1c145c9-7010-4fbf-9b2d-d46663dadb23.png" 
                alt="Logo" 
                className="h-6 w-6"
              />
            </div>
            <div>
              <h1 className="text-lg font-bold bg-gradient-to-r from-slate-800 to-slate-600 bg-clip-text text-transparent">
                ABC CAFE POS
              </h1>
              {storeInfo && (
                <p className="text-xs text-slate-600 font-medium">{storeInfo.storeName}</p>
              )}
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <Button
              variant="outline"
              size="sm"
              onClick={onShowQuickStock}
              className="p-2 bg-white hover:bg-blue-50 border-slate-200 text-slate-700 rounded-lg shadow-sm"
            >
              <Package className="h-4 w-4" />
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={onShowStoreInfo}
              className="p-2 bg-white hover:bg-green-50 border-slate-200 text-slate-700 rounded-lg shadow-sm"
            >
              <User className="h-4 w-4" />
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={onToggleCart}
              className="p-2 bg-white hover:bg-purple-50 border-slate-200 text-slate-700 rounded-lg shadow-sm"
            >
              <ShoppingCart className="h-4 w-4" />
              {cart.length > 0 && (
                <span className="ml-1 text-xs">{cart.length}</span>
              )}
            </Button>
          </div>
        </div>

        {/* Professional Mobile Search */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 h-4 w-4" />
          <Input
            placeholder="Search products..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 h-11 border-slate-200 focus:border-blue-500 rounded-lg bg-white/90 backdrop-blur-sm shadow-sm"
          />
        </div>
      </div>

      <div className="flex flex-1 overflow-hidden">
        {/* Professional Mobile Category Sidebar */}
        <div className="w-14 bg-white/90 backdrop-blur-sm border-r border-slate-200 flex flex-col py-3 space-y-1 shadow-sm">
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setSelectedCategory(category)}
              className={`mx-1 px-1 py-3 text-xs font-bold rounded-lg whitespace-nowrap transition-all duration-300 shadow-sm ${
                selectedCategory === category
                  ? "bg-gradient-to-r from-blue-600 to-blue-700 text-white shadow-md"
                  : "text-slate-600 hover:text-slate-900 bg-slate-50 hover:bg-slate-100"
              }`}
              title={category === "all" ? "All" : category}
            >
              {category === "all" ? "ALL" : category.substring(0, 3).toUpperCase()}
            </button>
          ))}
        </div>

        {/* Professional Mobile Products Grid */}
        <div className="flex-1 overflow-y-auto p-3 bg-gradient-to-br from-slate-50/30 to-blue-50/30">
          {filteredProducts.length === 0 ? (
            <div className="text-center py-16 text-slate-500">
              <div className="w-20 h-20 mx-auto mb-6 bg-white/80 backdrop-blur-sm rounded-full flex items-center justify-center shadow-lg">
                <Search className="h-10 w-10 text-slate-400" />
              </div>
              <h3 className="text-xl font-bold mb-3 text-slate-700">No products found</h3>
              <p className="text-base text-slate-400">Try adjusting your search or category filter</p>
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-3">
              {filteredProducts.map((product) => (
                <Card 
                  key={product.id} 
                  className={`cursor-pointer transition-all duration-300 group hover:shadow-xl transform hover:scale-105 ${
                    product.quantity !== undefined && product.quantity <= 0 
                      ? 'border-red-200 bg-gradient-to-br from-red-50 to-red-100 opacity-80' 
                      : 'border-slate-200 bg-white/90 backdrop-blur-sm hover:border-blue-300 shadow-sm hover:bg-white'
                  }`}
                  onClick={() => onAddToCart(product)}
                >
                  <CardContent className="p-3">
                    <h4 className="font-semibold text-xs leading-tight mb-3 text-slate-800 line-clamp-2 min-h-[2rem]">
                      {product.name}
                    </h4>
                    
                    {product.quantity !== undefined && (
                      <div className="mb-2">
                        <Badge 
                          variant="outline" 
                          className={`text-xs py-0.5 px-1.5 font-semibold shadow-sm ${
                            product.quantity > 10 
                              ? 'bg-green-50 text-green-700 border-green-200' 
                              : product.quantity > 0 
                                ? 'bg-amber-50 text-amber-700 border-amber-200'
                                : 'bg-red-50 text-red-700 border-red-200'
                          }`}
                        >
                          {product.quantity}
                        </Badge>
                      </div>
                    )}
                    
                    <div className="bg-gradient-to-r from-slate-800 to-slate-700 text-white px-2 py-1.5 rounded-lg text-center shadow-md">
                      <p className="text-xs font-bold">
                        ₹{Number(product.price).toFixed(2)}
                      </p>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Mobile Cart Sheet */}
      <Sheet open={showMobileCart} onOpenChange={onToggleCart}>
        <SheetContent side="right" className="w-full sm:w-[400px]">
          <div className="flex flex-col h-full">
            <div className="flex-1 space-y-4">
              <h2 className="text-lg font-semibold">Cart ({cart.length} items)</h2>
              
              {cart.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  Your cart is empty
                </div>
              ) : (
                <div className="space-y-3">
                  {cart.map((item) => (
                    <Card key={item.id}>
                      <CardContent className="p-3">
                        <div className="flex justify-between items-start mb-2">
                          <h4 className="font-medium text-sm">{item.name}</h4>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => onRemoveFromCart(item.id)}
                            className="text-red-500 hover:text-red-700 p-1"
                          >
                            ×
                          </Button>
                        </div>
                        <div className="flex justify-between items-center">
                          <div className="flex items-center space-x-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => onUpdateQuantity(item.id, item.quantity - 1)}
                              className="h-6 w-6 p-0"
                            >
                              -
                            </Button>
                            <span className="text-sm font-medium">{item.quantity}</span>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => onUpdateQuantity(item.id, item.quantity + 1)}
                              className="h-6 w-6 p-0"
                            >
                              +
                            </Button>
                          </div>
                          <span className="font-semibold">₹{item.total.toFixed(2)}</span>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </div>

            {cart.length > 0 && (
              <div className="border-t pt-4 space-y-3">
                <div className="flex justify-between items-center text-lg font-bold">
                  <span>Total:</span>
                  <span>₹{totalAmount.toFixed(2)}</span>
                </div>
                
                <div className="grid grid-cols-2 gap-2">
                  <Button onClick={onShowCash} className="w-full">
                    Cash
                  </Button>
                  <Button onClick={onShowCredit} variant="outline" className="w-full">
                    Credit
                  </Button>
                </div>
                
                <div className="grid grid-cols-2 gap-2">
                  <Button onClick={onShowSplit} variant="outline" className="w-full">
                    Split
                  </Button>
                  <Button onClick={onShowPending} variant="outline" className="w-full">
                    Pending
                  </Button>
                </div>
                
                <Button 
                  onClick={onClearCart} 
                  variant="destructive" 
                  className="w-full"
                >
                  Clear Cart
                </Button>
              </div>
            )}
          </div>
        </SheetContent>
      </Sheet>
    </div>
  );
};
