
import { useState } from "react";
import { CartItem, StoreInfo, POSSystemStateProps } from "@/types/pos";
import { usePOSModals } from "@/hooks/usePOSModals";

export const usePOSSystemState = ({
  propStoreInfo,
  propSelectedShopId,
  propSelectedShiftId
}: POSSystemStateProps) => {
  // selectedShopId is now fixed based on the prop (user's assigned store)
  const selectedShopId = propSelectedShopId;
  const [cart, setCart] = useState<CartItem[]>([]);
  const [storeInfo, setStoreInfo] = useState<StoreInfo | null>(propStoreInfo);

  // Use the shared modal management hook
  const modalManagement = usePOSModals();

  return {
    selectedShopId,
    cart,
    setCart,
    storeInfo,
    setStoreInfo,
    // Spread all modal management functionality
    ...modalManagement
  };
};
