
import React, { useEffect, useRef } from "react";

interface POSPopupManagerProps {
  onPopupCheck: (isPopup: boolean) => void;
}

export const POSPopupManager: React.FC<POSPopupManagerProps> = ({ onPopupCheck }) => {
  const hasChecked = useRef(false);

  useEffect(() => {
    // Only run this check once
    if (hasChecked.current) return;
    hasChecked.current = true;

    console.log('🔍 [POSPopupManager] Starting popup check...');
    console.log('🔍 [POSPopupManager] Current URL:', window.location.href);
    console.log('🔍 [POSPopupManager] Current pathname:', window.location.pathname);

    const urlParams = new URLSearchParams(window.location.search);
    const isPopupFromUrl = urlParams.get('popup') === 'true';
    const checkIfPopup = window.opener !== null || window.name === 'POSWindow' || isPopupFromUrl;
    
    console.log('🔍 [POSPopupManager] URL popup param:', isPopupFromUrl);
    console.log('🔍 [POSPopupManager] Window opener:', window.opener);
    console.log('🔍 [POSPopupManager] Window name:', window.name);
    console.log('🔍 [POSPopupManager] Is already popup?', checkIfPopup);
    
    onPopupCheck(checkIfPopup);
    
    // If we're on /pos route and NOT already in a popup, open popup
    const isOnPOSRoute = window.location.pathname === '/pos';
    const shouldOpenPopup = isOnPOSRoute && !checkIfPopup;
    
    console.log('🔍 [POSPopupManager] Should open popup?', shouldOpenPopup);
    console.log('🔍 [POSPopupManager] Is on POS route?', isOnPOSRoute);
    console.log('🔍 [POSPopupManager] Not in popup?', !checkIfPopup);
    
    if (shouldOpenPopup) {
      console.log('🚀 [POSPopupManager] OPENING POPUP NOW!');
      
      // Use setTimeout to ensure DOM is ready
      setTimeout(() => {
        try {
          const currentUrl = window.location.href;
          const popupUrl = currentUrl.includes('?') ? 
            `${currentUrl}&popup=true` : 
            `${currentUrl}?popup=true`;
          
          console.log('🪟 [POSPopupManager] Opening popup with URL:', popupUrl);
          
          const popupFeatures = [
            'width=1400',
            'height=900',
            'scrollbars=yes',
            'resizable=yes',
            'toolbar=no',
            'menubar=no',
            'location=no',
            'status=no',
            'left=100',
            'top=100'
          ].join(',');
          
          const popup = window.open(popupUrl, 'POSWindow', popupFeatures);
          
          console.log('🪟 [POSPopupManager] window.open returned:', popup);
          
          if (popup) {
            popup.focus();
            console.log('✅ [POSPopupManager] Popup opened successfully!');
            
            // Close original window after confirming popup is open
            setTimeout(() => {
              if (!popup.closed) {
                console.log('🪟 [POSPopupManager] Closing original window');
                window.close();
              } else {
                console.warn('⚠️ [POSPopupManager] Popup was closed, not closing original');
              }
            }, 1000);
            
          } else {
            console.error('❌ [POSPopupManager] Popup was blocked by browser!');
            alert('Pop-up blocked! Please allow pop-ups for this site and try again.\n\nTo enable pop-ups:\n1. Click the popup blocker icon in your address bar\n2. Select "Always allow pop-ups from this site"\n3. Refresh the page');
          }
        } catch (error) {
          console.error('❌ [POSPopupManager] Error opening popup:', error);
          alert('Failed to open POS popup. Please check your browser settings and try again.');
        }
      }, 100);
    } else {
      console.log('ℹ️ [POSPopupManager] Not opening popup - either not on POS route or already in popup');
    }
  }, []); // Empty dependency array - only run once

  return null;
};
