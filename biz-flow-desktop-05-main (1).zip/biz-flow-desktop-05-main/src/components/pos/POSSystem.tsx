
import React, { useEffect, useState } from "react";
import { useAuth } from "@/context/AuthContext";
import { usePOSProducts } from "@/hooks/usePOSProducts";
import { usePOSModals } from "@/hooks/usePOSModals";
import POSHeader from "./POSHeader";
import { POSMobileView } from "./POSMobileView";
import { POSModals } from "./POSModals";
import { QuickStockUpdateModal } from "./QuickStockUpdateModal";
import { StoreInfoModal } from "./StoreInfoModal";
import { toast } from "sonner";
import { usePOSCartOperations } from "./POSCartOperations";
import { StoreInfo } from "@/types/pos";

interface POSSystemProps {
  products?: any[];
  storeInfo?: StoreInfo | null;
  selectedShopId?: string;
  selectedShiftId?: string;
  onStockUpdated?: () => void;
  showToasts?: boolean;
  onToggleToasts?: (enabled: boolean) => void;
}

const POSSystem: React.FC<POSSystemProps> = ({
  products: propProducts = [],
  storeInfo: propStoreInfo = null,
  selectedShopId: propSelectedShopId = "",
  selectedShiftId: propSelectedShiftId = "",
  onStockUpdated: propOnStockUpdated = () => {},
  showToasts: propShowToasts = true,
  onToggleToasts: propOnToggleToasts = () => {}
}) => {
  const { user } = useAuth();
  const [showToasts, setShowToasts] = useState(propShowToasts);
  const [selectedShopId] = useState(propSelectedShopId);
  const [storeInfo, setStoreInfo] = useState<StoreInfo | null>(propStoreInfo);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [showActualStockModal, setShowActualStockModal] = useState(false);
  
  // Use the new modal management hook
  const {
    modalStates,
    openCashModal,
    closeCashModal,
    openCreditModal,
    closeCreditModal,
    openSplitModal,
    closeSplitModal,
    openPendingModal,
    closePendingModal,
    openQuickStockModal,
    closeQuickStockModal,
    openStoreInfoModal,
    closeStoreInfoModal,
    toggleMobileCart,
    closeAllPaymentModals
  } = usePOSModals();

  const [cart, setCart] = useState<any[]>([]);

  const {
    addToCart,
    updateCartQuantity,
    removeFromCart,
    clearCart,
    totalAmount
  } = usePOSCartOperations({ cart, setCart });

  // Use the POS products hook
  const { 
    products: fetchedProducts, 
    shops, 
    isLoading, 
    error, 
    refetchProducts,
    handleStockAdded
  } = usePOSProducts(selectedShopId);

  // Use fetched products if available, otherwise use prop products, otherwise empty array
  const products = fetchedProducts && fetchedProducts.length > 0 ? fetchedProducts : 
                   propProducts.length > 0 ? propProducts : [];

  // Handle manual refresh
  const handleRefresh = async () => {
    setIsRefreshing(true);
    try {
      await refetchProducts();
      if (showToasts) {
        toast.success("Products refreshed successfully!");
      }
    } catch (error) {
      if (showToasts) {
        toast.error("Failed to refresh products");
      }
    } finally {
      setIsRefreshing(false);
    }
  };

  // Handle toast toggle
  const handleToggleToasts = (enabled: boolean) => {
    console.log("🔔 Toggle toasts called with:", enabled);
    setShowToasts(enabled);
    
    // If disabling toasts, dismiss any existing ones
    if (!enabled) {
      console.log("🔔 Dismissing all toasts");
      toast.dismiss();
    }
    
    propOnToggleToasts(enabled);
  };

  const handlePaymentComplete = () => {
    clearCart();
    closeAllPaymentModals();
    if (showToasts) {
      toast.success("Payment processed successfully!");
    }
  };

  const handleStockUpdated = () => {
    handleStockAdded();
    propOnStockUpdated();
    if (showToasts) {
      toast.success("Stock updated successfully!");
    }
  };

  const handleActualStockUpdated = () => {
    handleStockAdded();
    propOnStockUpdated();
    setShowActualStockModal(false);
    if (showToasts) {
      toast.success("Actual stock updated successfully!");
    }
  };

  // Get current store info for display
  const currentStore = shops?.find(shop => shop.id === selectedShopId);

  if (error) {
    return (
      <div className="p-4 text-center">
        <p className="text-red-600">Error loading POS data: {error.message}</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <POSHeader
        cartItemsCount={cart.length}
        onShowQuickStock={openQuickStockModal}
        onShowActualStock={() => setShowActualStockModal(true)}
        onToggleCart={toggleMobileCart}
        showMobileCart={modalStates.showMobileCart}
        storeName={currentStore?.name || storeInfo?.storeName}
        storeCode={currentStore?.store_code}
        showToasts={showToasts}
        onToggleToasts={handleToggleToasts}
        onRefresh={handleRefresh}
        isRefreshing={isRefreshing}
      />

      {/* Mobile View */}
      <div className="min-h-screen">
        <POSMobileView
          products={products}
          cart={cart}
          totalAmount={totalAmount}
          isLoading={isLoading}
          showMobileCart={modalStates.showMobileCart}
          onAddToCart={addToCart}
          onUpdateQuantity={updateCartQuantity}
          onRemoveFromCart={removeFromCart}
          onClearCart={clearCart}
          onShowCash={openCashModal}
          onShowCredit={openCreditModal}
          onShowSplit={openSplitModal}
          onShowPending={openPendingModal}
          onShowQuickStock={openQuickStockModal}
          onShowStoreInfo={openStoreInfoModal}
          onToggleCart={toggleMobileCart}
        />
      </div>

      {/* All Modals */}
      <POSModals
        showCashModal={modalStates.showCashModal}
        showCreditModal={modalStates.showCreditModal}
        showSplitModal={modalStates.showSplitModal}
        showPendingModal={modalStates.showPendingModal}
        showQuickStockModal={modalStates.showQuickStockModal}
        cart={cart}
        products={products}
        totalAmount={totalAmount}
        storeInfo={storeInfo}
        selectedShopId={selectedShopId}
        onCloseCash={closeCashModal}
        onCloseCredit={closeCreditModal}
        onCloseSplit={closeSplitModal}
        onClosePending={closePendingModal}
        onCloseQuickStock={closeQuickStockModal}
        onPaymentComplete={handlePaymentComplete}
        onStockUpdated={handleStockUpdated}
      />

      {/* Actual Stock Update Modal */}
      <QuickStockUpdateModal
        isOpen={showActualStockModal}
        onClose={() => setShowActualStockModal(false)}
        products={products}
        selectedShopId={selectedShopId}
        onStockUpdated={handleActualStockUpdated}
      />

      <StoreInfoModal
        isOpen={modalStates.showStoreInfoModal}
        onClose={closeStoreInfoModal}
        onComplete={(info, shiftId, storeId) => {
          setStoreInfo(info);
          closeStoreInfoModal();
        }}
      />
    </div>
  );
};

export default POSSystem;
