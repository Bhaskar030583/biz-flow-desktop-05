import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Minus, Plus, Trash2, Calculator, CreditCard, Banknote, SplitSquareHorizontal, Clock, Smartphone, Percent } from "lucide-react";

interface CartItem {
  id: string;
  name: string;
  price: number;
  quantity: number;
  total: number;
}

interface POSCartSidebarProps {
  cart: CartItem[];
  updateQuantity: (productId: string, newQuantity: number) => void;
  removeFromCart: (productId: string) => void;
  clearCart: () => void;
  getTotalAmount: () => number;
  onCashPayment: () => void;
  onUPIPayment: () => void;
  onCreditPayment: () => void;
  onSplitPayment: () => void;
  onPendingPayment: () => void;
}

export const POSCartSidebar: React.FC<POSCartSidebarProps> = ({
  cart,
  updateQuantity,
  removeFromCart,
  clearCart,
  getTotalAmount,
  onCashPayment,
  onUPIPayment,
  onCreditPayment,
  onSplitPayment,
  onPendingPayment
}) => {
  const [discountType, setDiscountType] = useState<'percentage' | 'value'>('percentage');
  const [discountValue, setDiscountValue] = useState<number>(0);

  const subtotal = getTotalAmount();
  
  const calculateDiscount = () => {
    if (discountType === 'percentage') {
      return (subtotal * discountValue) / 100;
    }
    return Math.min(discountValue, subtotal);
  };

  const discountAmount = calculateDiscount();
  const finalTotal = subtotal - discountAmount;
  const isCartEmpty = cart.length === 0;

  const resetDiscount = () => {
    setDiscountValue(0);
  };

  // Enhanced payment handlers with debugging
  const handleCashPayment = () => {
    console.log("💰 Cash payment button clicked!");
    console.log("💰 Cart items:", cart.length);
    console.log("💰 Is cart empty:", isCartEmpty);
    console.log("💰 onCashPayment function:", typeof onCashPayment);
    
    if (isCartEmpty) {
      console.log("💰 Cart is empty, cannot proceed");
      return;
    }
    
    console.log("💰 Calling onCashPayment...");
    onCashPayment();
  };

  const handleUPIPayment = () => {
    console.log("📱 UPI payment button clicked!");
    console.log("📱 Cart items:", cart.length);
    console.log("📱 Is cart empty:", isCartEmpty);
    console.log("📱 onUPIPayment function:", typeof onUPIPayment);
    
    if (isCartEmpty) {
      console.log("📱 Cart is empty, cannot proceed");
      return;
    }
    
    console.log("📱 Calling onUPIPayment...");
    onUPIPayment();
  };

  const handleCreditPayment = () => {
    console.log("💳 Credit payment button clicked!");
    console.log("💳 Cart items:", cart.length);
    console.log("💳 Is cart empty:", isCartEmpty);
    console.log("💳 onCreditPayment function:", typeof onCreditPayment);
    
    if (isCartEmpty) {
      console.log("💳 Cart is empty, cannot proceed");
      return;
    }
    
    console.log("💳 Calling onCreditPayment...");
    onCreditPayment();
  };

  const handleSplitPayment = () => {
    console.log("🔄 Split payment button clicked!");
    console.log("🔄 Cart items:", cart.length);
    console.log("🔄 Is cart empty:", isCartEmpty);
    console.log("🔄 onSplitPayment function:", typeof onSplitPayment);
    
    if (isCartEmpty) {
      console.log("🔄 Cart is empty, cannot proceed");
      return;
    }
    
    console.log("🔄 Calling onSplitPayment...");
    onSplitPayment();
  };

  const handlePendingPayment = () => {
    console.log("⏳ Pending payment button clicked!");
    console.log("⏳ Cart items:", cart.length);
    console.log("⏳ Is cart empty:", isCartEmpty);
    console.log("⏳ onPendingPayment function:", typeof onPendingPayment);
    
    if (isCartEmpty) {
      console.log("⏳ Cart is empty, cannot proceed");
      return;
    }
    
    console.log("⏳ Calling onPendingPayment...");
    onPendingPayment();
  };

  return (
    <div className="w-80 bg-white dark:bg-gray-800 border-l border-gray-200 dark:border-gray-700 flex flex-col">
      <Card className="h-full flex flex-col">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-sm">
            <Calculator className="h-4 w-4" />
            Order Summary ({cart.length})
          </CardTitle>
        </CardHeader>

        <CardContent className="flex-1 flex flex-col">
          {/* Cart Items */}
          <div className="flex-1 space-y-2 max-h-64 overflow-y-auto mb-4">
            {cart.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-8 text-gray-500">
                <Calculator className="h-12 w-12 mb-3 opacity-50" />
                <p className="text-center">No items in cart</p>
              </div>
            ) : (
              cart.map((item) => (
                <div key={item.id} className="bg-gray-50 dark:bg-gray-700 rounded-lg p-2">
                  <div className="flex items-center justify-between gap-2">
                    {/* Product name and price */}
                    <div className="flex-1 min-w-0">
                      <h4 className="font-medium text-xs truncate">{item.name}</h4>
                      <p className="text-xs text-gray-500">₹{item.price.toFixed(2)}</p>
                    </div>
                    
                    {/* Quantity controls */}
                    <div className="flex items-center gap-1">
                      <Button
                        size="sm"
                        variant="outline"
                        className="h-6 w-6 p-0"
                        onClick={() => updateQuantity(item.id, item.quantity - 1)}
                      >
                        <Minus className="h-3 w-3" />
                      </Button>
                      <Badge variant="secondary" className="min-w-[24px] text-center text-xs px-1">
                        {item.quantity}
                      </Badge>
                      <Button
                        size="sm"
                        variant="outline"
                        className="h-6 w-6 p-0"
                        onClick={() => updateQuantity(item.id, item.quantity + 1)}
                      >
                        <Plus className="h-3 w-3" />
                      </Button>
                    </div>
                    
                    {/* Total and remove button */}
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-green-600 text-xs">₹{item.total.toFixed(2)}</span>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => removeFromCart(item.id)}
                        className="text-red-500 hover:text-red-700 p-1 h-6 w-6"
                      >
                        <Trash2 className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Discount Section */}
          {cart.length > 0 && (
            <div className="bg-amber-50 dark:bg-amber-900/20 rounded-lg p-3 mb-4 border border-amber-200 dark:border-amber-800">
              <div className="flex items-center gap-2 mb-3">
                <Percent className="h-4 w-4 text-amber-600" />
                <Label className="text-sm font-medium text-amber-800 dark:text-amber-200">Apply Discount</Label>
              </div>
              
              <div className="grid grid-cols-2 gap-2 mb-2">
                <Select value={discountType} onValueChange={(value) => setDiscountType(value as 'percentage' | 'value')}>
                  <SelectTrigger className="h-8 text-xs">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="percentage">% Off</SelectItem>
                    <SelectItem value="value">₹ Off</SelectItem>
                  </SelectContent>
                </Select>
                
                <div className="flex gap-1">
                  <Input
                    type="number"
                    placeholder="0"
                    value={discountValue || ''}
                    onChange={(e) => setDiscountValue(Number(e.target.value) || 0)}
                    className="h-8 text-xs"
                    min="0"
                    max={discountType === 'percentage' ? 100 : subtotal}
                  />
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={resetDiscount}
                    className="h-8 px-2 text-xs"
                  >
                    Clear
                  </Button>
                </div>
              </div>
              
              {discountAmount > 0 && (
                <div className="text-xs text-amber-700 dark:text-amber-300 font-medium">
                  Discount: -{discountType === 'percentage' ? `${discountValue}%` : `₹${discountValue.toFixed(2)}`} = ₹{discountAmount.toFixed(2)}
                </div>
              )}
            </div>
          )}

          {/* Total Section */}
          <div className="border-t pt-4 mb-4 space-y-2">
            <div className="flex justify-between items-center text-sm">
              <span>Subtotal:</span>
              <span>₹{subtotal.toFixed(2)}</span>
            </div>
            {discountAmount > 0 && (
              <div className="flex justify-between items-center text-sm text-red-600">
                <span>Discount:</span>
                <span>-₹{discountAmount.toFixed(2)}</span>
              </div>
            )}
            <Separator />
            <div className="flex justify-between items-center text-lg font-bold">
              <span>Total:</span>
              <span className="text-green-600">₹{finalTotal.toFixed(2)}</span>
            </div>
          </div>

          {/* Payment Buttons */}
          <div className="grid grid-cols-5 gap-2">
            <Button
              className="bg-green-600 hover:bg-green-700 text-white p-2 h-10 w-full"
              onClick={handleCashPayment}
              disabled={isCartEmpty}
            >
              <Banknote className="h-5 w-5" />
            </Button>
            
            <Button
              className="bg-blue-600 hover:bg-blue-700 text-white p-2 h-10 w-full"
              onClick={handleUPIPayment}
              disabled={isCartEmpty}
            >
              <Smartphone className="h-5 w-5" />
            </Button>
            
            <Button
              className="bg-purple-600 hover:bg-purple-700 text-white p-2 h-10 w-full"
              onClick={handleCreditPayment}
              disabled={isCartEmpty}
            >
              <CreditCard className="h-5 w-5" />
            </Button>
            
            <Button
              className="bg-orange-600 hover:bg-orange-700 text-white p-2 h-10 w-full"
              onClick={handleSplitPayment}
              disabled={isCartEmpty}
            >
              <SplitSquareHorizontal className="h-5 w-5" />
            </Button>
            
            <Button
              className="bg-amber-600 hover:bg-amber-700 text-white p-2 h-10 w-full"
              onClick={handlePendingPayment}
              disabled={isCartEmpty}
            >
              <Clock className="h-5 w-5" />
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
