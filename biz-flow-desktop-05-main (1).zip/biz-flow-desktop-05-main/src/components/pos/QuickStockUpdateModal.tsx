
import React, { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { toast } from "sonner";
import { Plus, Search, CheckCircle } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/context/AuthContext";
import { useQueryClient } from "@tanstack/react-query";
import { format } from "date-fns";

interface Product {
  id: string;
  name: string;
  price: number;
  category: string;
  quantity?: number;
  expectedClosing?: number;
  actualStock?: number;
  sku?: string;
}

interface QuickStockUpdateModalProps {
  isOpen: boolean;
  onClose: () => void;
  products: Product[];
  selectedShopId: string;
  onStockUpdated: () => void;
}

export const QuickStockUpdateModal: React.FC<QuickStockUpdateModalProps> = ({
  isOpen,
  onClose,
  products,
  selectedShopId,
  onStockUpdated
}) => {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [actualStockUpdates, setActualStockUpdates] = useState<Record<string, number>>({});
  const [isUpdating, setIsUpdating] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [stockDate] = useState(format(new Date(), 'yyyy-MM-dd'));

  // Filter products based on search term (search by name, SKU, or category)
  const filteredProducts = products.filter(product =>
    product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (product.sku && product.sku.toLowerCase().includes(searchTerm.toLowerCase())) ||
    product.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleActualStockChange = (productId: string, value: string) => {
    const quantity = parseInt(value) || 0;
    setActualStockUpdates(prev => ({
      ...prev,
      [productId]: quantity
    }));
  };

  const updateActualStock = async (productId: string, actualStock: number) => {
    if (!user?.id) {
      toast.error("User not authenticated");
      return;
    }

    console.log('📦 [QuickStock] Updating actual stock:', {
      productId,
      selectedShopId,
      actualStock,
      userId: user.id
    });

    const today = new Date().toISOString().split('T')[0];
    
    // Get current stock record using hr_shop_id (trying both shop_id and hr_shop_id for compatibility)
    const { data: currentStock, error: fetchError } = await supabase
      .from('stocks')
      .select('*')
      .eq('product_id', productId)
      .or(`hr_shop_id.eq.${selectedShopId},shop_id.eq.${selectedShopId}`)
      .eq('user_id', user.id)
      .eq('stock_date', today)
      .maybeSingle();
    
    console.log('📦 [QuickStock] Current stock found:', currentStock);
    
    if (fetchError) {
      console.error('Error fetching current stock:', fetchError);
      throw fetchError;
    }
    
    if (currentStock) {
      // Update existing stock record - update actual_stock directly
      console.log('📦 [QuickStock] Updating existing stock record with actual stock:', actualStock);

      const { error: updateError } = await supabase
        .from('stocks')
        .update({
          actual_stock: actualStock,
          closing_stock: actualStock // Also update closing stock to match actual
        })
        .eq('id', currentStock.id);
      
      if (updateError) {
        console.error('Error updating actual stock:', updateError);
        throw updateError;
      }

      console.log('✅ [QuickStock] Actual stock updated successfully');
    } else {
      // Create new stock record if none exists for today
      console.log('📦 [QuickStock] Creating new stock record with actual stock');

      const { error: insertError } = await supabase
        .from('stocks')
        .insert({
          product_id: productId,
          shop_id: selectedShopId, // Keep for backward compatibility
          hr_shop_id: selectedShopId, // Use hr_shop_id as primary field
          stock_date: today,
          opening_stock: 0, // Start with 0 if no previous record
          closing_stock: actualStock, // Set to the actual stock
          actual_stock: actualStock, // Set to the actual stock
          stock_added: 0, // No stock added in this case
          user_id: user.id
        });
      
      if (insertError) {
        console.error('Error creating stock record:', insertError);
        throw insertError;
      }

      console.log('✅ [QuickStock] New stock record created with actual stock');
    }
  };

  const handleUpdateActualStock = async (productId: string) => {
    const actualStock = actualStockUpdates[productId];
    if (actualStock === undefined || actualStock < 0) {
      toast.error("Please enter a valid actual stock quantity");
      return;
    }

    setIsUpdating(true);
    try {
      await updateActualStock(productId, actualStock);
      
      toast.success("Actual stock updated successfully");
      
      // Clear the input for this product
      setActualStockUpdates(prev => ({
        ...prev,
        [productId]: 0
      }));
      
      // Invalidate all relevant queries to refresh data
      queryClient.invalidateQueries({ queryKey: ['pos-products'] });
      queryClient.invalidateQueries({ queryKey: ['product-stock-management'] });
      queryClient.invalidateQueries({ queryKey: ['stocks'] });
      queryClient.invalidateQueries({ queryKey: ['assigned-products'] });
      
      // Notify parent to refresh data
      onStockUpdated();
    } catch (error) {
      console.error('Error updating actual stock:', error);
      toast.error("Failed to update actual stock");
    } finally {
      setIsUpdating(false);
    }
  };

  const handleUpdateAllActualStock = async () => {
    const updatesNeeded = Object.entries(actualStockUpdates).filter(([_, actualStock]) => actualStock !== undefined && actualStock >= 0);
    
    if (updatesNeeded.length === 0) {
      toast.error("No actual stock updates to process");
      return;
    }

    if (!user?.id) {
      toast.error("User not authenticated");
      return;
    }

    setIsUpdating(true);
    try {
      for (const [productId, actualStock] of updatesNeeded) {
        await updateActualStock(productId, actualStock);
      }
      
      toast.success(`Updated actual stock for ${updatesNeeded.length} products`);
      setActualStockUpdates({});
      
      // Invalidate all relevant queries to refresh data
      queryClient.invalidateQueries({ queryKey: ['pos-products'] });
      queryClient.invalidateQueries({ queryKey: ['product-stock-management'] });
      queryClient.invalidateQueries({ queryKey: ['stocks'] });
      queryClient.invalidateQueries({ queryKey: ['assigned-products'] });
      
      onStockUpdated();
      onClose();
    } catch (error) {
      console.error('Error updating actual stock:', error);
      toast.error("Failed to update some actual stock items");
    } finally {
      setIsUpdating(false);
    }
  };

  const handleClose = () => {
    onClose();
    setSearchTerm("");
    setActualStockUpdates({});
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-6xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-3 text-base font-semibold text-gray-800">
            <div className="p-1.5 bg-blue-100 rounded-md">
              <CheckCircle className="h-4 w-4 text-blue-600" />
            </div>
            <div className="flex-1">
              <span>Verify Actual Stock - Update Physical Count</span>
              <div className="text-xs font-normal text-gray-600">
                {products.length} {products.length === 1 ? 'product' : 'products'} • Date: {stockDate}
              </div>
            </div>
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          {/* Search Input */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 dark:text-gray-500 h-4 w-4" />
            <Input
              placeholder="Search by Product Name, SKU, or Category..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-600"
            />
          </div>
          
          {products.length === 0 ? (
            <div className="text-center py-8 bg-gray-50 rounded-lg border border-gray-200">
              <div className="w-12 h-12 mx-auto mb-3 bg-gray-100 rounded-full flex items-center justify-center">
                <CheckCircle className="h-6 w-6 text-gray-400" />
              </div>
              <h3 className="text-base font-medium text-gray-700 mb-2">No Products Available</h3>
              <p className="text-sm text-gray-500 max-w-md mx-auto">
                No products are available for this store. Please assign products to get started.
              </p>
            </div>
          ) : filteredProducts.length === 0 ? (
            <div className="text-center py-8 text-gray-500 dark:text-gray-400">
              No products match your search
            </div>
          ) : (
            <div className="space-y-4">
              {/* Table Header */}
              <div className="grid grid-cols-6 gap-4 p-3 bg-gray-100 dark:bg-gray-800 rounded-lg font-medium text-sm">
                <div>Date</div>
                <div>SKU</div>
                <div>Product Name</div>
                <div>Category</div>
                <div>Expected Closing</div>
                <div>Actual Stock</div>
              </div>
              
              {/* Table Rows */}
              <div className="space-y-2 max-h-96 overflow-y-auto">
                {filteredProducts.map((product) => {
                  const expectedClosing = product.expectedClosing || product.quantity || 0;
                  const currentActualStock = actualStockUpdates[product.id] !== undefined ? actualStockUpdates[product.id] : expectedClosing;
                  
                  return (
                    <div key={product.id} className="grid grid-cols-6 gap-4 p-3 bg-white border border-gray-200 rounded-lg items-center">
                      {/* Date */}
                      <div className="text-sm text-gray-600">
                        {stockDate}
                      </div>
                      
                      {/* SKU */}
                      <div className="text-sm font-mono text-gray-600">
                        {product.sku || 'N/A'}
                      </div>
                      
                      {/* Product Name */}
                      <div>
                        <h4 className="font-medium text-gray-900 text-sm">{product.name}</h4>
                      </div>
                      
                      {/* Category */}
                      <div>
                        <Badge variant="outline" className="text-xs border-gray-200 text-gray-600">
                          {product.category}
                        </Badge>
                      </div>
                      
                      {/* Expected Closing */}
                      <div>
                        <Badge 
                          variant="outline" 
                          className="text-xs bg-blue-50 text-blue-700 border-blue-200"
                        >
                          {expectedClosing}
                        </Badge>
                      </div>
                      
                      {/* Actual Stock Input */}
                      <div className="flex items-center gap-2">
                        <div className="w-20">
                          <Input
                            type="number"
                            min="0"
                            placeholder={expectedClosing.toString()}
                            value={currentActualStock.toString()}
                            onChange={(e) => handleActualStockChange(product.id, e.target.value)}
                            className="text-center bg-white border-gray-200 text-sm h-8"
                          />
                        </div>
                        <Button
                          size="sm"
                          onClick={() => handleUpdateActualStock(product.id)}
                          disabled={actualStockUpdates[product.id] === undefined || isUpdating}
                          className="px-3 h-8"
                        >
                          <CheckCircle className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
          
          <div className="flex justify-between items-center pt-4 border-t border-gray-200 dark:border-gray-600">
            <Button variant="outline" onClick={handleClose}>
              Cancel
            </Button>
            <Button 
              onClick={handleUpdateAllActualStock}
              disabled={isUpdating || Object.keys(actualStockUpdates).length === 0}
            >
              {isUpdating ? "Updating..." : "Update All Actual Stock"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};
