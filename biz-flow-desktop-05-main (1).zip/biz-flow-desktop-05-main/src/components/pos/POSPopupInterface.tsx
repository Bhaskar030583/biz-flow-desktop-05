
import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ShoppingCart, Package, Bell, BellOff, X, CheckCircle } from "lucide-react";
import { POSMainView } from "./POSMainView";
import { QuickStockUpdateModal } from "./QuickStockUpdateModal";
import { StoreInfoModal } from "./StoreInfoModal";
import { StoreInfo } from "@/types/pos";
import { useAuth } from "@/context/AuthContext";

interface POSPopupInterfaceProps {
  shouldShowStoreModal: boolean;
  storeInfoCompleted: boolean;
  selectedStoreId: string;
  productsLoading: boolean;
  products: any[];
  storeInfo: StoreInfo | null;
  selectedShiftId: string;
  onStoreInfoComplete: (info: StoreInfo, shiftId: string, storeId: string) => void;
  onStoreModalClose: () => void;
  onClosePopup: () => void;
  onStockUpdated: () => void;
  showSearch: boolean;
  toggleSearch: () => void;
}

export const POSPopupInterface: React.FC<POSPopupInterfaceProps> = ({
  shouldShowStoreModal,
  storeInfoCompleted,
  selectedStoreId,
  productsLoading,
  products,
  storeInfo,
  selectedShiftId,
  onStoreInfoComplete,
  onStoreModalClose,
  onClosePopup,
  onStockUpdated,
  showSearch,
  toggleSearch
}) => {
  const [showToasts, setShowToasts] = useState(true);
  const [showActualStockModal, setShowActualStockModal] = useState(false);
  const { user, userRole } = useAuth();
  const userInitials = user?.email ? user.email.substring(0, 2).toUpperCase() : "US";
  const userName = user?.user_metadata?.full_name || user?.email?.split('@')[0] || 'User';

  const handleToggleToasts = (enabled: boolean) => {
    console.log("🔔 Popup: Toggle toasts called with:", enabled);
    setShowToasts(enabled);
    
    // If disabling toasts, dismiss any existing ones
    if (!enabled) {
      console.log("🔔 Popup: Dismissing all toasts");
      // Import toast dynamically to avoid issues
      import("sonner").then(({ toast }) => {
        toast.dismiss();
      });
    }
  };

  const handleActualStockUpdated = () => {
    onStockUpdated();
    setShowActualStockModal(false);
    if (showToasts) {
      import("sonner").then(({ toast }) => {
        toast.success("Actual stock updated successfully!");
      });
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Popup Header */}
      <div className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 px-4 py-3">
        <div className="flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <img 
              src="/lovable-uploads/ed799d5e-33fc-4ae2-a120-07c3961fcd47.png" 
              alt="ABC Cafe Logo" 
              className="h-10 w-auto"
            />
            {storeInfo?.storeName && (
              <Badge variant="outline" className="text-xs border-gray-300 dark:border-gray-600">
                {storeInfo.storeName}
              </Badge>
            )}
          </div>

          <div className="flex items-center gap-3">
            {/* Actual Stock Update Button */}
            {storeInfoCompleted && !productsLoading && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowActualStockModal(true)}
                className="flex items-center gap-2 bg-green-50 dark:bg-green-950 border-green-200 dark:border-green-800 text-green-700 dark:text-green-300 hover:bg-green-100 dark:hover:bg-green-900"
              >
                <CheckCircle className="h-4 w-4" />
                <span className="hidden sm:inline">Update Actual Stock</span>
              </Button>
            )}

            {/* User Info */}
            <div className="flex items-center gap-2 bg-gray-50 dark:bg-gray-700 px-3 py-2 rounded-lg border border-gray-200 dark:border-gray-600">
              <Avatar className="h-6 w-6">
                <AvatarImage src={user?.user_metadata?.avatar_url || ""} alt="User" />
                <AvatarFallback className="bg-primary text-primary-foreground text-xs">
                  {userInitials}
                </AvatarFallback>
              </Avatar>
              <div className="flex flex-col">
                <span className="text-sm font-medium text-gray-900 dark:text-gray-100 truncate max-w-24">
                  {userName}
                </span>
                <span className="text-xs text-gray-500 dark:text-gray-400 capitalize">
                  {userRole}
                </span>
              </div>
            </div>

            {/* Notification Toggle */}
            <div className="flex items-center gap-2">
              <div className="flex items-center gap-1">
                {showToasts ? (
                  <Bell className="h-4 w-4 text-green-600" />
                ) : (
                  <BellOff className="h-4 w-4 text-gray-400" />
                )}
              </div>
              <Switch
                checked={showToasts}
                onCheckedChange={handleToggleToasts}
                className="data-[state=checked]:bg-green-600"
              />
              <span className="text-xs text-gray-600 dark:text-gray-400 hidden sm:inline">
                {showToasts ? 'On' : 'Off'}
              </span>
            </div>

            <Button
              variant="outline"
              onClick={onClosePopup}
              className="flex items-center gap-2 bg-white dark:bg-gray-700 border-gray-300 dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-gray-600 text-gray-900 dark:text-gray-100"
            >
              <X className="h-4 w-4" />
              <span className="hidden sm:inline">Close</span>
            </Button>
          </div>
        </div>
      </div>

      {/* Store Info Modal */}
      {shouldShowStoreModal && (
        <StoreInfoModal
          isOpen={shouldShowStoreModal}
          onComplete={onStoreInfoComplete}
          onClose={onStoreModalClose}
        />
      )}

      {/* Main POS Content */}
      {storeInfoCompleted && !productsLoading && (
        <POSMainView
          products={products}
          onStockAdded={onStockUpdated}
          showSearch={showSearch}
          toggleSearch={toggleSearch}
          showToasts={showToasts}
          onToggleToasts={handleToggleToasts}
          selectedShopId={selectedStoreId}
          storeInfo={storeInfo}
        />
      )}

      {/* Actual Stock Update Modal */}
      <QuickStockUpdateModal
        isOpen={showActualStockModal}
        onClose={() => setShowActualStockModal(false)}
        products={products}
        selectedShopId={selectedStoreId}
        onStockUpdated={handleActualStockUpdated}
      />

      {/* Loading State */}
      {productsLoading && (
        <div className="flex items-center justify-center h-64">
          <div className="text-gray-500">Loading products...</div>
        </div>
      )}
    </div>
  );
};
