import React, { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Banknote, Calculator, Lightbulb, AlertTriangle, ArrowLeftRight } from "lucide-react";
import { generateBill } from "@/services/billService";
import { useDenominations } from "@/hooks/useDenominations";
import { DenominationExchangeModal } from "./DenominationExchangeModal";
import { toast } from "sonner";

interface CashPaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  totalAmount: number;
  onPaymentComplete: () => void;
  cartItems: Array<{
    id: string;
    name: string;
    price: number;
    quantity: number;
    total: number;
  }>;
  storeInfo?: {
    storeName: string;
    salespersonName: string;
  } | null;
  selectedShopId?: string;
  terminalId?: string;
}

interface Denominations {
  [key: string]: number;
}

export const CashPaymentModal: React.FC<CashPaymentModalProps> = ({
  isOpen,
  onClose,
  totalAmount,
  onPaymentComplete,
  cartItems,
  storeInfo,
  selectedShopId,
  terminalId = 'main'
}) => {
  const [cashReceived, setCashReceived] = useState("");
  const [processing, setProcessing] = useState(false);
  const [useDetailedDenominations, setUseDetailedDenominations] = useState(false);
  const [showExchangeModal, setShowExchangeModal] = useState(false);
  const [finalChangeGiven, setFinalChangeGiven] = useState<Denominations>({});
  const [receivedDenominations, setReceivedDenominations] = useState<Denominations>({
    "500": 0, "200": 0, "100": 0, "50": 0, "20": 0, "10": 0, "5": 0, "2": 0, "1": 0
  });

  const denominationHook = useDenominations(selectedShopId, terminalId);
  const { 
    currentDenominations, 
    getOptimalChange, 
    canGiveExactChange, 
    recordCashReceived, 
    recordChangeGiven 
  } = denominationHook;

  const denominationValues = [500, 200, 100, 50, 20, 10, 5, 2, 1];

  const calculateTotalFromDenominations = () => {
    return denominationValues.reduce((total, value) => {
      return total + (value * (receivedDenominations[value.toString()] || 0));
    }, 0);
  };

  const cashAmount = useDetailedDenominations ? calculateTotalFromDenominations() : (parseFloat(cashReceived) || 0);
  const changeAmount = cashAmount - totalAmount;

  // Get suggested change breakdown
  const suggestedChange = changeAmount > 0 ? getOptimalChange(changeAmount) : {};
  const canGiveChange = changeAmount > 0 ? canGiveExactChange(changeAmount) : true;

  const handleDenominationChange = (value: number, count: string) => {
    const numCount = parseInt(count) || 0;
    setReceivedDenominations(prev => ({
      ...prev,
      [value.toString()]: numCount
    }));
  };

  const handleSwitchChange = (checked: boolean) => {
    setUseDetailedDenominations(checked);
    if (!checked) {
      setReceivedDenominations({
        "500": 0, "200": 0, "100": 0, "50": 0, "20": 0, "10": 0, "5": 0, "2": 0, "1": 0
      });
    } else {
      setCashReceived("");
    }
  };

  const handleExchangeConfirm = (actualChange: Denominations) => {
    setFinalChangeGiven(actualChange);
    setShowExchangeModal(false);
  };

  const handlePayment = async () => {
    if (cashAmount < totalAmount) {
      toast.error("Cash received is less than total amount");
      return;
    }

    if (changeAmount > 0 && !canGiveChange) {
      toast.error("Cannot give exact change with available denominations");
      return;
    }

    // If there's change and no custom exchange has been set, show exchange modal
    if (changeAmount > 0 && Object.keys(suggestedChange).length > 0 && Object.keys(finalChangeGiven).length === 0) {
      setShowExchangeModal(true);
      return;
    }

    setProcessing(true);
    try {
      const bill = await generateBill({
        totalAmount,
        paymentMethod: 'cash',
        cartItems,
        storeName: storeInfo?.storeName,
        salespersonName: storeInfo?.salespersonName
      });

      if (bill && selectedShopId) {
        // Record the cash received
        if (useDetailedDenominations) {
          await recordCashReceived(receivedDenominations, bill.id);
        } else {
          // Convert cash received to denomination breakdown (simplified)
          const breakdown: Denominations = {};
          let remaining = Math.round(cashAmount);
          for (const value of denominationValues) {
            const count = Math.floor(remaining / value);
            if (count > 0) {
              breakdown[value.toString()] = count;
              remaining -= value * count;
            }
          }
          await recordCashReceived(breakdown, bill.id);
        }

        // Record change given - use final change given or suggested change
        const changeToRecord = Object.keys(finalChangeGiven).length > 0 ? finalChangeGiven : suggestedChange;
        if (changeAmount > 0 && Object.keys(changeToRecord).length > 0) {
          await recordChangeGiven(changeToRecord, bill.id);
        }

        let toastMessage = "Cash payment completed!";
        if (useDetailedDenominations) {
          const denominationSummary = denominationValues
            .filter(value => receivedDenominations[value.toString()] > 0)
            .map(value => `₹${value} x ${receivedDenominations[value.toString()]}`)
            .join(', ');
          toastMessage += ` Received: ${denominationSummary}`;
        }

        if (Object.keys(finalChangeGiven).length > 0) {
          const changeSummary = denominationValues
            .filter(value => finalChangeGiven[value.toString()] > 0)
            .map(value => `₹${value} x ${finalChangeGiven[value.toString()]}`)
            .join(', ');
          toastMessage += ` Change: ${changeSummary}`;
        }

        toast.success(toastMessage);
        onPaymentComplete();
        handleClose();
      }
    } catch (error) {
      console.error("Error processing cash payment:", error);
      toast.error("Failed to process cash payment");
    } finally {
      setProcessing(false);
    }
  };

  const handleClose = () => {
    setCashReceived("");
    setReceivedDenominations({
      "500": 0, "200": 0, "100": 0, "50": 0, "20": 0, "10": 0, "5": 0, "2": 0, "1": 0
    });
    setUseDetailedDenominations(false);
    setFinalChangeGiven({});
    onClose();
  };

  return (
    <>
      <Dialog open={isOpen} onOpenChange={handleClose}>
        <DialogContent className="sm:max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Banknote className="h-5 w-5" />
              Cash Payment
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="total-amount">Total Amount</Label>
              <div className="text-2xl font-bold text-green-600">
                ₹{totalAmount.toFixed(2)}
              </div>
            </div>

            <Separator />

            {/* Available Denominations Info */}
            {selectedShopId && Object.keys(currentDenominations).length > 0 && (
              <div className="bg-blue-50 p-4 rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  <Lightbulb className="h-4 w-4 text-blue-600" />
                  <span className="text-sm font-medium text-blue-800">Available in Register</span>
                </div>
                <div className="flex flex-wrap gap-2">
                  {denominationValues.map(value => {
                    const count = currentDenominations[value.toString()] || 0;
                    return (
                      <Badge 
                        key={value} 
                        variant={count > 0 ? "default" : "secondary"}
                        className={count > 0 ? "bg-blue-100 text-blue-800" : "bg-gray-100 text-gray-500"}
                      >
                        ₹{value}: {count}
                      </Badge>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Denomination Toggle Switch */}
            <div className="flex items-center space-x-2">
              <Switch
                id="denomination-mode"
                checked={useDetailedDenominations}
                onCheckedChange={handleSwitchChange}
              />
              <Label htmlFor="denomination-mode" className="text-sm font-medium">
                Use denomination breakdown
              </Label>
            </div>

            <Separator />

            {useDetailedDenominations ? (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Cash Received Section */}
                <div className="space-y-3">
                  <Label className="text-lg font-semibold">Cash Denominations Received</Label>
                  <div className="grid grid-cols-3 gap-3">
                    {denominationValues.map(value => (
                      <div key={value} className="space-y-1">
                        <Label htmlFor={`denom-${value}`} className="text-sm font-medium">
                          ₹{value} notes
                        </Label>
                        <Input
                          id={`denom-${value}`}
                          type="number"
                          min="0"
                          value={receivedDenominations[value.toString()]}
                          onChange={(e) => handleDenominationChange(value, e.target.value)}
                          placeholder="0"
                          className="text-center"
                        />
                        <div className="text-xs text-gray-500 text-center">
                          = ₹{(value * (receivedDenominations[value.toString()] || 0)).toFixed(0)}
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="space-y-2 mt-4">
                    <Label htmlFor="total-cash">Total Cash Received</Label>
                    <div className="text-xl font-bold text-blue-600">
                      ₹{calculateTotalFromDenominations().toFixed(2)}
                    </div>
                  </div>
                </div>

                {/* Change to Return Section */}
                {changeAmount > 0 && (
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <Label className="text-lg font-semibold">Change to Return</Label>
                      {Object.keys(suggestedChange).length > 0 && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setShowExchangeModal(true)}
                          className="flex items-center gap-2"
                        >
                          <ArrowLeftRight className="h-4 w-4" />
                          Exchange
                        </Button>
                      )}
                    </div>
                    
                    {!canGiveChange && (
                      <div className="flex items-center gap-2 p-3 bg-red-50 border border-red-200 rounded-lg">
                        <AlertTriangle className="h-4 w-4 text-red-600" />
                        <span className="text-sm text-red-700">
                          Cannot give exact change with available denominations
                        </span>
                      </div>
                    )}

                    <div className="text-xl font-bold text-blue-600 mb-3">
                      ₹{changeAmount.toFixed(2)}
                    </div>
                    
                    <div className="space-y-2">
                      <Label className="text-base font-medium">
                        {Object.keys(finalChangeGiven).length > 0 ? 'Final Change Given:' : 'Suggested Breakdown:'}
                      </Label>
                      <div className="grid grid-cols-3 gap-2">
                        {denominationValues.map(value => {
                          const changeBreakdown = Object.keys(finalChangeGiven).length > 0 ? finalChangeGiven : suggestedChange;
                          const count = changeBreakdown[value.toString()] || 0;
                          const available = currentDenominations[value.toString()] || 0;
                          
                          if (count === 0 && available === 0) return null;
                          
                          return (
                            <div 
                              key={value} 
                              className={`p-2 rounded border text-center ${
                                count > available ? 'bg-red-50 border-red-200' : 'bg-gray-50 border-gray-200'
                              }`}
                            >
                              <div className="text-sm font-medium">₹{value}</div>
                              <div className={`text-lg font-bold ${
                                count > available ? 'text-red-600' : 'text-blue-600'
                              }`}>
                                {count}
                              </div>
                              <div className="text-xs text-gray-500">
                                = ₹{(value * count).toFixed(0)}
                              </div>
                              {count > available && (
                                <div className="text-xs text-red-500">
                                  Need {count - available} more
                                </div>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                )}

                {changeAmount < 0 && cashAmount > 0 && (
                  <div className="space-y-3">
                    <Label className="text-lg font-semibold text-red-600">Insufficient Cash</Label>
                    <div className="text-xl font-bold text-red-600">
                      Short by: ₹{Math.abs(changeAmount).toFixed(2)}
                    </div>
                  </div>
                )}
              </div>
            ) : (
              /* Simple Cash Input Mode */
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="cash-received">Cash Received</Label>
                  <Input
                    id="cash-received"
                    type="number"
                    min="0"
                    step="0.01"
                    value={cashReceived}
                    onChange={(e) => setCashReceived(e.target.value)}
                    placeholder="Enter cash amount"
                    className="text-lg"
                  />
                </div>

                {changeAmount > 0 && (
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label>Change to Return</Label>
                      {Object.keys(suggestedChange).length > 0 && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setShowExchangeModal(true)}
                          className="flex items-center gap-2"
                        >
                          <ArrowLeftRight className="h-4 w-4" />
                          Exchange
                        </Button>
                      )}
                    </div>
                    <div className="text-xl font-bold text-blue-600">
                      ₹{changeAmount.toFixed(2)}
                    </div>
                    
                    {!canGiveChange && (
                      <div className="flex items-center gap-2 p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                        <AlertTriangle className="h-4 w-4 text-yellow-600" />
                        <span className="text-sm text-yellow-700">
                          May not be able to give exact change with available denominations
                        </span>
                      </div>
                    )}

                    {/* Show final change given if set */}
                    {Object.keys(finalChangeGiven).length > 0 && (
                      <div className="bg-green-50 p-3 rounded-lg">
                        <Label className="text-sm font-medium text-green-800">Final Change Given:</Label>
                        <div className="flex flex-wrap gap-2 mt-1">
                          {denominationValues.map(value => {
                            const count = finalChangeGiven[value.toString()] || 0;
                            if (count === 0) return null;
                            return (
                              <Badge key={value} variant="outline" className="bg-green-100 text-green-800">
                                ₹{value} × {count}
                              </Badge>
                            );
                          })}
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {changeAmount < 0 && cashAmount > 0 && (
                  <div className="space-y-2">
                    <Label className="text-red-600">Insufficient Cash</Label>
                    <div className="text-xl font-bold text-red-600">
                      Short by: ₹{Math.abs(changeAmount).toFixed(2)}
                    </div>
                  </div>
                )}
              </div>
            )}

            <div className="flex gap-2 pt-4">
              <Button variant="outline" onClick={handleClose} className="flex-1">
                Cancel
              </Button>
              <Button
                onClick={handlePayment}
                disabled={cashAmount < totalAmount || processing || (changeAmount > 0 && !canGiveChange)}
                className="flex-1 bg-green-600 hover:bg-green-700"
              >
                <Calculator className="h-4 w-4 mr-2" />
                {processing ? "Processing..." : "Complete Payment"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Denomination Exchange Modal */}
      <DenominationExchangeModal
        isOpen={showExchangeModal}
        onClose={() => setShowExchangeModal(false)}
        suggestedChange={suggestedChange}
        onExchangeConfirm={handleExchangeConfirm}
        currentDenominations={currentDenominations}
      />
    </>
  );
};
