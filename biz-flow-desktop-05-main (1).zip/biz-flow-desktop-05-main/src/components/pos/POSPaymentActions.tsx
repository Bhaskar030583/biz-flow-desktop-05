import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface PaymentActionsConfig {
  cart: any[];
  products: any[];
  selectedShopId: string;
  storeInfo: any;
  userId: string;
  onStockUpdated: () => void;
  showToasts: boolean;
}

export const createPaymentActions = (config: PaymentActionsConfig) => {
  const {
    cart,
    products,
    selectedShopId,
    storeInfo,
    userId,
    onStockUpdated,
    showToasts
  } = config;

  const consumeRecipeIngredients = async (cartItems: any[]) => {
    try {
      for (const item of cartItems) {
        const { error } = await supabase.rpc('consume_recipe_ingredients', {
          p_product_id: item.id,
          p_quantity: item.quantity,
          p_shop_id: selectedShopId,
          p_user_id: userId
        });

        if (error) {
          console.error('Error consuming recipe ingredients:', error);
          if (showToasts) {
            toast.error(`Failed to update ingredient stock for ${item.name}`);
          }
        }
      }
    } catch (error) {
      console.error('Error in consumeRecipeIngredients:', error);
    }
  };

  const handleCashPayment = async (): Promise<boolean> => {
    try {
      console.log('🏪 Processing cash payment with recipe consumption');
      
      if (!cart.length) {
        if (showToasts) toast.error("Cart is empty");
        return false;
      }

      if (!selectedShopId || !userId) {
        if (showToasts) toast.error("Store or user information missing");
        return false;
      }

      // First, consume recipe ingredients
      await consumeRecipeIngredients(cart);

      // Generate bill number
      const { data: billNumber, error: billNumberError } = await supabase.rpc('generate_bill_number');
      if (billNumberError) throw billNumberError;

      // Create bill
      const { data: bill, error: billError } = await supabase
        .from('bills')
        .insert({
          bill_number: billNumber,
          total_amount: cart.reduce((sum, item) => sum + item.total, 0),
          payment_method: 'cash',
          payment_status: 'completed',
          user_id: userId,
          customer_id: null
        })
        .select()
        .single();

      if (billError) throw billError;

      // Create bill items
      const billItems = cart.map(item => ({
        bill_id: bill.id,
        product_id: item.id,
        product_name: item.name,
        quantity: item.quantity,
        unit_price: item.price,
        total_price: item.total
      }));

      const { error: itemsError } = await supabase
        .from('bill_items')
        .insert(billItems);

      if (itemsError) throw itemsError;

      if (showToasts) {
        toast.success("Cash payment completed successfully!");
      }

      onStockUpdated();
      return true;

    } catch (error) {
      console.error('Cash payment error:', error);
      if (showToasts) {
        toast.error(`Payment failed: ${error.message}`);
      }
      return false;
    }
  };

  const handleCreditPayment = async (customerId: string, customerName?: string): Promise<boolean> => {
    try {
      console.log('💳 Processing credit payment with recipe consumption');
      
      if (!cart.length) {
        if (showToasts) toast.error("Cart is empty");
        return false;
      }

      const totalAmount = cart.reduce((sum, item) => sum + item.total, 0);

      // Check credit limit
      const { data: canMakeCredit, error: creditCheckError } = await supabase.rpc(
        'can_make_credit_purchase',
        { customer_id_param: customerId, purchase_amount: totalAmount }
      );

      if (creditCheckError) throw creditCheckError;

      if (!canMakeCredit) {
        if (showToasts) toast.error("Credit limit exceeded for this customer");
        return false;
      }

      // First, consume recipe ingredients
      await consumeRecipeIngredients(cart);

      // Generate bill number
      const { data: billNumber, error: billNumberError } = await supabase.rpc('generate_bill_number');
      if (billNumberError) throw billNumberError;

      // Create bill
      const { data: bill, error: billError } = await supabase
        .from('bills')
        .insert({
          bill_number: billNumber,
          total_amount: totalAmount,
          payment_method: 'credit',
          payment_status: 'completed',
          user_id: userId,
          customer_id: customerId
        })
        .select()
        .single();

      if (billError) throw billError;

      // Create bill items
      const billItems = cart.map(item => ({
        bill_id: bill.id,
        product_id: item.id,
        product_name: item.name,
        quantity: item.quantity,
        unit_price: item.price,
        total_price: item.total
      }));

      const { error: itemsError } = await supabase
        .from('bill_items')
        .insert(billItems);

      if (itemsError) throw itemsError;

      // Create credit transaction
      const { error: creditError } = await supabase
        .from('credit_transactions')
        .insert({
          customer_id: customerId,
          amount: totalAmount,
          status: 'pending',
          description: `Bill #${billNumber} - ${customerName || 'Credit Sale'}`,
          user_id: userId
        });

      if (creditError) throw creditError;

      if (showToasts) {
        toast.success(`Credit payment completed for ${customerName || 'customer'}!`);
      }

      onStockUpdated();
      return true;

    } catch (error) {
      console.error('Credit payment error:', error);
      if (showToasts) {
        toast.error(`Credit payment failed: ${error.message}`);
      }
      return false;
    }
  };

  return {
    handleCashPayment,
    handleCreditPayment
  };
};
