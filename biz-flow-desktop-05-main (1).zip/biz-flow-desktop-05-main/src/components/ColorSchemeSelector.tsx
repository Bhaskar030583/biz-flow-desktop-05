
import React from 'react';
import { Palette, Sparkles, Sun, Moon, Zap } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from '@/components/ui/dropdown-menu';
import { useSettings } from '@/context/SettingsContext';

export function ColorSchemeSelector() {
  const { colorTheme, setColorTheme } = useSettings();

  const colorSchemes = [
    {
      id: 'default',
      name: 'Ocean Blue',
      icon: Sun,
      description: 'Classic blue and white theme',
      preview: 'bg-gradient-to-r from-blue-500 to-blue-600'
    },
    {
      id: 'professional',
      name: 'Professional',
      icon: Moon,
      description: 'Clean and minimal design',
      preview: 'bg-gradient-to-r from-slate-600 to-slate-700'
    },
    {
      id: 'modern',
      name: 'Electric Green',
      icon: Zap,
      description: 'Modern and fresh look',
      preview: 'bg-gradient-to-r from-emerald-500 to-teal-600'
    },
    {
      id: 'vibrant',
      name: 'Vibrant Sunset',
      icon: Sparkles,
      description: 'Colorful and energetic',
      preview: 'bg-gradient-to-r from-orange-500 via-pink-500 to-purple-600'
    }
  ];

  const currentScheme = colorSchemes.find(scheme => scheme.id === colorTheme) || colorSchemes[0];
  const CurrentIcon = currentScheme.icon;

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button 
          variant="outline" 
          size="sm" 
          className="gap-2 bg-card/80 backdrop-blur-sm border border-border hover:bg-accent shadow-sm hover:shadow-md transition-all duration-200"
        >
          <Palette className="h-4 w-4 text-primary" />
          <span className="hidden sm:inline font-medium text-foreground">{currentScheme.name}</span>
          <CurrentIcon className="h-3 w-3 text-muted-foreground" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent 
        align="end" 
        className="w-56 bg-card border border-border shadow-xl rounded-xl p-2"
      >
        <div className="px-2 py-1.5 text-sm font-semibold text-foreground">
          Choose Color Scheme
        </div>
        <DropdownMenuSeparator className="bg-border" />
        
        {colorSchemes.map((scheme) => {
          const Icon = scheme.icon;
          const isActive = colorTheme === scheme.id;
          
          return (
            <DropdownMenuItem
              key={scheme.id}
              onClick={() => setColorTheme(scheme.id as any)}
              className={`cursor-pointer rounded-lg p-3 my-1 transition-all duration-200 ${
                isActive 
                  ? 'bg-primary/10 text-primary border border-primary/20' 
                  : 'hover:bg-accent text-foreground'
              }`}
            >
              <div className="flex items-center gap-3 w-full">
                <div className={`w-8 h-8 rounded-lg ${scheme.preview} flex items-center justify-center shadow-sm`}>
                  <Icon className="h-4 w-4 text-white" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="font-medium text-sm">{scheme.name}</div>
                  <div className="text-xs text-muted-foreground truncate">{scheme.description}</div>
                </div>
                {isActive && (
                  <div className="w-2 h-2 bg-primary rounded-full flex-shrink-0" />
                )}
              </div>
            </DropdownMenuItem>
          );
        })}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
