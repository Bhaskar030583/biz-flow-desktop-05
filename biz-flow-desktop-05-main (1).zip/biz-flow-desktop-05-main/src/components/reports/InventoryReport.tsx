
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Download, Package, AlertTriangle, TrendingDown, DollarSign } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

const InventoryReport = () => {
  const { data: stocksData, isLoading: stocksLoading } = useQuery({
    queryKey: ['stocks-report'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('stocks')
        .select(`
          *,
          products(name, price, cost_price, category)
        `)
        .order('stock_date', { ascending: false });

      if (error) throw error;
      return data || [];
    },
  });

  const { data: lowStockAlerts } = useQuery({
    queryKey: ['low-stock-alerts'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('low_stock_alerts')
        .select(`
          *,
          products(name, category)
        `)
        .eq('is_resolved', false);

      if (error) throw error;
      return data || [];
    },
  });

  const { data: lossesData } = useQuery({
    queryKey: ['losses-report'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('losses')
        .select(`
          *,
          products(name, price)
        `);

      if (error) throw error;
      return data || [];
    },
  });

  // Calculate inventory metrics
  const totalProducts = stocksData?.length || 0;
  const totalStockValue = stocksData?.reduce((sum, stock) => {
    const price = stock.products?.price || 0;
    return sum + (stock.actual_stock * Number(price));
  }, 0) || 0;

  const totalCostValue = stocksData?.reduce((sum, stock) => {
    const costPrice = stock.products?.cost_price || 0;
    return sum + (stock.actual_stock * Number(costPrice));
  }, 0) || 0;

  const totalLossValue = lossesData?.reduce((sum, loss) => {
    const price = loss.products?.price || 0;
    return sum + (loss.quantity_lost * Number(price));
  }, 0) || 0;

  // Category-wise stock distribution
  const categoryData = stocksData?.reduce((acc, stock) => {
    const category = stock.products?.category || 'Other';
    if (!acc[category]) {
      acc[category] = { quantity: 0, value: 0 };
    }
    acc[category].quantity += stock.actual_stock;
    acc[category].value += stock.actual_stock * Number(stock.products?.price || 0);
    return acc;
  }, {} as Record<string, { quantity: number; value: number }>);

  const categoryChartData = Object.entries(categoryData || {}).map(([category, data]) => ({
    name: category,
    quantity: data.quantity,
    value: data.value
  }));

  // Low stock products
  const lowStockProducts = stocksData?.filter(stock => stock.actual_stock <= 10) || [];

  // Top products by value
  const topProductsByValue = stocksData?.map(stock => ({
    name: stock.products?.name || 'Unknown',
    quantity: stock.actual_stock,
    value: stock.actual_stock * Number(stock.products?.price || 0),
    category: stock.products?.category || 'Other'
  }))
  .sort((a, b) => b.value - a.value)
  .slice(0, 10) || [];

  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8'];

  if (stocksLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">Loading inventory report...</div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-start">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Inventory Report</h1>
          <p className="text-muted-foreground">
            Comprehensive inventory analysis and stock management
          </p>
        </div>
        <Button variant="outline" className="flex items-center gap-2">
          <Download className="h-4 w-4" />
          Export
        </Button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Products</CardTitle>
            <Package className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalProducts}</div>
            <p className="text-xs text-muted-foreground">unique items</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Stock Value</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">₹{totalStockValue.toFixed(2)}</div>
            <p className="text-xs text-muted-foreground">selling price</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Low Stock Alerts</CardTitle>
            <AlertTriangle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">{lowStockAlerts?.length || 0}</div>
            <p className="text-xs text-muted-foreground">items need reorder</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Loss Value</CardTitle>
            <TrendingDown className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">₹{totalLossValue.toFixed(2)}</div>
            <p className="text-xs text-muted-foreground">inventory losses</p>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Stock Distribution by Category</CardTitle>
            <CardDescription>Inventory spread across product categories</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={categoryChartData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, value }) => `${name}: ₹${value.toFixed(0)}`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {categoryChartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip formatter={(value) => [`₹${Number(value).toFixed(2)}`, 'Value']} />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Top Products by Value</CardTitle>
            <CardDescription>Most valuable inventory items</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={topProductsByValue.slice(0, 6)} layout="horizontal">
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis type="number" />
                <YAxis dataKey="name" type="category" width={80} />
                <Tooltip formatter={(value) => [`₹${Number(value).toFixed(2)}`, 'Value']} />
                <Bar dataKey="value" fill="#8884d8" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Low Stock Alerts */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-orange-600" />
            Low Stock Alerts
          </CardTitle>
          <CardDescription>Products that need immediate attention</CardDescription>
        </CardHeader>
        <CardContent>
          {lowStockProducts.length === 0 ? (
            <p className="text-center text-muted-foreground py-8">No low stock alerts at the moment</p>
          ) : (
            <div className="space-y-3">
              {lowStockProducts.slice(0, 10).map((stock) => (
                <div key={stock.id} className="flex justify-between items-center p-3 border rounded-lg bg-orange-50">
                  <div>
                    <p className="font-medium">{stock.products?.name}</p>
                    <div className="flex gap-2 mt-1">
                      <Badge variant="secondary">{stock.products?.category}</Badge>
                      <Badge variant="destructive">{stock.actual_stock} left</Badge>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-bold">₹{Number(stock.products?.price || 0).toFixed(2)}</p>
                    <p className="text-sm text-muted-foreground">per unit</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Top Products by Value */}
      <Card>
        <CardHeader>
          <CardTitle>High Value Inventory</CardTitle>
          <CardDescription>Products with highest stock value</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {topProductsByValue.map((product, index) => (
              <div key={index} className="flex justify-between items-center p-3 border rounded-lg">
                <div className="flex items-center gap-3">
                  <Badge variant="secondary">#{index + 1}</Badge>
                  <div>
                    <p className="font-medium">{product.name}</p>
                    <div className="flex gap-2 mt-1">
                      <Badge variant="outline">{product.category}</Badge>
                      <span className="text-sm text-muted-foreground">{product.quantity} units</span>
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-bold text-green-600">₹{product.value.toFixed(2)}</p>
                  <p className="text-sm text-muted-foreground">total value</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default InventoryReport;
