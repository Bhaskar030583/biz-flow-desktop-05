
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { DatePickerWithRange } from '@/components/ui/date-picker-with-range';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Download, TrendingUp, TrendingDown, DollarSign } from 'lucide-react';
import { format, subDays } from 'date-fns';
import { DateRange } from 'react-day-picker';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts';

const ProfitLossReport = () => {
  const [dateRange, setDateRange] = useState<DateRange | undefined>({
    from: subDays(new Date(), 30),
    to: new Date(),
  });

  const { data: salesData, isLoading: salesLoading } = useQuery({
    queryKey: ['sales-data', dateRange],
    queryFn: async () => {
      const startDate = dateRange?.from ? format(dateRange.from, 'yyyy-MM-dd') : format(subDays(new Date(), 30), 'yyyy-MM-dd');
      const endDate = dateRange?.to ? format(dateRange.to, 'yyyy-MM-dd') : format(new Date(), 'yyyy-MM-dd');

      const { data, error } = await supabase
        .from('bills')
        .select(`
          *,
          bill_items(*, products(cost_price))
        `)
        .gte('bill_date', startDate)
        .lte('bill_date', endDate);

      if (error) throw error;
      return data || [];
    },
  });

  const { data: expensesData, isLoading: expensesLoading } = useQuery({
    queryKey: ['expenses-data', dateRange],
    queryFn: async () => {
      const startDate = dateRange?.from ? format(dateRange.from, 'yyyy-MM-dd') : format(subDays(new Date(), 30), 'yyyy-MM-dd');
      const endDate = dateRange?.to ? format(dateRange.to, 'yyyy-MM-dd') : format(new Date(), 'yyyy-MM-dd');

      const { data, error } = await supabase
        .from('expenses')
        .select('*')
        .gte('expense_date', startDate)
        .lte('expense_date', endDate);

      if (error) throw error;
      return data || [];
    },
  });

  // Calculate revenue
  const totalRevenue = salesData?.reduce((sum, bill) => sum + Number(bill.total_amount), 0) || 0;

  // Calculate cost of goods sold (COGS)
  const totalCOGS = salesData?.reduce((sum, bill) => {
    const billCOGS = bill.bill_items?.reduce((itemSum: number, item: any) => {
      const costPrice = item.products?.cost_price || 0;
      return itemSum + (Number(costPrice) * item.quantity);
    }, 0) || 0;
    return sum + billCOGS;
  }, 0) || 0;

  // Calculate gross profit
  const grossProfit = totalRevenue - totalCOGS;
  const grossProfitMargin = totalRevenue > 0 ? (grossProfit / totalRevenue) * 100 : 0;

  // Calculate total expenses
  const totalExpenses = expensesData?.reduce((sum, expense) => sum + Number(expense.amount), 0) || 0;

  // Calculate net profit
  const netProfit = grossProfit - totalExpenses;
  const netProfitMargin = totalRevenue > 0 ? (netProfit / totalRevenue) * 100 : 0;

  // Daily profit/loss data
  const dailyData = salesData?.reduce((acc, bill) => {
    const date = format(new Date(bill.bill_date), 'MMM dd');
    if (!acc[date]) {
      acc[date] = { revenue: 0, cogs: 0, expenses: 0 };
    }
    acc[date].revenue += Number(bill.total_amount);
    
    const billCOGS = bill.bill_items?.reduce((itemSum: number, item: any) => {
      const costPrice = item.products?.cost_price || 0;
      return itemSum + (Number(costPrice) * item.quantity);
    }, 0) || 0;
    acc[date].cogs += billCOGS;
    
    return acc;
  }, {} as Record<string, { revenue: number; cogs: number; expenses: number }>);

  // Add expenses to daily data
  expensesData?.forEach(expense => {
    const date = format(new Date(expense.expense_date), 'MMM dd');
    if (dailyData && dailyData[date]) {
      dailyData[date].expenses += Number(expense.amount);
    } else if (dailyData) {
      dailyData[date] = { revenue: 0, cogs: 0, expenses: Number(expense.amount) };
    }
  });

  const chartData = Object.entries(dailyData || {}).map(([date, data]) => ({
    date,
    revenue: data.revenue,
    grossProfit: data.revenue - data.cogs,
    netProfit: data.revenue - data.cogs - data.expenses,
    expenses: data.expenses
  }));

  const isLoading = salesLoading || expensesLoading;

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">Loading profit & loss report...</div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-start">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Profit & Loss Report</h1>
          <p className="text-muted-foreground">
            Financial performance analysis and profitability metrics
          </p>
        </div>
        <div className="flex gap-2">
          <DatePickerWithRange date={dateRange} setDate={setDateRange} />
          <Button variant="outline" className="flex items-center gap-2">
            <Download className="h-4 w-4" />
            Export
          </Button>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">₹{totalRevenue.toFixed(2)}</div>
            <p className="text-xs text-muted-foreground">gross sales</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Gross Profit</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">₹{grossProfit.toFixed(2)}</div>
            <p className="text-xs text-muted-foreground">{grossProfitMargin.toFixed(1)}% margin</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Expenses</CardTitle>
            <TrendingDown className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">₹{totalExpenses.toFixed(2)}</div>
            <p className="text-xs text-muted-foreground">operating costs</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Net Profit</CardTitle>
            {netProfit >= 0 ? (
              <TrendingUp className="h-4 w-4 text-green-600" />
            ) : (
              <TrendingDown className="h-4 w-4 text-red-600" />
            )}
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${netProfit >= 0 ? 'text-green-600' : 'text-red-600'}`}>
              ₹{netProfit.toFixed(2)}
            </div>
            <p className="text-xs text-muted-foreground">{netProfitMargin.toFixed(1)}% margin</p>
          </CardContent>
        </Card>
      </div>

      {/* Profit & Loss Statement */}
      <Card>
        <CardHeader>
          <CardTitle>Profit & Loss Statement</CardTitle>
          <CardDescription>Detailed financial breakdown</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex justify-between items-center py-2 border-b">
              <span className="font-medium">Revenue</span>
              <span className="font-bold text-green-600">₹{totalRevenue.toFixed(2)}</span>
            </div>
            
            <div className="flex justify-between items-center py-2">
              <span className="text-muted-foreground ml-4">Less: Cost of Goods Sold</span>
              <span className="text-red-600">-₹{totalCOGS.toFixed(2)}</span>
            </div>
            
            <div className="flex justify-between items-center py-2 border-b border-t bg-muted/50">
              <span className="font-medium">Gross Profit</span>
              <span className="font-bold text-blue-600">₹{grossProfit.toFixed(2)}</span>
            </div>
            
            <div className="flex justify-between items-center py-2">
              <span className="text-muted-foreground ml-4">Less: Operating Expenses</span>
              <span className="text-red-600">-₹{totalExpenses.toFixed(2)}</span>
            </div>
            
            <div className="flex justify-between items-center py-3 border-t-2 border-black">
              <span className="font-bold text-lg">Net Profit</span>
              <span className={`font-bold text-lg ${netProfit >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                ₹{netProfit.toFixed(2)}
              </span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Profit Trend</CardTitle>
            <CardDescription>Daily profit/loss over selected period</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip formatter={(value, name) => [`₹${Number(value).toFixed(2)}`, name]} />
                <Line type="monotone" dataKey="grossProfit" stroke="#3b82f6" name="Gross Profit" />
                <Line type="monotone" dataKey="netProfit" stroke="#10b981" name="Net Profit" />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Revenue vs Expenses</CardTitle>
            <CardDescription>Daily comparison of income and costs</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip formatter={(value, name) => [`₹${Number(value).toFixed(2)}`, name]} />
                <Bar dataKey="revenue" fill="#10b981" name="Revenue" />
                <Bar dataKey="expenses" fill="#ef4444" name="Expenses" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default ProfitLossReport;
