
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { format, subDays, startOfWeek, endOfWeek, startOfMonth, endOfMonth } from 'date-fns';
import { DateRange } from 'react-day-picker';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { TrendingUp, Package, DollarSign } from 'lucide-react';

interface ProductSalesAnalysisProps {
  dateRange?: DateRange;
}

interface ProductData {
  sales: number;
  profit: number;
  quantity: number;
}

interface ProductSummary {
  name: string;
  sales: number;
  profit: number;
}

export const ProductSalesAnalysis: React.FC<ProductSalesAnalysisProps> = ({ dateRange }) => {
  const [selectedPeriod, setSelectedPeriod] = useState('daily');

  const { data: productSalesData, isLoading } = useQuery({
    queryKey: ['product-sales-analysis', dateRange, selectedPeriod],
    queryFn: async () => {
      const startDate = dateRange?.from ? format(dateRange.from, 'yyyy-MM-dd') : format(subDays(new Date(), 30), 'yyyy-MM-dd');
      const endDate = dateRange?.to ? format(dateRange.to, 'yyyy-MM-dd') : format(new Date(), 'yyyy-MM-dd');

      // Fetch bill items with product details for the selected period
      const { data: billItems, error } = await supabase
        .from('bill_items')
        .select(`
          *,
          bills!inner(bill_date, payment_method),
          products(id, name, cost_price, price, category)
        `)
        .gte('bills.bill_date', startDate)
        .lte('bills.bill_date', endDate)
        .order('bills.bill_date', { ascending: true });

      if (error) throw error;

      return billItems || [];
    },
  });

  // Process data based on selected period
  const processDataByPeriod = (data: any[], period: string): Record<string, Record<string, ProductData>> => {
    if (!data || data.length === 0) return {};

    const groupedData: Record<string, Record<string, ProductData>> = {};

    data.forEach((item: any) => {
      if (!item.bills || !item.products) return;

      const date = new Date(item.bills.bill_date);
      let periodKey = '';

      switch (period) {
        case 'daily':
          periodKey = format(date, 'yyyy-MM-dd');
          break;
        case 'weekly':
          periodKey = `Week of ${format(startOfWeek(date), 'MMM dd, yyyy')}`;
          break;
        case 'monthly':
          periodKey = format(date, 'MMM yyyy');
          break;
        default:
          periodKey = format(date, 'yyyy-MM-dd');
      }

      const productName = item.products.name;
      const salesAmount = Number(item.total_price);
      const costPrice = Number(item.products.cost_price || 0);
      const profit = salesAmount - (costPrice * item.quantity);

      if (!groupedData[periodKey]) {
        groupedData[periodKey] = {};
      }

      if (!groupedData[periodKey][productName]) {
        groupedData[periodKey][productName] = { sales: 0, profit: 0, quantity: 0 };
      }

      groupedData[periodKey][productName].sales += salesAmount;
      groupedData[periodKey][productName].profit += profit;
      groupedData[periodKey][productName].quantity += item.quantity;
    });

    return groupedData;
  };

  const processedData = processDataByPeriod(productSalesData || [], selectedPeriod);

  // Get top products by sales for the chart
  const getTopProductsForChart = (): ProductSummary[] => {
    const productTotals: Record<string, { sales: number; profit: number }> = {};

    Object.values(processedData).forEach(periodData => {
      Object.entries(periodData).forEach(([product, data]: [string, ProductData]) => {
        if (!productTotals[product]) {
          productTotals[product] = { sales: 0, profit: 0 };
        }
        productTotals[product].sales += data.sales;
        productTotals[product].profit += data.profit;
      });
    });

    return Object.entries(productTotals)
      .map(([name, data]) => ({ name, ...data }))
      .sort((a, b) => b.sales - a.sales)
      .slice(0, 10);
  };

  const topProducts = getTopProductsForChart();

  // Calculate summary metrics
  const totalSales = topProducts.reduce((sum, product) => sum + product.sales, 0);
  const totalProfit = topProducts.reduce((sum, product) => sum + product.profit, 0);
  const avgProfitMargin = totalSales > 0 ? (totalProfit / totalSales) * 100 : 0;

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Product Sales & Profit Analysis</CardTitle>
          <CardDescription>Loading product performance data...</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center h-64">
            <div className="text-center">Loading...</div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Package className="h-5 w-5" />
          Product Sales & Profit Analysis
        </CardTitle>
        <CardDescription>
          Detailed breakdown of sales and profit by product across different time periods
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs value={selectedPeriod} onValueChange={setSelectedPeriod} className="space-y-4">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="daily">Daily</TabsTrigger>
            <TabsTrigger value="weekly">Weekly</TabsTrigger>
            <TabsTrigger value="monthly">Monthly</TabsTrigger>
          </TabsList>

          {/* Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Sales</CardTitle>
                <DollarSign className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">₹{totalSales.toFixed(2)}</div>
                <p className="text-xs text-muted-foreground">from top products</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Profit</CardTitle>
                <TrendingUp className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">₹{totalProfit.toFixed(2)}</div>
                <p className="text-xs text-muted-foreground">gross profit</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Avg Profit Margin</CardTitle>
                <Package className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{avgProfitMargin.toFixed(1)}%</div>
                <p className="text-xs text-muted-foreground">across all products</p>
              </CardContent>
            </Card>
          </div>

          <TabsContent value="daily" className="space-y-4">
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={topProducts}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis 
                    dataKey="name" 
                    angle={-45}
                    textAnchor="end"
                    height={80}
                    interval={0}
                  />
                  <YAxis />
                  <Tooltip 
                    formatter={(value, name) => [
                      `₹${Number(value).toFixed(2)}`, 
                      name === 'sales' ? 'Sales' : 'Profit'
                    ]}
                  />
                  <Bar dataKey="sales" name="Sales" fill="#3b82f6" />
                  <Bar dataKey="profit" name="Profit" fill="#22c55e" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </TabsContent>

          <TabsContent value="weekly" className="space-y-4">
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={topProducts}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis 
                    dataKey="name" 
                    angle={-45}
                    textAnchor="end"
                    height={80}
                    interval={0}
                  />
                  <YAxis />
                  <Tooltip 
                    formatter={(value, name) => [
                      `₹${Number(value).toFixed(2)}`, 
                      name === 'sales' ? 'Sales' : 'Profit'
                    ]}
                  />
                  <Bar dataKey="sales" name="Sales" fill="#3b82f6" />
                  <Bar dataKey="profit" name="Profit" fill="#22c55e" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </TabsContent>

          <TabsContent value="monthly" className="space-y-4">
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={topProducts}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis 
                    dataKey="name" 
                    angle={-45}
                    textAnchor="end"
                    height={80}
                    interval={0}
                  />
                  <YAxis />
                  <Tooltip 
                    formatter={(value, name) => [
                      `₹${Number(value).toFixed(2)}`, 
                      name === 'sales' ? 'Sales' : 'Profit'
                    ]}
                  />
                  <Bar dataKey="sales" name="Sales" fill="#3b82f6" />
                  <Bar dataKey="profit" name="Profit" fill="#22c55e" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </TabsContent>
        </Tabs>

        {/* Detailed Product List */}
        <div className="mt-6">
          <h4 className="text-lg font-semibold mb-4">Product Performance Details</h4>
          <div className="space-y-2 max-h-64 overflow-y-auto">
            {topProducts.map((product, index) => {
              const profitMargin = product.sales > 0 ? (product.profit / product.sales) * 100 : 0;
              return (
                <div key={product.name} className="flex justify-between items-center p-3 border rounded-lg">
                  <div className="flex items-center gap-3">
                    <Badge variant="secondary">#{index + 1}</Badge>
                    <div>
                      <p className="font-medium">{product.name}</p>
                      <p className="text-sm text-muted-foreground">
                        Margin: {profitMargin.toFixed(1)}%
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-blue-600">₹{product.sales.toFixed(2)}</p>
                    <p className="text-sm text-green-600">+₹{product.profit.toFixed(2)}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};
