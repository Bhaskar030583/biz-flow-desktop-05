
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { 
  Users, 
  Package, 
  TrendingUp,
  Target,
  Calendar,
  Clock
} from 'lucide-react';
import { format, subDays, eachDayOfInterval } from 'date-fns';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, LineChart, Line, XAxis, YAxis, CartesianGrid, BarChart, Bar } from 'recharts';

const BusinessAnalytics = () => {
  const [selectedPeriod, setSelectedPeriod] = useState('30days');

  const { data: analyticsData, isLoading } = useQuery({
    queryKey: ['business-analytics', selectedPeriod],
    queryFn: async () => {
      const days = selectedPeriod === '7days' ? 7 : selectedPeriod === '30days' ? 30 : 90;
      const startDate = format(subDays(new Date(), days), 'yyyy-MM-dd');
      const endDate = format(new Date(), 'yyyy-MM-dd');

      const [bills, customers, products, billItems] = await Promise.all([
        supabase.from('bills').select('*').gte('bill_date', startDate).lte('bill_date', endDate),
        supabase.from('customers').select('*'),
        supabase.from('products').select('*'),
        supabase.from('bill_items').select('*, bills!inner(bill_date)').gte('bills.bill_date', startDate).lte('bills.bill_date', endDate)
      ]);

      return { 
        bills: bills.data || [], 
        customers: customers.data || [], 
        products: products.data || [],
        billItems: billItems.data || []
      };
    },
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">Loading analytics...</div>
      </div>
    );
  }

  // Customer Analysis
  const customerPurchaseFrequency = analyticsData?.bills.reduce((acc, bill) => {
    if (bill.customer_id) {
      acc[bill.customer_id] = (acc[bill.customer_id] || 0) + 1;
    }
    return acc;
  }, {} as Record<string, number>);

  const customerSegments = Object.values(customerPurchaseFrequency || {}).reduce((acc, frequency) => {
    if (frequency >= 10) acc.loyal++;
    else if (frequency >= 5) acc.regular++;
    else acc.occasional++;
    return acc;
  }, { loyal: 0, regular: 0, occasional: 0 });

  const customerSegmentData = [
    { name: 'Loyal (10+ purchases)', value: customerSegments.loyal, color: '#22c55e' },
    { name: 'Regular (5-9 purchases)', value: customerSegments.regular, color: '#3b82f6' },
    { name: 'Occasional (1-4 purchases)', value: customerSegments.occasional, color: '#f59e0b' }
  ];

  // Product Analysis
  const productPerformance = analyticsData?.billItems.reduce((acc, item) => {
    if (!acc[item.product_name]) {
      acc[item.product_name] = { quantity: 0, revenue: 0, frequency: 0 };
    }
    acc[item.product_name].quantity += item.quantity;
    acc[item.product_name].revenue += Number(item.total_price);
    acc[item.product_name].frequency += 1;
    return acc;
  }, {} as Record<string, { quantity: number; revenue: number; frequency: number }>);

  const topProducts = Object.entries(productPerformance || {})
    .map(([name, data]) => ({ name, ...data }))
    .sort((a, b) => b.revenue - a.revenue)
    .slice(0, 10);

  // Time-based Analysis
  const hourlyAnalysis = analyticsData?.bills.reduce((acc, bill) => {
    const hour = new Date(bill.bill_date).getHours();
    acc[hour] = (acc[hour] || 0) + Number(bill.total_amount);
    return acc;
  }, {} as Record<number, number>);

  const hourlyData = Array.from({ length: 24 }, (_, hour) => ({
    hour: `${hour}:00`,
    sales: hourlyAnalysis?.[hour] || 0
  }));

  // Weekly pattern
  const weeklyAnalysis = analyticsData?.bills.reduce((acc, bill) => {
    const day = new Date(bill.bill_date).getDay();
    const dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    const dayName = dayNames[day];
    acc[dayName] = (acc[dayName] || 0) + Number(bill.total_amount);
    return acc;
  }, {} as Record<string, number>);

  const weeklyData = Object.entries(weeklyAnalysis || {}).map(([day, sales]) => ({ day, sales }));

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Business Analytics</h1>
          <p className="text-muted-foreground">
            Deep insights into customer behavior and business patterns
          </p>
        </div>
        <div className="flex gap-2">
          {['7days', '30days', '90days'].map((period) => (
            <Button
              key={period}
              variant={selectedPeriod === period ? "default" : "outline"}
              onClick={() => setSelectedPeriod(period)}
              size="sm"
            >
              {period === '7days' ? '7 Days' : period === '30days' ? '30 Days' : '90 Days'}
            </Button>
          ))}
        </div>
      </div>

      <Tabs defaultValue="customers" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="customers">Customer Analysis</TabsTrigger>
          <TabsTrigger value="products">Product Performance</TabsTrigger>
          <TabsTrigger value="timing">Time Patterns</TabsTrigger>
          <TabsTrigger value="insights">Business Insights</TabsTrigger>
        </TabsList>

        <TabsContent value="customers" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Customer Segmentation</CardTitle>
                <CardDescription>Based on purchase frequency</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={customerSegmentData}
                      cx="50%"
                      cy="50%"
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                      label={({ name, value }) => `${name}: ${value}`}
                    >
                      {customerSegmentData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Customer Insights</CardTitle>
                <CardDescription>Key customer metrics</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-sm">Total Customers</span>
                  <span className="font-bold">{analyticsData?.customers.length || 0}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm">Loyal Customers</span>
                  <span className="font-bold text-green-600">{customerSegments.loyal}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm">Regular Customers</span>
                  <span className="font-bold text-blue-600">{customerSegments.regular}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm">Customer Retention</span>
                  <span className="font-bold">
                    {analyticsData?.customers.length ? 
                      ((customerSegments.loyal + customerSegments.regular) / analyticsData.customers.length * 100).toFixed(1) 
                      : 0}%
                  </span>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="products" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Top Products by Revenue</CardTitle>
              <CardDescription>Best performing products in selected period</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {topProducts.map((product, index) => (
                  <div key={product.name} className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center text-sm font-bold">
                        {index + 1}
                      </div>
                      <div>
                        <p className="font-medium">{product.name}</p>
                        <p className="text-sm text-muted-foreground">
                          {product.quantity} units sold • {product.frequency} transactions
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-green-600">₹{product.revenue.toFixed(2)}</p>
                      <p className="text-xs text-muted-foreground">
                        ₹{(product.revenue / product.quantity).toFixed(2)}/unit
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="timing" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Hourly Sales Pattern</CardTitle>
                <CardDescription>Sales distribution throughout the day</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={hourlyData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="hour" />
                    <YAxis />
                    <Tooltip formatter={(value) => [`₹${Number(value).toFixed(2)}`, 'Sales']} />
                    <Bar dataKey="sales" fill="#8884d8" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Weekly Sales Pattern</CardTitle>
                <CardDescription>Sales by day of the week</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={weeklyData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="day" />
                    <YAxis />
                    <Tooltip formatter={(value) => [`₹${Number(value).toFixed(2)}`, 'Sales']} />
                    <Bar dataKey="sales" fill="#82ca9d" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="insights" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Growth Opportunities</CardTitle>
                <CardDescription>Areas for business expansion</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-start gap-3">
                  <Target className="h-5 w-5 text-blue-600 mt-0.5" />
                  <div>
                    <p className="font-medium">Focus on Loyal Customers</p>
                    <p className="text-sm text-muted-foreground">
                      {customerSegments.loyal} loyal customers drive significant revenue
                    </p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Package className="h-5 w-5 text-green-600 mt-0.5" />
                  <div>
                    <p className="font-medium">Promote Top Products</p>
                    <p className="text-sm text-muted-foreground">
                      Top 5 products generate majority of revenue
                    </p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Clock className="h-5 w-5 text-purple-600 mt-0.5" />
                  <div>
                    <p className="font-medium">Optimize Peak Hours</p>
                    <p className="text-sm text-muted-foreground">
                      Ensure adequate staffing during busy periods
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Recommendations</CardTitle>
                <CardDescription>Data-driven action items</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="p-3 bg-blue-50 rounded-lg border border-blue-200">
                  <p className="font-medium text-blue-800">Customer Retention</p>
                  <p className="text-sm text-blue-700">
                    Create loyalty programs for regular customers to convert them to loyal status
                  </p>
                </div>
                <div className="p-3 bg-green-50 rounded-lg border border-green-200">
                  <p className="font-medium text-green-800">Inventory Management</p>
                  <p className="text-sm text-green-700">
                    Ensure top-selling products are always in stock
                  </p>
                </div>
                <div className="p-3 bg-purple-50 rounded-lg border border-purple-200">
                  <p className="font-medium text-purple-800">Marketing Strategy</p>
                  <p className="text-sm text-purple-700">
                    Target marketing campaigns during peak hours and days
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default BusinessAnalytics;
