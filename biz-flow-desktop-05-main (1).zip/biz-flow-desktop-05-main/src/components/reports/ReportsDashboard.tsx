
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';
import { 
  BarChart3, 
  TrendingUp, 
  DollarSign, 
  Package, 
  Users, 
  UserCheck,
  FileText,
  Download,
  Target,
  Activity
} from 'lucide-react';

const ReportsDashboard = () => {
  const navigate = useNavigate();

  const reportCategories = [
    {
      title: 'KPI Dashboard',
      description: 'Key performance indicators and business metrics',
      icon: Target,
      color: 'text-indigo-600',
      bgColor: 'bg-indigo-50',
      path: '/reports/kpi',
      reports: ['Revenue Growth', 'Profit Margins', 'Customer Metrics', 'Inventory Turnover']
    },
    {
      title: 'Business Analytics',
      description: 'Advanced analytics and customer insights',
      icon: Activity,
      color: 'text-cyan-600',
      bgColor: 'bg-cyan-50',
      path: '/reports/analytics',
      reports: ['Customer Segmentation', 'Product Performance', 'Time Patterns', 'Growth Insights']
    },
    {
      title: 'Sales Reports',
      description: 'Comprehensive sales analysis and trends',
      icon: TrendingUp,
      color: 'text-green-600',
      bgColor: 'bg-green-50',
      path: '/reports/sales',
      reports: ['Daily Sales', 'Monthly Summary', 'Product Performance', 'Payment Methods']
    },
    {
      title: 'Financial Reports',
      description: 'Profit & Loss, Cash Flow, Financial Summary',
      icon: DollarSign,
      color: 'text-blue-600',
      bgColor: 'bg-blue-50',
      path: '/reports/profit-loss',
      reports: ['P&L Statement', 'Cash Flow', 'Revenue Analysis', 'Expense Breakdown']
    },
    {
      title: 'Expense Reports',
      description: 'Track and analyze business expenses',
      icon: FileText,
      color: 'text-red-600',
      bgColor: 'bg-red-50',
      path: '/reports/expenses',
      reports: ['Category-wise', 'Monthly Trends', 'Store Comparison', 'Tax Summary']
    },
    {
      title: 'Inventory Reports',
      description: 'Stock levels, movements, and valuation',
      icon: Package,
      color: 'text-purple-600',
      bgColor: 'bg-purple-50',
      path: '/reports/inventory',
      reports: ['Stock Valuation', 'Movement Analysis', 'Low Stock', 'Loss Tracking']
    },
    {
      title: 'Customer Reports',
      description: 'Customer analysis and credit management',
      icon: Users,
      color: 'text-orange-600',
      bgColor: 'bg-orange-50',
      path: '/reports/customers',
      reports: ['Customer Analysis', 'Credit Summary', 'Payment History', 'Top Customers']
    },
    {
      title: 'HRMS Reports',
      description: 'Employee, attendance, and payroll reports',
      icon: UserCheck,
      color: 'text-teal-600',
      bgColor: 'bg-teal-50',
      path: '/reports/hrms',
      reports: ['Attendance Summary', 'Payroll Reports', 'Performance Metrics', 'Leave Analysis']
    }
  ];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Business Reports</h1>
          <p className="text-muted-foreground">
            Comprehensive business analytics and reporting dashboard
          </p>
        </div>
        <Button variant="outline" className="flex items-center gap-2">
          <Download className="h-4 w-4" />
          Export All
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {reportCategories.map((category, index) => {
          const Icon = category.icon;
          return (
            <Card key={index} className="hover:shadow-lg transition-shadow cursor-pointer">
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-lg ${category.bgColor}`}>
                    <Icon className={`h-6 w-6 ${category.color}`} />
                  </div>
                  <div>
                    <CardTitle className="text-lg">{category.title}</CardTitle>
                    <CardDescription>{category.description}</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 mb-4">
                  {category.reports.map((report, idx) => (
                    <div key={idx} className="text-sm text-muted-foreground flex items-center gap-2">
                      <BarChart3 className="h-3 w-3" />
                      {report}
                    </div>
                  ))}
                </div>
                <Button 
                  onClick={() => navigate(category.path)}
                  className="w-full"
                  variant="default"
                >
                  View Reports
                </Button>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Quick Report Generation</CardTitle>
          <CardDescription>Generate commonly used reports quickly</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Button 
              variant="outline" 
              onClick={() => navigate('/reports/kpi')}
              className="flex items-center gap-2 h-12"
            >
              <Target className="h-4 w-4" />
              KPI Dashboard
            </Button>
            <Button 
              variant="outline" 
              onClick={() => navigate('/reports/analytics')}
              className="flex items-center gap-2 h-12"
            >
              <Activity className="h-4 w-4" />
              Business Analytics
            </Button>
            <Button 
              variant="outline" 
              onClick={() => navigate('/reports/sales')}
              className="flex items-center gap-2 h-12"
            >
              <TrendingUp className="h-4 w-4" />
              Today's Sales Summary
            </Button>
            <Button 
              variant="outline" 
              onClick={() => navigate('/reports/profit-loss')}
              className="flex items-center gap-2 h-12"
            >
              <DollarSign className="h-4 w-4" />
              Profit & Loss
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default ReportsDashboard;
