
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { DatePickerWithRange } from '@/components/ui/date-picker-with-range';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { 
  TrendingUp, 
  TrendingDown, 
  Target, 
  Users, 
  ShoppingCart, 
  DollarSign,
  Package,
  RotateCcw,
  Banknote,
  Download
} from 'lucide-react';
import { format, subDays, subMonths } from 'date-fns';
import { DateRange } from 'react-day-picker';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts';
import { calculatePercentageChange, calculateAverage } from '@/utils/calculations';

const KPIDashboard = () => {
  const [dateRange, setDateRange] = useState<DateRange | undefined>({
    from: subDays(new Date(), 30),
    to: new Date(),
  });

  const [comparisonRange, setComparisonRange] = useState<DateRange | undefined>({
    from: subDays(new Date(), 60),
    to: subDays(new Date(), 31),
  });

  // Current period data
  const { data: currentData, isLoading: currentLoading } = useQuery({
    queryKey: ['kpi-current', dateRange],
    queryFn: async () => {
      const startDate = dateRange?.from ? format(dateRange.from, 'yyyy-MM-dd') : format(subDays(new Date(), 30), 'yyyy-MM-dd');
      const endDate = dateRange?.to ? format(dateRange.to, 'yyyy-MM-dd') : format(new Date(), 'yyyy-MM-dd');

      const [bills, customers, stocks, expenses] = await Promise.all([
        supabase.from('bills').select('*').gte('bill_date', startDate).lte('bill_date', endDate),
        supabase.from('customers').select('*'),
        supabase.from('stocks').select('*, products(cost_price, price)').gte('stock_date', startDate).lte('stock_date', endDate),
        supabase.from('expenses').select('*').gte('expense_date', startDate).lte('expense_date', endDate)
      ]);

      return { bills: bills.data || [], customers: customers.data || [], stocks: stocks.data || [], expenses: expenses.data || [] };
    },
  });

  // Previous period data for comparison
  const { data: previousData, isLoading: previousLoading } = useQuery({
    queryKey: ['kpi-previous', comparisonRange],
    queryFn: async () => {
      const startDate = comparisonRange?.from ? format(comparisonRange.from, 'yyyy-MM-dd') : format(subDays(new Date(), 60), 'yyyy-MM-dd');
      const endDate = comparisonRange?.to ? format(comparisonRange.to, 'yyyy-MM-dd') : format(subDays(new Date(), 31), 'yyyy-MM-dd');

      const [bills, expenses] = await Promise.all([
        supabase.from('bills').select('*').gte('bill_date', startDate).lte('bill_date', endDate),
        supabase.from('expenses').select('*').gte('expense_date', startDate).lte('expense_date', endDate)
      ]);

      return { bills: bills.data || [], expenses: expenses.data || [] };
    },
  });

  if (currentLoading || previousLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">Loading KPI dashboard...</div>
      </div>
    );
  }

  // Calculate current period KPIs
  const currentRevenue = currentData?.bills.reduce((sum, bill) => sum + Number(bill.total_amount), 0) || 0;
  const currentSales = currentData?.bills.length || 0;
  const currentAOV = currentSales > 0 ? currentRevenue / currentSales : 0;
  const currentExpenses = currentData?.expenses.reduce((sum, expense) => sum + Number(expense.amount), 0) || 0;
  const currentProfit = currentRevenue - currentExpenses;
  const currentGrossMargin = currentRevenue > 0 ? (currentProfit / currentRevenue) * 100 : 0;

  // Calculate previous period KPIs
  const previousRevenue = previousData?.bills.reduce((sum, bill) => sum + Number(bill.total_amount), 0) || 0;
  const previousSales = previousData?.bills.length || 0;
  const previousAOV = previousSales > 0 ? previousRevenue / previousSales : 0;
  const previousExpenses = previousData?.expenses.reduce((sum, expense) => sum + Number(expense.amount), 0) || 0;
  const previousProfit = previousRevenue - previousExpenses;

  // Calculate changes
  const revenueChange = calculatePercentageChange(previousRevenue, currentRevenue);
  const salesChange = calculatePercentageChange(previousSales, currentSales);
  const aovChange = calculatePercentageChange(previousAOV, currentAOV);
  const profitChange = calculatePercentageChange(previousProfit, currentProfit);

  // Calculate inventory turnover (simplified)
  const totalStockValue = currentData?.stocks.reduce((sum, stock) => {
    const price = stock.products?.price || 0;
    return sum + (stock.actual_stock * Number(price));
  }, 0) || 0;

  const inventoryTurnover = totalStockValue > 0 ? currentRevenue / totalStockValue : 0;

  // Customer metrics
  const totalCustomers = currentData?.customers.length || 0;
  const customerAcquisitionRate = 0; // Would need historical data to calculate properly

  // Daily trends for charts
  const dailyMetrics = currentData?.bills.reduce((acc, bill) => {
    const date = format(new Date(bill.bill_date), 'MMM dd');
    if (!acc[date]) {
      acc[date] = { date, revenue: 0, sales: 0, profit: 0 };
    }
    acc[date].revenue += Number(bill.total_amount);
    acc[date].sales += 1;
    return acc;
  }, {} as Record<string, { date: string; revenue: number; sales: number; profit: number }>);

  const chartData = Object.values(dailyMetrics || {});

  const kpiCards = [
    {
      title: "Revenue Growth Rate",
      value: `₹${currentRevenue.toFixed(2)}`,
      change: revenueChange,
      icon: DollarSign,
      description: "vs previous period"
    },
    {
      title: "Gross Profit Margin",
      value: `${currentGrossMargin.toFixed(1)}%`,
      change: profitChange,
      icon: TrendingUp,
      description: "profit margin"
    },
    {
      title: "Average Order Value",
      value: `₹${currentAOV.toFixed(2)}`,
      change: aovChange,
      icon: ShoppingCart,
      description: "per transaction"
    },
    {
      title: "Inventory Turnover",
      value: `${inventoryTurnover.toFixed(2)}x`,
      change: 0, // Would need historical data
      icon: RotateCcw,
      description: "times per period"
    },
    {
      title: "Total Customers",
      value: totalCustomers.toString(),
      change: customerAcquisitionRate,
      icon: Users,
      description: "active customers"
    },
    {
      title: "Cash Flow",
      value: `₹${(currentRevenue - currentExpenses).toFixed(2)}`,
      change: profitChange,
      icon: Banknote,
      description: "net cash flow"
    }
  ];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-start">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">KPI Dashboard</h1>
          <p className="text-muted-foreground">
            Key performance indicators for business growth analysis
          </p>
        </div>
        <div className="flex gap-2">
          <DatePickerWithRange date={dateRange} setDate={setDateRange} />
          <Button variant="outline" className="flex items-center gap-2">
            <Download className="h-4 w-4" />
            Export KPIs
          </Button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {kpiCards.map((kpi, index) => {
          const Icon = kpi.icon;
          const isPositive = kpi.change >= 0;
          
          return (
            <Card key={index} className="hover:shadow-lg transition-shadow">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">{kpi.title}</CardTitle>
                <Icon className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{kpi.value}</div>
                <div className="flex items-center gap-1 text-xs">
                  {kpi.change !== 0 && (
                    <>
                      {isPositive ? (
                        <TrendingUp className="h-3 w-3 text-green-600" />
                      ) : (
                        <TrendingDown className="h-3 w-3 text-red-600" />
                      )}
                      <span className={isPositive ? "text-green-600" : "text-red-600"}>
                        {Math.abs(kpi.change).toFixed(1)}%
                      </span>
                    </>
                  )}
                  <span className="text-muted-foreground">{kpi.description}</span>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Performance Trends */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Revenue Trend</CardTitle>
            <CardDescription>Daily revenue performance</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip formatter={(value) => [`₹${Number(value).toFixed(2)}`, 'Revenue']} />
                <Line type="monotone" dataKey="revenue" stroke="#8884d8" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Sales Volume</CardTitle>
            <CardDescription>Daily transaction count</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip formatter={(value) => [value, 'Sales']} />
                <Bar dataKey="sales" fill="#82ca9d" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Business Insights */}
      <Card>
        <CardHeader>
          <CardTitle>Business Insights & Recommendations</CardTitle>
          <CardDescription>AI-powered analysis of your performance data</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {revenueChange > 10 && (
              <div className="flex items-start gap-3 p-3 bg-green-50 rounded-lg border border-green-200">
                <TrendingUp className="h-5 w-5 text-green-600 mt-0.5" />
                <div>
                  <p className="font-medium text-green-800">Strong Revenue Growth</p>
                  <p className="text-sm text-green-700">Your revenue is up {revenueChange.toFixed(1)}%! Consider expanding inventory for top-selling products.</p>
                </div>
              </div>
            )}
            
            {currentGrossMargin < 30 && (
              <div className="flex items-start gap-3 p-3 bg-yellow-50 rounded-lg border border-yellow-200">
                <Target className="h-5 w-5 text-yellow-600 mt-0.5" />
                <div>
                  <p className="font-medium text-yellow-800">Low Profit Margin</p>
                  <p className="text-sm text-yellow-700">Your profit margin is {currentGrossMargin.toFixed(1)}%. Consider reviewing pricing or reducing costs.</p>
                </div>
              </div>
            )}

            {aovChange < -5 && (
              <div className="flex items-start gap-3 p-3 bg-blue-50 rounded-lg border border-blue-200">
                <ShoppingCart className="h-5 w-5 text-blue-600 mt-0.5" />
                <div>
                  <p className="font-medium text-blue-800">Declining Average Order Value</p>
                  <p className="text-sm text-blue-700">AOV decreased by {Math.abs(aovChange).toFixed(1)}%. Implement upselling strategies or bundle offers.</p>
                </div>
              </div>
            )}

            {inventoryTurnover < 2 && (
              <div className="flex items-start gap-3 p-3 bg-purple-50 rounded-lg border border-purple-200">
                <Package className="h-5 w-5 text-purple-600 mt-0.5" />
                <div>
                  <p className="font-medium text-purple-800">Slow Inventory Movement</p>
                  <p className="text-sm text-purple-700">Inventory turnover is low. Consider promotions to clear slow-moving stock.</p>
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default KPIDashboard;
