
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { DatePickerWithRange } from '@/components/ui/date-picker-with-range';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Download, Users, CreditCard, TrendingUp, DollarSign } from 'lucide-react';
import { format, subDays } from 'date-fns';
import { DateRange } from 'react-day-picker';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

const CustomerReport = () => {
  const [dateRange, setDateRange] = useState<DateRange | undefined>({
    from: subDays(new Date(), 30),
    to: new Date(),
  });

  const { data: customersData, isLoading } = useQuery({
    queryKey: ['customers-report'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('customers')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      return data || [];
    },
  });

  const { data: customerSales } = useQuery({
    queryKey: ['customer-sales', dateRange],
    queryFn: async () => {
      const startDate = dateRange?.from ? format(dateRange.from, 'yyyy-MM-dd') : format(subDays(new Date(), 30), 'yyyy-MM-dd');
      const endDate = dateRange?.to ? format(dateRange.to, 'yyyy-MM-dd') : format(new Date(), 'yyyy-MM-dd');

      const { data, error } = await supabase
        .from('bills')
        .select(`
          *,
          customers(name, phone, email)
        `)
        .gte('bill_date', startDate)
        .lte('bill_date', endDate)
        .not('customer_id', 'is', null);

      if (error) throw error;
      return data || [];
    },
  });

  const { data: creditData } = useQuery({
    queryKey: ['customer-credits'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('credit_transactions')
        .select(`
          *,
          customers(name)
        `);

      if (error) throw error;
      return data || [];
    },
  });

  // Calculate metrics
  const totalCustomers = customersData?.length || 0;
  const activeCustomers = customerSales?.reduce((acc, sale) => {
    if (sale.customer_id) acc.add(sale.customer_id);
    return acc;
  }, new Set()).size || 0;

  const totalCustomerRevenue = customerSales?.reduce((sum, sale) => sum + Number(sale.total_amount), 0) || 0;
  const averageOrderValue = customerSales?.length ? totalCustomerRevenue / customerSales.length : 0;

  // Customer purchase analysis
  const customerPurchases = customerSales?.reduce((acc, sale) => {
    const customerId = sale.customer_id;
    if (!acc[customerId]) {
      acc[customerId] = {
        name: sale.customers?.name || 'Unknown',
        totalSpent: 0,
        orderCount: 0,
        averageOrder: 0
      };
    }
    acc[customerId].totalSpent += Number(sale.total_amount);
    acc[customerId].orderCount += 1;
    acc[customerId].averageOrder = acc[customerId].totalSpent / acc[customerId].orderCount;
    return acc;
  }, {} as Record<string, any>);

  const topCustomers = Object.values(customerPurchases || {})
    .sort((a: any, b: any) => b.totalSpent - a.totalSpent)
    .slice(0, 10);

  // Credit analysis
  const customerCredits = creditData?.reduce((acc, credit) => {
    const customerId = credit.customer_id;
    if (!acc[customerId]) {
      acc[customerId] = {
        name: credit.customers?.name || 'Unknown',
        totalCredit: 0,
        status: credit.status
      };
    }
    if (credit.status === 'pending') {
      acc[customerId].totalCredit += Number(credit.amount);
    }
    return acc;
  }, {} as Record<string, any>);

  const topCreditCustomers = Object.values(customerCredits || {})
    .filter((customer: any) => customer.totalCredit > 0)
    .sort((a: any, b: any) => b.totalCredit - a.totalCredit)
    .slice(0, 10);

  const totalOutstandingCredits = Object.values(customerCredits || {})
    .reduce((sum: number, customer: any) => sum + customer.totalCredit, 0);

  // Customer segmentation by purchase value
  const segmentData = [
    { segment: 'High Value (₹10,000+)', count: topCustomers.filter((c: any) => c.totalSpent >= 10000).length },
    { segment: 'Medium Value (₹5,000-9,999)', count: topCustomers.filter((c: any) => c.totalSpent >= 5000 && c.totalSpent < 10000).length },
    { segment: 'Low Value (<₹5,000)', count: topCustomers.filter((c: any) => c.totalSpent < 5000).length },
  ];

  const COLORS = ['#0088FE', '#00C49F', '#FFBB28'];

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">Loading customer report...</div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-start">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Customer Report</h1>
          <p className="text-muted-foreground">
            Customer analysis and relationship insights
          </p>
        </div>
        <div className="flex gap-2">
          <DatePickerWithRange date={dateRange} setDate={setDateRange} />
          <Button variant="outline" className="flex items-center gap-2">
            <Download className="h-4 w-4" />
            Export
          </Button>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Customers</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalCustomers}</div>
            <p className="text-xs text-muted-foreground">registered customers</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Customers</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{activeCustomers}</div>
            <p className="text-xs text-muted-foreground">purchased in period</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Customer Revenue</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">₹{totalCustomerRevenue.toFixed(2)}</div>
            <p className="text-xs text-muted-foreground">from customer sales</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Outstanding Credits</CardTitle>
            <CreditCard className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">₹{totalOutstandingCredits.toFixed(2)}</div>
            <p className="text-xs text-muted-foreground">pending collections</p>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Customer Segmentation</CardTitle>
            <CardDescription>Customer distribution by purchase value</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={segmentData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ segment, count }) => `${segment}: ${count}`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="count"
                >
                  {segmentData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Top Customers by Revenue</CardTitle>
            <CardDescription>Highest value customers</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={topCustomers.slice(0, 6)}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" angle={-45} textAnchor="end" height={100} />
                <YAxis />
                <Tooltip formatter={(value) => [`₹${Number(value).toFixed(2)}`, 'Total Spent']} />
                <Bar dataKey="totalSpent" fill="#8884d8" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Top Customers */}
      <Card>
        <CardHeader>
          <CardTitle>Top Customers</CardTitle>
          <CardDescription>Best customers by purchase value and frequency</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {topCustomers.map((customer: any, index) => (
              <div key={index} className="flex justify-between items-center p-3 border rounded-lg">
                <div className="flex items-center gap-3">
                  <Badge variant="secondary">#{index + 1}</Badge>
                  <div>
                    <p className="font-medium">{customer.name}</p>
                    <p className="text-sm text-muted-foreground">
                      {customer.orderCount} orders • Avg: ₹{customer.averageOrder.toFixed(2)}
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-bold text-green-600">₹{customer.totalSpent.toFixed(2)}</p>
                  <p className="text-sm text-muted-foreground">total spent</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Credit Customers */}
      {topCreditCustomers.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CreditCard className="h-5 w-5 text-orange-600" />
              Outstanding Credits
            </CardTitle>
            <CardDescription>Customers with pending credit payments</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {topCreditCustomers.map((customer: any, index) => (
                <div key={index} className="flex justify-between items-center p-3 border rounded-lg bg-orange-50">
                  <div className="flex items-center gap-3">
                    <Badge variant="destructive">#{index + 1}</Badge>
                    <div>
                      <p className="font-medium">{customer.name}</p>
                      <Badge variant="outline" className="mt-1">Pending Payment</Badge>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-red-600">₹{customer.totalCredit.toFixed(2)}</p>
                    <p className="text-sm text-muted-foreground">outstanding</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default CustomerReport;
