import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { DatePickerWithRange } from '@/components/ui/date-picker-with-range';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Download, Users, Clock, DollarSign, Calendar } from 'lucide-react';
import { format, subDays } from 'date-fns';
import { DateRange } from 'react-day-picker';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts';

const HRMSReport = () => {
  const [dateRange, setDateRange] = useState<DateRange | undefined>({
    from: subDays(new Date(), 30),
    to: new Date(),
  });

  const { data: employeesData, isLoading } = useQuery({
    queryKey: ['employees-report'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('hr_employees')
        .select('*')
        .eq('employment_status', 'active');

      if (error) throw error;
      return data || [];
    },
  });

  const { data: attendanceData } = useQuery({
    queryKey: ['attendance-report', dateRange],
    queryFn: async () => {
      const startDate = dateRange?.from ? format(dateRange.from, 'yyyy-MM-dd') : format(subDays(new Date(), 30), 'yyyy-MM-dd');
      const endDate = dateRange?.to ? format(dateRange.to, 'yyyy-MM-dd') : format(new Date(), 'yyyy-MM-dd');

      const { data, error } = await supabase
        .from('hr_attendance')
        .select(`
          *,
          hr_employees!hr_attendance_employee_id_fkey(first_name, last_name, employee_code)
        `)
        .gte('attendance_date', startDate)
        .lte('attendance_date', endDate);

      if (error) throw error;
      return data || [];
    },
  });

  const { data: payrollData } = useQuery({
    queryKey: ['payroll-report'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('hr_payslips')
        .select(`
          *,
          hr_employees(first_name, last_name, employee_code)
        `)
        .order('month', { ascending: false });

      if (error) throw error;
      return data || [];
    },
  });

  // Calculate metrics
  const totalEmployees = employeesData?.length || 0;
  const totalWorkingHours = attendanceData?.reduce((sum, record) => sum + (Number(record.total_hours) || 0), 0) || 0;
  const totalPayroll = payrollData?.reduce((sum, payslip) => sum + Number(payslip.net_salary), 0) || 0;
  const averageHoursPerEmployee = totalEmployees > 0 ? totalWorkingHours / totalEmployees : 0;

  // Attendance analysis
  const attendanceRate = attendanceData?.length > 0 ? 
    (attendanceData.filter(record => record.status === 'present').length / attendanceData.length) * 100 : 0;

  // Daily attendance data
  const dailyAttendanceData = attendanceData?.reduce((acc, record) => {
    const date = format(new Date(record.attendance_date), 'MMM dd');
    if (!acc[date]) {
      acc[date] = { present: 0, late: 0, absent: 0 };
    }
    if (record.status === 'present') {
      acc[date].present += 1;
      if (record.is_late) acc[date].late += 1;
    } else {
      acc[date].absent += 1;
    }
    return acc;
  }, {} as Record<string, any>);

  const attendanceTrendData = Object.entries(dailyAttendanceData || {}).map(([date, data]) => ({
    date,
    ...data
  }));

  // Employee performance data with fixed relationship reference
  const employeePerformance = attendanceData?.reduce((acc, record) => {
    const employeeId = record.employee_id;
    const employeeName = record.hr_employees ? `${record.hr_employees.first_name} ${record.hr_employees.last_name}` : 'Unknown Employee';
    
    if (!acc[employeeId]) {
      acc[employeeId] = {
        name: employeeName,
        totalHours: 0,
        presentDays: 0,
        lateDays: 0,
        overtimeHours: 0
      };
    }
    
    acc[employeeId].totalHours += Number(record.total_hours) || 0;
    acc[employeeId].overtimeHours += Number(record.overtime_hours) || 0;
    
    if (record.status === 'present') {
      acc[employeeId].presentDays += 1;
      if (record.is_late) acc[employeeId].lateDays += 1;
    }
    
    return acc;
  }, {} as Record<string, any>);

  const topPerformers = Object.values(employeePerformance || {})
    .sort((a: any, b: any) => b.totalHours - a.totalHours)
    .slice(0, 10);

  // Monthly payroll trend
  const payrollTrend = payrollData?.reduce((acc, payslip) => {
    const monthKey = `${payslip.month}/${payslip.year}`;
    if (!acc[monthKey]) {
      acc[monthKey] = { total: 0, count: 0 };
    }
    acc[monthKey].total += Number(payslip.net_salary);
    acc[monthKey].count += 1;
    return acc;
  }, {} as Record<string, any>);

  const payrollTrendData = Object.entries(payrollTrend || {})
    .map(([month, data]: [string, any]) => ({
      month,
      totalPayroll: data.total,
      employeeCount: data.count,
      averageSalary: data.total / data.count
    }))
    .sort((a, b) => a.month.localeCompare(b.month));

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">Loading HRMS report...</div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-start">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">HRMS Report</h1>
          <p className="text-muted-foreground">
            Employee management and performance analytics
          </p>
        </div>
        <div className="flex gap-2">
          <DatePickerWithRange date={dateRange} setDate={setDateRange} />
          <Button variant="outline" className="flex items-center gap-2">
            <Download className="h-4 w-4" />
            Export
          </Button>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Employees</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalEmployees}</div>
            <p className="text-xs text-muted-foreground">active employees</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Attendance Rate</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{attendanceRate.toFixed(1)}%</div>
            <p className="text-xs text-muted-foreground">overall attendance</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Working Hours</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalWorkingHours.toFixed(0)}</div>
            <p className="text-xs text-muted-foreground">in selected period</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Payroll</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">₹{totalPayroll.toFixed(2)}</div>
            <p className="text-xs text-muted-foreground">salary expenses</p>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Attendance Trend</CardTitle>
            <CardDescription>Daily attendance pattern</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={attendanceTrendData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="present" fill="#10b981" name="Present" />
                <Bar dataKey="late" fill="#f59e0b" name="Late" />
                <Bar dataKey="absent" fill="#ef4444" name="Absent" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Payroll Trend</CardTitle>
            <CardDescription>Monthly payroll expenses</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={payrollTrendData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip formatter={(value, name) => [
                  name === 'totalPayroll' ? `₹${Number(value).toFixed(2)}` : Number(value).toFixed(0),
                  name === 'totalPayroll' ? 'Total Payroll' : 'Employee Count'
                ]} />
                <Line type="monotone" dataKey="totalPayroll" stroke="#8884d8" name="Total Payroll" />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Top Performers */}
      <Card>
        <CardHeader>
          <CardTitle>Top Performers</CardTitle>
          <CardDescription>Employees with highest working hours</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {topPerformers.map((employee: any, index) => (
              <div key={index} className="flex justify-between items-center p-3 border rounded-lg">
                <div className="flex items-center gap-3">
                  <Badge variant="secondary">#{index + 1}</Badge>
                  <div>
                    <p className="font-medium">{employee.name}</p>
                    <div className="flex gap-2 mt-1">
                      <span className="text-sm text-muted-foreground">
                        {employee.presentDays} days present
                      </span>
                      <span className="text-sm text-orange-600">
                        {employee.lateDays} late
                      </span>
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-bold text-blue-600">{employee.totalHours.toFixed(1)}h</p>
                  <p className="text-sm text-muted-foreground">
                    OT: {employee.overtimeHours.toFixed(1)}h
                  </p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default HRMSReport;
