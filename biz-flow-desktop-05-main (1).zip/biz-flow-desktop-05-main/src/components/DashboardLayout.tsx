import React from 'react';
import { Outlet, Link, useLocation } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';
import { Button } from '@/components/ui/button';
import { ModeToggle } from '@/components/ModeToggle';
import { useGranularPermissions } from '@/hooks/useGranularPermissions';
import {
  Menubar,
  MenubarContent,
  MenubarItem,
  MenubarMenu,
  MenubarTrigger,
} from '@/components/ui/menubar';
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarHeader,
  SidebarInset,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarProvider,
  SidebarTrigger,
} from '@/components/ui/sidebar';
import {
  BarChart3,
  Package,
  ChefHat,
  Warehouse,
  ShoppingCart,
  Receipt,
  Users,
  CreditCard,
  TrendingDown,
  Building2,
  ArrowLeftRight,
  FileText,
  UserCheck,
  UserCog,
  Settings,
  LogOut,
  LogIn,
} from 'lucide-react';

interface NavItem {
  name: string;
  href: string;
  icon: React.ComponentType<React.SVGProps<SVGSVGElement>>;
  permission: string;
}

const DashboardLayout = () => {
  const { user, signOut } = useAuth();
  const location = useLocation();
  const { hasPermission } = useGranularPermissions();

  const navItems: NavItem[] = [
    { name: 'Dashboard', href: '/dashboard', icon: BarChart3, permission: 'dashboard' },
    { name: 'Products', href: '/products', icon: Package, permission: 'products' },
    { name: 'Recipes', href: '/recipes', icon: ChefHat, permission: 'recipes' },
    { name: 'Stocks', href: '/stocks', icon: Warehouse, permission: 'stocks' },
    { name: 'POS', href: '/pos', icon: ShoppingCart, permission: 'pos' },
    { name: 'Bills', href: '/bills', icon: Receipt, permission: 'bills' },
    { name: 'Customers', href: '/customers', icon: Users, permission: 'customers' },
    { name: 'Credits', href: '/credits', icon: CreditCard, permission: 'credits' },
    { name: 'Expenses', href: '/expenses', icon: TrendingDown, permission: 'expenses' },
    { name: 'Shops', href: '/shops', icon: Building2, permission: 'shops' },
    { name: 'Stock Movements', href: '/stock-movements', icon: ArrowLeftRight, permission: 'stock-movements' },
    { name: 'Reports', href: '/reports', icon: FileText, permission: 'reports' },
    { name: 'HRMS', href: '/hrms', icon: UserCheck, permission: 'hrms' },
    { name: 'Auto Debit', href: '/auto-debit', icon: CreditCard, permission: 'auto-debit' },
    { name: 'Users', href: '/users', icon: UserCog, permission: 'users' },
    { name: 'Settings', href: '/settings', icon: Settings, permission: 'settings' },
  ];

  const filteredNavItems = navItems.filter(item => hasPermission(item.permission));

  const handleEmployeeLogin = () => {
    // Navigate to employee login page
    window.open('/employee-auth', '_blank', 'width=600,height=700,scrollbars=yes,resizable=yes');
  };

  const handleEmployeeLogout = () => {
    // Clear employee session from localStorage
    localStorage.removeItem('employeeSession');
    localStorage.removeItem('employeeData');
    // You could also show a toast notification here
  };

  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full">
        <Sidebar>
          <SidebarHeader className="border-b">
            <div className="px-6 py-4">
              <Link to="/" className="flex items-center space-x-2">
                <img 
                  src="/lovable-uploads/266f478f-6b7a-4c8a-b19c-9e278f7ad27e.png" 
                  alt="ABC Cafe Logo" 
                  className="h-8 w-auto"
                />
              </Link>
            </div>
          </SidebarHeader>
          
          <SidebarContent>
            <SidebarMenu>
              {filteredNavItems.map((item) => (
                <SidebarMenuItem key={item.name}>
                  <SidebarMenuButton 
                    asChild
                    isActive={location.pathname === item.href}
                  >
                    <Link to={item.href}>
                      <item.icon className="h-4 w-4" />
                      <span>{item.name}</span>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarContent>

          <SidebarFooter className="border-t">
            <div className="p-6">
              <Button variant="outline" className="w-full" onClick={signOut}>
                <LogOut className="h-4 w-4 mr-2" />
                Logout
              </Button>
            </div>
          </SidebarFooter>
        </Sidebar>

        <SidebarInset>
          {/* Header */}
          <header className="flex items-center justify-between h-16 px-4 border-b border-gray-200 dark:border-gray-700">
            <div className="flex items-center">
              <SidebarTrigger />
              <h1 className="text-lg font-semibold ml-4">
                {navItems.find(item => location.pathname.startsWith(item.href))?.name || 'Dashboard'}
              </h1>
            </div>
            <div className="flex items-center space-x-4">
              {/* Employee Login/Logout Menu */}
              <Menubar>
                <MenubarMenu>
                  <MenubarTrigger className="flex items-center gap-2">
                    <UserCheck className="h-4 w-4" />
                    Employee
                  </MenubarTrigger>
                  <MenubarContent>
                    <MenubarItem onClick={handleEmployeeLogin}>
                      <LogIn className="h-4 w-4 mr-2" />
                      Employee Login
                    </MenubarItem>
                    <MenubarItem onClick={handleEmployeeLogout}>
                      <LogOut className="h-4 w-4 mr-2" />
                      Employee Logout
                    </MenubarItem>
                  </MenubarContent>
                </MenubarMenu>
              </Menubar>
              
              <ModeToggle />
              <span>{user?.email}</span>
            </div>
          </header>

          {/* Page Content */}
          <main className="flex-1 overflow-x-hidden overflow-y-auto bg-gray-50 dark:bg-gray-900">
            <div className="container mx-auto py-6">
              <Outlet />
            </div>
          </main>
        </SidebarInset>
      </div>
    </SidebarProvider>
  );
};

export default DashboardLayout;
