
import React from "react";
import { Navigate } from "react-router-dom";
import { useEmployeeAuth } from "@/context/EmployeeAuthContext";

interface EmployeeProtectedRouteProps {
  children: React.ReactNode;
}

const EmployeeProtectedRoute = ({ children }: EmployeeProtectedRouteProps) => {
  const { employee, loading } = useEmployeeAuth();

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-lg">Loading...</div>
      </div>
    );
  }

  if (!employee) {
    return <Navigate to="/employee-auth" replace />;
  }

  return <>{children}</>;
};

export default EmployeeProtectedRoute;
