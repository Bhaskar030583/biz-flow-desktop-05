
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { Slider } from '@/components/ui/slider';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Volume2, VolumeX, Play, Square } from 'lucide-react';
import { useVoiceAlerts } from '@/hooks/useVoiceAlerts';

export const VoiceAlertSettings = () => {
  const { settings, updateSettings, testVoice, stopSpeech } = useVoiceAlerts();

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          {settings.enabled ? <Volume2 className="h-5 w-5" /> : <VolumeX className="h-5 w-5" />}
          Voice Alert Settings
        </CardTitle>
        <CardDescription>
          Configure voice announcements for sales and expenses
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Master Enable */}
        <div className="flex items-center justify-between">
          <Label htmlFor="voice-enabled" className="text-base font-medium">
            Enable Voice Alerts
          </Label>
          <Switch
            id="voice-enabled"
            checked={settings.enabled}
            onCheckedChange={(enabled) => updateSettings({ enabled })}
          />
        </div>

        {settings.enabled && (
          <>
            {/* Sales Alerts */}
            <div className="flex items-center justify-between">
              <Label htmlFor="sales-alerts" className="text-sm">
                Sales Announcements
              </Label>
              <Switch
                id="sales-alerts"
                checked={settings.salesAlerts}
                onCheckedChange={(salesAlerts) => updateSettings({ salesAlerts })}
              />
            </div>

            {/* Expense Alerts */}
            <div className="flex items-center justify-between">
              <Label htmlFor="expense-alerts" className="text-sm">
                Expense Announcements
              </Label>
              <Switch
                id="expense-alerts"
                checked={settings.expenseAlerts}
                onCheckedChange={(expenseAlerts) => updateSettings({ expenseAlerts })}
              />
            </div>

            {/* Volume Control */}
            <div className="space-y-2">
              <Label className="text-sm">Volume: {Math.round(settings.volume * 100)}%</Label>
              <Slider
                value={[settings.volume]}
                onValueChange={([volume]) => updateSettings({ volume })}
                max={1}
                min={0}
                step={0.1}
                className="w-full"
              />
            </div>

            {/* Speed Control */}
            <div className="space-y-2">
              <Label className="text-sm">Speech Rate: {settings.rate}x</Label>
              <Slider
                value={[settings.rate]}
                onValueChange={([rate]) => updateSettings({ rate })}
                max={2}
                min={0.5}
                step={0.1}
                className="w-full"
              />
            </div>

            {/* Pitch Control */}
            <div className="space-y-2">
              <Label className="text-sm">Pitch: {settings.pitch}x</Label>
              <Slider
                value={[settings.pitch]}
                onValueChange={([pitch]) => updateSettings({ pitch })}
                max={2}
                min={0.5}
                step={0.1}
                className="w-full"
              />
            </div>

            {/* Test Controls */}
            <div className="flex gap-2 pt-4">
              <Button onClick={testVoice} variant="outline" className="flex items-center gap-2">
                <Play className="h-4 w-4" />
                Test Voice
              </Button>
              <Button onClick={stopSpeech} variant="outline" className="flex items-center gap-2">
                <Square className="h-4 w-4" />
                Stop
              </Button>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
};
