import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Badge } from "@/components/ui/badge";
import { Settings, Plus, Edit, Trash2 } from "lucide-react";
import { toast } from 'sonner';

interface Category {
  value: string;
  label: string;
}

interface CategoryManagerProps {
  categories: Category[];
  onAddCategory: (category: Category) => void;
  onEditCategory: (oldValue: string, newCategory: Category) => void;
  onDeleteCategory: (value: string) => void;
}

const CategoryManager: React.FC<CategoryManagerProps> = ({
  categories,
  onAddCategory,
  onEditCategory,
  onDeleteCategory,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);
  const [newCategoryValue, setNewCategoryValue] = useState('');
  const [newCategoryLabel, setNewCategoryLabel] = useState('');

  const handleAddCategory = () => {
    if (!newCategoryLabel.trim()) {
      toast.error('Please enter a category name');
      return;
    }

    const categoryValue = newCategoryLabel.toLowerCase().replace(/\s+/g, '_');

    if (categories.some(cat => cat.value === categoryValue)) {
      toast.error('Category already exists');
      return;
    }

    onAddCategory({
      value: categoryValue,
      label: newCategoryLabel.trim()
    });

    setNewCategoryValue('');
    setNewCategoryLabel('');
    toast.success('Category added successfully');
  };

  const handleEditCategory = () => {
    if (!editingCategory || !newCategoryLabel.trim()) {
      toast.error('Please fill in the category label');
      return;
    }

    onEditCategory(editingCategory.value, {
      value: editingCategory.value,
      label: newCategoryLabel
    });

    setEditingCategory(null);
    setNewCategoryLabel('');
    toast.success('Category updated successfully');
  };

  const handleDeleteCategory = (value: string) => {
    onDeleteCategory(value);
    toast.success('Category deleted successfully');
  };

  const startEdit = (category: Category) => {
    setEditingCategory(category);
    setNewCategoryLabel(category.label);
  };

  const cancelEdit = () => {
    setEditingCategory(null);
    setNewCategoryLabel('');
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="flex items-center gap-2">
          <Settings size={16} />
          Manage Categories
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Manage Expense Categories</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          {/* Add New Category */}
          <div className="border rounded-lg p-4 space-y-4">
            <h3 className="font-medium flex items-center gap-2">
              <Plus size={16} />
              Add New Category
            </h3>
            <div className="space-y-4">
              <div>
                <Label htmlFor="category-name">Category Name</Label>
                <Input
                  id="category-name"
                  placeholder="e.g., Office Supplies, Travel Expenses"
                  value={newCategoryLabel}
                  onChange={(e) => setNewCategoryLabel(e.target.value)}
                />
                <p className="text-xs text-gray-500 mt-1">
                  Enter the name of your custom category
                </p>
              </div>
            </div>
            <Button onClick={handleAddCategory} className="w-full">
              Add Category
            </Button>
          </div>

          {/* Existing Categories */}
          <div className="space-y-4">
            <h3 className="font-medium">Existing Categories</h3>
            <div className="grid gap-2 max-h-60 overflow-y-auto">
              {categories.map((category) => (
                <div key={category.value} className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex items-center gap-3">
                    <Badge variant="outline">{category.value}</Badge>
                    <span>{category.label}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => startEdit(category)}
                      className="h-8 w-8 p-0"
                    >
                      <Edit size={14} />
                    </Button>
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-8 w-8 p-0 text-red-500 hover:text-red-600"
                        >
                          <Trash2 size={14} />
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>Delete Category</AlertDialogTitle>
                          <AlertDialogDescription>
                            Are you sure you want to delete the "{category.label}" category? 
                            This action cannot be undone.
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>Cancel</AlertDialogCancel>
                          <AlertDialogAction 
                            onClick={() => handleDeleteCategory(category.value)}
                            className="bg-red-500 hover:bg-red-600"
                          >
                            Delete
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Edit Category Dialog */}
        {editingCategory && (
          <Dialog open={!!editingCategory} onOpenChange={(open) => !open && cancelEdit()}>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Edit Category</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="edit-category-label">Display Label</Label>
                  <Input
                    id="edit-category-label"
                    value={newCategoryLabel}
                    onChange={(e) => setNewCategoryLabel(e.target.value)}
                  />
                </div>
                <div className="flex gap-2">
                  <Button onClick={handleEditCategory} className="flex-1">
                    Save Changes
                  </Button>
                  <Button variant="outline" onClick={cancelEdit} className="flex-1">
                    Cancel
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        )}
      </DialogContent>
    </Dialog>
  );
};

export default CategoryManager;
