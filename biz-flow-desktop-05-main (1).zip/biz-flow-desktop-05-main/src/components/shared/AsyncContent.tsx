
import React from 'react';
import { LoadingSpinner } from './LoadingSpinner';
import { ErrorDisplay } from './ErrorDisplay';
import { cn } from '@/lib/utils';

interface AsyncContentProps {
  loading: boolean;
  error: Error | string | null;
  data?: any;
  children: React.ReactNode;
  loadingText?: string;
  errorTitle?: string;
  onRetry?: () => void;
  retryText?: string;
  emptyState?: React.ReactNode;
  className?: string;
  centerLoading?: boolean;
}

export const AsyncContent: React.FC<AsyncContentProps> = ({
  loading,
  error,
  data,
  children,
  loadingText = 'Loading...',
  errorTitle = 'Error',
  onRetry,
  retryText = 'Try again',
  emptyState,
  className,
  centerLoading = true
}) => {
  if (loading) {
    return (
      <div className={cn(centerLoading ? 'flex items-center justify-center min-h-[200px]' : '', className)}>
        <LoadingSpinner text={loadingText} centered={centerLoading} />
      </div>
    );
  }

  if (error) {
    return (
      <div className={cn('', className)}>
        <ErrorDisplay
          error={error}
          title={errorTitle}
          onRetry={onRetry}
          retryText={retryText}
        />
      </div>
    );
  }

  // Check for empty state (if data is an array and empty, or if data is falsy)
  if (emptyState && ((Array.isArray(data) && data.length === 0) || !data)) {
    return <div className={className}>{emptyState}</div>;
  }

  return <div className={className}>{children}</div>;
};
