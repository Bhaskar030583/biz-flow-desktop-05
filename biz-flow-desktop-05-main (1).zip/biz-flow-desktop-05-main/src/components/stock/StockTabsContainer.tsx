
import React from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import StockForm from "./StockForm";
import NewStockManagement from "./NewStockManagement";
import ProductStockManagement from "./ProductStockManagement";
import { AdvancedReporting } from "./AdvancedReporting";
import LossTracking from "./LossTracking";
import ShiftStockChangesReport from "./ShiftStockChangesReport";
import StockListTab from "./StockListTab";

interface StockTabsContainerProps {
  showForm: boolean;
  handleStockAdded: () => void;
  setShowForm: (show: boolean) => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

const StockTabsContainer = ({
  showForm,
  handleStockAdded,
  setShowForm,
  activeTab,
  setActiveTab,
}: StockTabsContainerProps) => {
  return (
    <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
      <TabsList className="grid w-full grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-1">
        <TabsTrigger value="management" className="text-xs lg:text-sm">Stock Management</TabsTrigger>
        <TabsTrigger value="products" className="text-xs lg:text-sm">Product Assignment</TabsTrigger>
        <TabsTrigger value="stock-list" className="text-xs lg:text-sm">Stock List</TabsTrigger>
        <TabsTrigger value="reporting" className="text-xs lg:text-sm">Reports</TabsTrigger>
        <TabsTrigger value="shift-reports" className="text-xs lg:text-sm">Shift Reports</TabsTrigger>
        <TabsTrigger value="loss-tracking" className="text-xs lg:text-sm">Loss Tracking</TabsTrigger>
      </TabsList>

      <TabsContent value="management" className="space-y-6">
        <NewStockManagement 
          onSuccess={handleStockAdded}
          onCancel={() => setShowForm(false)}
        />
      </TabsContent>

      <TabsContent value="products" className="space-y-6">
        <ProductStockManagement />
      </TabsContent>

      <TabsContent value="stock-list" className="space-y-6">
        <StockListTab />
      </TabsContent>

      <TabsContent value="reporting" className="space-y-6">
        <AdvancedReporting />
      </TabsContent>

      <TabsContent value="shift-reports" className="space-y-6">
        <ShiftStockChangesReport />
      </TabsContent>

      <TabsContent value="loss-tracking" className="space-y-6">
        <LossTracking />
      </TabsContent>
    </Tabs>
  );
};

export default StockTabsContainer;
