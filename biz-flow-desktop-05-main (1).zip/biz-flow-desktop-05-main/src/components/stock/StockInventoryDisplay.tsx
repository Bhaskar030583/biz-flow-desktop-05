
import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Package2, Search, Plus } from "lucide-react";
import { format } from "date-fns";

interface StockItem {
  productId: string;
  productName: string;
  category: string;
  openingStock: number;
  actualStock: number;
  availableStock: number;
  stockAdded: number;
  sku?: string;
}

interface StockInventoryDisplayProps {
  stockItems: StockItem[];
  totalStockAdded: number;
  isAdmin: boolean;
  onUpdateStock: (productId: string, field: keyof StockItem, value: number) => void;
  stockDate?: string;
}

const StockInventoryDisplay: React.FC<StockInventoryDisplayProps> = ({
  stockItems,
  totalStockAdded,
  isAdmin,
  onUpdateStock,
  stockDate = format(new Date(), 'yyyy-MM-dd')
}) => {
  const [searchTerm, setSearchTerm] = useState("");
  const [stockInputValues, setStockInputValues] = useState<Record<string, string>>({});

  // Filter products based on search term (search by name, SKU, or category)
  const filteredItems = stockItems.filter(item =>
    item.productName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (item.sku && item.sku.toLowerCase().includes(searchTerm.toLowerCase())) ||
    item.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleStockInputChange = (productId: string, value: string) => {
    setStockInputValues(prev => ({
      ...prev,
      [productId]: value
    }));
  };

  const handleUpdateStock = (productId: string) => {
    const inputValue = stockInputValues[productId];
    if (inputValue === undefined || inputValue === '') {
      return;
    }
    
    const quantity = parseInt(inputValue) || 0;
    onUpdateStock(productId, 'stockAdded', quantity);
    
    // Clear the input for this product
    setStockInputValues(prev => ({
      ...prev,
      [productId]: ''
    }));
  };

  return (
    <Card className="h-fit border border-gray-200 shadow-sm bg-white">
      <CardHeader className="pb-3 bg-gradient-to-r from-blue-50 to-indigo-50 border-b">
        <CardTitle className="flex items-center gap-3 text-base font-semibold text-gray-800">
          <div className="p-1.5 bg-blue-100 rounded-md">
            <Package2 className="h-4 w-4 text-blue-600" />
          </div>
          <div className="flex-1">
            <span>Quick Add Stock - Update "Stock Added" Column</span>
            <div className="text-xs font-normal text-gray-600">
              {stockItems.length} {stockItems.length === 1 ? 'product' : 'products'} • Date: {stockDate}
            </div>
          </div>
          {totalStockAdded > 0 && (
            <Badge variant="default" className="bg-green-100 text-green-700 border-green-200 text-xs px-2 py-1">
              +{totalStockAdded} items to add
            </Badge>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent className="p-4">
        {/* Search Input */}
        <div className="relative mb-4">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 dark:text-gray-500 h-4 w-4" />
          <Input
            placeholder="Search by Product Name, SKU, or Category..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-600"
          />
        </div>

        {stockItems.length === 0 ? (
          <div className="text-center py-8 bg-gray-50 rounded-lg border border-gray-200">
            <div className="w-12 h-12 mx-auto mb-3 bg-gray-100 rounded-full flex items-center justify-center">
              <Package2 className="h-6 w-6 text-gray-400" />
            </div>
            <h3 className="text-base font-medium text-gray-700 mb-2">No Products Assigned</h3>
            <p className="text-sm text-gray-500 max-w-md mx-auto">
              Products must be assigned to this store first. Use the 'Assign Products' button to get started.
            </p>
          </div>
        ) : filteredItems.length === 0 ? (
          <div className="text-center py-8 text-gray-500 dark:text-gray-400">
            No products match your search
          </div>
        ) : (
          <div className="space-y-4">
            {/* Table Header */}
            <div className="grid grid-cols-6 gap-4 p-3 bg-gray-100 dark:bg-gray-800 rounded-lg font-medium text-sm">
              <div>Date</div>
              <div>SKU</div>
              <div>Product Name</div>
              <div>Category</div>
              <div>Current Stock</div>
              <div>Stock Added</div>
            </div>
            
            {/* Table Rows */}
            <div className="space-y-2 max-h-96 overflow-y-auto">
              {filteredItems.map((item) => (
                <div key={item.productId} className="grid grid-cols-6 gap-4 p-3 bg-white border border-gray-200 rounded-lg items-center">
                  {/* Date */}
                  <div className="text-sm text-gray-600">
                    {stockDate}
                  </div>
                  
                  {/* SKU */}
                  <div className="text-sm font-mono text-gray-600">
                    {item.sku || 'N/A'}
                  </div>
                  
                  {/* Product Name */}
                  <div>
                    <h4 className="font-medium text-gray-900 text-sm">{item.productName}</h4>
                  </div>
                  
                  {/* Category */}
                  <div>
                    <Badge variant="outline" className="text-xs border-gray-200 text-gray-600">
                      {item.category}
                    </Badge>
                  </div>
                  
                  {/* Current Stock */}
                  <div>
                    <Badge 
                      variant="outline" 
                      className={`text-xs ${
                        item.actualStock > 10 
                          ? 'bg-green-50 text-green-700 border-green-200' 
                          : item.actualStock > 0 
                            ? 'bg-yellow-50 text-yellow-700 border-yellow-200'
                            : 'bg-red-50 text-red-700 border-red-200'
                      }`}
                    >
                      {item.actualStock}
                    </Badge>
                  </div>
                  
                  {/* Stock Added Input */}
                  <div className="flex items-center gap-2">
                    <div className="w-20">
                      <Input
                        type="text"
                        placeholder="0"
                        value={stockInputValues[item.productId] || ''}
                        onChange={(e) => handleStockInputChange(item.productId, e.target.value)}
                        className="text-center bg-white border-gray-200 text-sm h-8"
                      />
                    </div>
                    <Button
                      size="sm"
                      onClick={() => handleUpdateStock(item.productId)}
                      disabled={!stockInputValues[item.productId]}
                      className="px-3 h-8"
                    >
                      <Plus className="h-3 w-3" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default StockInventoryDisplay;
