
import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Search } from "lucide-react";
import ProductStockTable from "./ProductStockTable";
import StockFilters from "./StockFilters";
import StockEditDialog from "./StockEditDialog";
import { AssignedProduct } from "./hooks/useAssignedProducts";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/context/AuthContext";
import { toast } from "sonner";

interface StockListContentProps {
  assignedProducts: AssignedProduct[];
  filteredProducts: AssignedProduct[];
  searchTerm: string;
  setSearchTerm: (term: string) => void;
  shopFilter: string;
  setShopFilter: (filter: string) => void;
  productFilter: string;
  setProductFilter: (filter: string) => void;
  paymentModeFilter: string;
  setPaymentModeFilter: (filter: string) => void;
  shops: any[];
  products: any[];
  onStockUpdated?: () => void;
}

const StockListContent = ({
  assignedProducts,
  filteredProducts,
  searchTerm,
  setSearchTerm,
  shopFilter,
  setShopFilter,
  productFilter,
  setProductFilter,
  paymentModeFilter,
  setPaymentModeFilter,
  shops,
  products,
  onStockUpdated
}: StockListContentProps) => {
  const { user } = useAuth();
  const [editingProduct, setEditingProduct] = useState<AssignedProduct | null>(null);
  const [editStockValues, setEditStockValues] = useState({
    opening_stock: 0,
    stock_added: 0,
    actual_stock: 0
  });
  const [isUpdatingStock, setIsUpdatingStock] = useState(false);
  const [addStockQuantities, setAddStockQuantities] = useState<Record<string, number>>({});
  const [updatingStock, setUpdatingStock] = useState<Record<string, boolean>>({});

  // Debug logging for product assignments
  React.useEffect(() => {
    if (assignedProducts.length > 0) {
      console.log('📊 [StockListContent] Product assignments debug:', {
        totalProducts: assignedProducts.length,
        sampleProducts: assignedProducts.slice(0, 3).map(p => ({
          name: p.name,
          actualStock: p.actual_stock,
          actualStockType: typeof p.actual_stock,
          openingStock: p.opening_stock,
          stockAdded: p.stock_added
        })),
        productsByStore: assignedProducts.reduce((acc, product) => {
          const storeName = product.shop_name || 'Unknown Store';
          if (!acc[storeName]) {
            acc[storeName] = [];
          }
          acc[storeName].push({
            name: product.name,
            productId: product.id,
            assignmentId: product.assignment_id,
            shopId: product.shop_id,
            actualStock: product.actual_stock
          });
          return acc;
        }, {} as Record<string, any[]>)
      });
    }
  }, [assignedProducts]);

  // Debug logging for filtered products
  React.useEffect(() => {
    if (filteredProducts.length > 0) {
      console.log('🔍 [StockListContent] Filtered products debug:', {
        totalFiltered: filteredProducts.length,
        sampleFiltered: filteredProducts.slice(0, 3).map(p => ({
          name: p.name,
          actualStock: p.actual_stock,
          actualStockType: typeof p.actual_stock
        }))
      });
    }
  }, [filteredProducts]);

  const handleEditStock = (product: AssignedProduct) => {
    setEditingProduct(product);
    setEditStockValues({
      opening_stock: product.opening_stock || 0,
      stock_added: product.stock_added || 0,
      actual_stock: product.actual_stock || 0
    });
  };

  const handleUpdateStock = async () => {
    if (!editingProduct || !user?.id) {
      toast.error("Missing product or user information");
      return;
    }

    setIsUpdatingStock(true);

    try {
      const today = new Date().toISOString().split('T')[0];
      
      // Check if stock record exists for today
      const { data: existingStock, error: checkError } = await supabase
        .from('stocks')
        .select('id')
        .eq('product_id', editingProduct.id)
        .eq('hr_shop_id', editingProduct.shop_id)
        .eq('stock_date', today)
        .eq('user_id', user.id)
        .maybeSingle();

      if (checkError) {
        throw checkError;
      }

      if (existingStock) {
        // Update existing stock record
        const { error: updateError } = await supabase
          .from('stocks')
          .update({
            opening_stock: editStockValues.opening_stock,
            stock_added: editStockValues.stock_added,
            actual_stock: editStockValues.actual_stock,
            closing_stock: editStockValues.opening_stock + editStockValues.stock_added
          })
          .eq('id', existingStock.id);

        if (updateError) throw updateError;
      } else {
        // Create new stock record
        const { error: insertError } = await supabase
          .from('stocks')
          .insert({
            product_id: editingProduct.id,
            shop_id: editingProduct.shop_id,
            hr_shop_id: editingProduct.shop_id,
            stock_date: today,
            opening_stock: editStockValues.opening_stock,
            stock_added: editStockValues.stock_added,
            actual_stock: editStockValues.actual_stock,
            closing_stock: editStockValues.opening_stock + editStockValues.stock_added,
            user_id: user.id
          });

        if (insertError) throw insertError;
      }

      toast.success(`Stock updated for ${editingProduct.name}`);
      setEditingProduct(null);
      
      if (onStockUpdated) {
        onStockUpdated();
      }
    } catch (error: any) {
      console.error('Error updating stock:', error);
      toast.error(error.message || 'Failed to update stock');
    } finally {
      setIsUpdatingStock(false);
    }
  };

  const handleAddStock = async (productId: string, assignmentId: string) => {
    const quantity = addStockQuantities[productId];
    if (!quantity || !user?.id) return;

    setUpdatingStock(prev => ({ ...prev, [productId]: true }));

    try {
      const today = new Date().toISOString().split('T')[0];
      const product = filteredProducts.find(p => p.id === productId);
      
      if (!product) {
        throw new Error("Product not found");
      }

      // Check if stock record exists for today
      const { data: existingStock, error: checkError } = await supabase
        .from('stocks')
        .select('*')
        .eq('product_id', productId)
        .eq('hr_shop_id', product.shop_id)
        .eq('stock_date', today)
        .eq('user_id', user.id)
        .maybeSingle();

      if (checkError) throw checkError;

      if (existingStock) {
        // Update existing stock record
        const newStockAdded = (existingStock.stock_added || 0) + quantity;
        const newClosingStock = existingStock.opening_stock + newStockAdded;
        
        const { error: updateError } = await supabase
          .from('stocks')
          .update({
            stock_added: newStockAdded,
            closing_stock: newClosingStock,
            actual_stock: newClosingStock // Update actual stock to match new closing stock
          })
          .eq('id', existingStock.id);

        if (updateError) throw updateError;
      } else {
        // Create new stock record
        const openingStock = product.opening_stock || 0;
        const newClosingStock = openingStock + quantity;
        
        const { error: insertError } = await supabase
          .from('stocks')
          .insert({
            product_id: productId,
            shop_id: product.shop_id,
            hr_shop_id: product.shop_id,
            stock_date: today,
            opening_stock: openingStock,
            stock_added: quantity,
            closing_stock: newClosingStock,
            actual_stock: newClosingStock,
            user_id: user.id
          });

        if (insertError) throw insertError;
      }

      toast.success(`Added ${quantity} units to ${product.name}`);
      
      // Clear the input
      setAddStockQuantities(prev => ({ ...prev, [productId]: 0 }));
      
      if (onStockUpdated) {
        onStockUpdated();
      }
    } catch (error: any) {
      console.error('Error adding stock:', error);
      toast.error(error.message || 'Failed to add stock');
    } finally {
      setUpdatingStock(prev => ({ ...prev, [productId]: false }));
    }
  };

  const handleRemoveProduct = async (assignmentId: string, productName: string) => {
    if (!user?.id) return;

    try {
      const { error } = await supabase
        .from('product_shops')
        .delete()
        .eq('id', assignmentId)
        .eq('user_id', user.id);

      if (error) throw error;

      toast.success(`${productName} has been removed from the store`);
      
      if (onStockUpdated) {
        onStockUpdated();
      }
    } catch (error: any) {
      console.error('Error removing product:', error);
      toast.error(error.message || 'Failed to remove product');
    }
  };

  const handleDeleteStock = async (productId: string, shopId: string) => {
    if (!user?.id) return;

    try {
      const today = new Date().toISOString().split('T')[0];
      
      const { error } = await supabase
        .from('stocks')
        .delete()
        .eq('product_id', productId)
        .eq('hr_shop_id', shopId)
        .eq('stock_date', today)
        .eq('user_id', user.id);

      if (error) throw error;

      toast.success('Stock record deleted');
      
      if (onStockUpdated) {
        onStockUpdated();
      }
    } catch (error: any) {
      console.error('Error deleting stock:', error);
      toast.error(error.message || 'Failed to delete stock');
    }
  };

  return (
    <>
      <Card className="transition-all duration-200 hover:shadow-md">
        <CardHeader className="flex flex-col space-y-4 sm:flex-row sm:items-center sm:justify-between sm:space-y-0 pb-4">
          <CardTitle>
            Assigned Products Stock 
            {assignedProducts.length > 0 && ` (${assignedProducts.length} products)`}
          </CardTitle>
          
          <StockFilters 
            searchTerm={searchTerm}
            setSearchTerm={setSearchTerm}
            shopFilter={shopFilter || "_all"}
            setShopFilter={setShopFilter}
            productFilter={productFilter || "_all"}
            setProductFilter={setProductFilter}
            shops={shops}
            products={products}
            paymentModeFilter={paymentModeFilter || "_all"}
            setPaymentModeFilter={setPaymentModeFilter}
          />
        </CardHeader>
        <CardContent>
          {assignedProducts.length === 0 ? (
            <div className="text-center max-w-md mx-auto py-12">
              <div className="rounded-full bg-muted flex items-center justify-center w-12 h-12 mx-auto mb-4">
                <Search className="h-6 w-6 text-muted-foreground" />
              </div>
              <h3 className="text-lg font-medium mb-2">No Assigned Products Found</h3>
              <p className="text-muted-foreground mb-6">
                No products have been assigned to stores. Please assign products to stores to get started.
              </p>
            </div>
          ) : (
            <>
              <ProductStockTable 
                filteredProducts={filteredProducts}
                isAdmin={false}
                addStockQuantities={addStockQuantities}
                setAddStockQuantities={setAddStockQuantities}
                updatingStock={updatingStock}
                onAddStock={handleAddStock}
                onEditStock={handleEditStock}
                onRemoveProduct={handleRemoveProduct}
                onDeleteStock={handleDeleteStock}
              />
              
              <div className="mt-4 text-sm text-muted-foreground text-center">
                Showing {filteredProducts.length} of {assignedProducts.length} assigned products
                {(searchTerm || shopFilter !== "_all" || productFilter !== "_all") && " (filtered)"}
              </div>
            </>
          )}
        </CardContent>
      </Card>

      <StockEditDialog
        editingProduct={editingProduct}
        setEditingProduct={setEditingProduct}
        editStockValues={editStockValues}
        setEditStockValues={setEditStockValues}
        selectedShop={editingProduct?.shop_id || ""}
        shops={shops}
        onUpdateStock={handleUpdateStock}
        isUpdatingStock={isUpdatingStock}
      />
    </>
  );
};

export default StockListContent;
