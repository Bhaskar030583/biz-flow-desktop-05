
import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Download, CalendarIcon, Filter, RotateCcw } from "lucide-react";
import { format, subDays } from "date-fns";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/context/AuthContext";
import { exportToExcel } from "@/utils/exportUtils";
import { toast } from "sonner";

interface ShiftStockChange {
  id: string;
  date: string;
  shift_name: string;
  product_name: string;
  category: string;
  store_name: string;
  opening_stock: number;
  closing_stock: number;
  actual_stock: number;
  stock_added: number;
  sales_quantity: number;
  variance: number;
  operator_name: string;
}

const ShiftStockChangesReport = () => {
  const { user } = useAuth();
  const [selectedDate, setSelectedDate] = useState<Date>(subDays(new Date(), 1));
  const [categoryFilter, setCategoryFilter] = useState<string>("all");
  const [productFilter, setProductFilter] = useState<string>("all");
  const [storeFilter, setStoreFilter] = useState<string>("all");
  const [showCalendar, setShowCalendar] = useState(false);

  const { data: shiftStockChanges, isLoading, refetch } = useQuery({
    queryKey: ['shift-stock-changes', selectedDate, categoryFilter, productFilter, storeFilter],
    queryFn: async (): Promise<ShiftStockChange[]> => {
      if (!user?.id) return [];

      const dateStr = format(selectedDate, 'yyyy-MM-dd');
      
      console.log('📊 [ShiftReport] Fetching shift stock changes for date:', dateStr);

      // Query shift stock entries with related data
      let query = supabase
        .from('shift_stock_entries')
        .select(`
          id,
          opening_stock,
          closing_stock,
          actual_stock,
          stock_added,
          sales_quantity,
          variance,
          operator_name,
          shift_id,
          stocks!inner (
            stock_date,
            product_id,
            hr_shop_id,
            products!inner (
              name,
              category
            ),
            hr_stores (
              store_name
            )
          ),
          hr_shifts (
            shift_name
          )
        `)
        .eq('stocks.stock_date', dateStr);

      const { data, error } = await query;

      if (error) {
        console.error('❌ [ShiftReport] Error fetching shift stock changes:', error);
        throw error;
      }

      console.log('📊 [ShiftReport] Raw shift stock data:', data);

      if (!data || data.length === 0) {
        console.log('⚠️ [ShiftReport] No shift stock entries found for date:', dateStr);
        return [];
      }

      // Transform the data
      const transformedData: ShiftStockChange[] = data
        .filter(entry => entry.stocks && entry.stocks.products)
        .map(entry => ({
          id: entry.id,
          date: entry.stocks.stock_date,
          shift_name: entry.hr_shifts?.shift_name || 'Unknown Shift',
          product_name: entry.stocks.products.name,
          category: entry.stocks.products.category,
          store_name: entry.stocks.hr_stores?.store_name || 'Unknown Store',
          opening_stock: entry.opening_stock || 0,
          closing_stock: entry.closing_stock || 0,
          actual_stock: entry.actual_stock || 0,
          stock_added: entry.stock_added || 0,
          sales_quantity: entry.sales_quantity || 0,
          variance: entry.variance || 0,
          operator_name: entry.operator_name || 'Unknown'
        }));

      // Apply filters
      let filteredData = transformedData;

      if (categoryFilter !== "all") {
        filteredData = filteredData.filter(item => item.category === categoryFilter);
      }

      if (productFilter !== "all") {
        filteredData = filteredData.filter(item => item.product_name === productFilter);
      }

      if (storeFilter !== "all") {
        filteredData = filteredData.filter(item => item.store_name === storeFilter);
      }

      console.log('📊 [ShiftReport] Filtered shift stock changes:', filteredData);
      return filteredData;
    },
    enabled: !!user?.id
  });

  // Get unique categories, products, and stores for filters
  const { data: filterOptions } = useQuery({
    queryKey: ['shift-report-filter-options'],
    queryFn: async () => {
      const { data: products, error: productsError } = await supabase
        .from('products')
        .select('name, category')
        .eq('user_id', user?.id)
        .order('name');
      
      if (productsError) throw productsError;

      const { data: stores, error: storesError } = await supabase
        .from('hr_stores')
        .select('store_name')
        .order('store_name');

      if (storesError) throw storesError;

      const categories = [...new Set(products?.map(p => p.category) || [])];
      const productNames = products?.map(p => p.name) || [];
      const storeNames = stores?.map(s => s.store_name) || [];

      return { categories, products: productNames, stores: storeNames };
    },
    enabled: !!user?.id
  });

  const handleExportData = () => {
    if (!shiftStockChanges || shiftStockChanges.length === 0) {
      toast.warning("No data to export");
      return;
    }

    const exportData = shiftStockChanges.map(item => ({
      Date: item.date,
      Shift: item.shift_name,
      Store: item.store_name,
      Product: item.product_name,
      Category: item.category,
      "Opening Stock": item.opening_stock,
      "Stock Added": item.stock_added,
      "Sales Quantity": item.sales_quantity,
      "Closing Stock": item.closing_stock,
      "Actual Stock": item.actual_stock,
      "Variance": item.variance,
      "Operator": item.operator_name
    }));

    try {
      exportToExcel(exportData, `shift_stock_changes_${format(selectedDate, 'yyyy-MM-dd')}`);
      toast.success("Data exported successfully");
    } catch (error) {
      console.error("Export error:", error);
      toast.error("Failed to export data");
    }
  };

  const resetFilters = () => {
    setCategoryFilter("all");
    setProductFilter("all");
    setStoreFilter("all");
    setSelectedDate(subDays(new Date(), 1));
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <RotateCcw className="h-5 w-5" />
          Shift-wise Stock Changes Report
        </CardTitle>
        
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
          {/* Date Filter */}
          <div className="space-y-2">
            <Label>Select Date</Label>
            <Popover open={showCalendar} onOpenChange={setShowCalendar}>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className="w-full justify-start text-left font-normal"
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {format(selectedDate, "PPP")}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0">
                <Calendar
                  mode="single"
                  selected={selectedDate}
                  onSelect={(date) => {
                    if (date) {
                      setSelectedDate(date);
                      setShowCalendar(false);
                    }
                  }}
                  initialFocus
                />
              </PopoverContent>
            </Popover>
          </div>

          {/* Store Filter */}
          <div className="space-y-2">
            <Label>Store</Label>
            <Select value={storeFilter} onValueChange={setStoreFilter}>
              <SelectTrigger>
                <SelectValue placeholder="All Stores" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Stores</SelectItem>
                {filterOptions?.stores.map(store => (
                  <SelectItem key={store} value={store}>
                    {store}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Category Filter */}
          <div className="space-y-2">
            <Label>Category</Label>
            <Select value={categoryFilter} onValueChange={setCategoryFilter}>
              <SelectTrigger>
                <SelectValue placeholder="All Categories" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                {filterOptions?.categories.map(category => (
                  <SelectItem key={category} value={category}>
                    {category}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Product Filter */}
          <div className="space-y-2">
            <Label>Product</Label>
            <Select value={productFilter} onValueChange={setProductFilter}>
              <SelectTrigger>
                <SelectValue placeholder="All Products" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Products</SelectItem>
                {filterOptions?.products.map(product => (
                  <SelectItem key={product} value={product}>
                    {product}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Action Buttons */}
          <div className="space-y-2">
            <Label>Actions</Label>
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={resetFilters}
                className="flex-1"
              >
                <Filter className="h-4 w-4 mr-1" />
                Reset
              </Button>
              <Button
                onClick={handleExportData}
                size="sm"
                className="flex-1"
                disabled={!shiftStockChanges || shiftStockChanges.length === 0}
              >
                <Download className="h-4 w-4 mr-1" />
                Export
              </Button>
            </div>
          </div>
        </div>
      </CardHeader>

      <CardContent>
        {isLoading ? (
          <div className="text-center py-8">Loading shift stock changes...</div>
        ) : !shiftStockChanges || shiftStockChanges.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            No shift stock changes found for the selected filters.
            <br />
            <span className="text-sm">Try selecting a different date or adjusting filters.</span>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <Badge variant="secondary">
                {shiftStockChanges.length} shift stock changes found
              </Badge>
            </div>

            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Shift</TableHead>
                    <TableHead>Store</TableHead>
                    <TableHead>Product</TableHead>
                    <TableHead>Category</TableHead>
                    <TableHead className="text-right">Opening</TableHead>
                    <TableHead className="text-right">Added</TableHead>
                    <TableHead className="text-right">Sales</TableHead>
                    <TableHead className="text-right">Closing</TableHead>
                    <TableHead className="text-right">Actual</TableHead>
                    <TableHead className="text-right">Variance</TableHead>
                    <TableHead>Operator</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {shiftStockChanges.map((item) => (
                    <TableRow key={item.id}>
                      <TableCell>
                        <Badge variant="outline">{item.shift_name}</Badge>
                      </TableCell>
                      <TableCell className="font-medium">{item.store_name}</TableCell>
                      <TableCell>{item.product_name}</TableCell>
                      <TableCell>
                        <Badge variant="secondary">{item.category}</Badge>
                      </TableCell>
                      <TableCell className="text-right">{item.opening_stock}</TableCell>
                      <TableCell className="text-right text-green-600">
                        {item.stock_added > 0 ? `+${item.stock_added}` : item.stock_added}
                      </TableCell>
                      <TableCell className="text-right text-red-600">
                        {item.sales_quantity > 0 ? `-${item.sales_quantity}` : item.sales_quantity}
                      </TableCell>
                      <TableCell className="text-right font-medium">{item.closing_stock}</TableCell>
                      <TableCell className="text-right">{item.actual_stock}</TableCell>
                      <TableCell className="text-right">
                        <Badge 
                          variant={item.variance === 0 ? "secondary" : item.variance > 0 ? "default" : "destructive"}
                        >
                          {item.variance > 0 ? `+${item.variance}` : item.variance}
                        </Badge>
                      </TableCell>
                      <TableCell>{item.operator_name}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default ShiftStockChangesReport;
