
import React from "react";
import { LossType } from "./LossFilters";

interface LossFormData {
  product_id: string;
  hr_shop_id: string;
  shift_id: string;
  loss_type: LossType;
  quantity_lost: number;
  reason: string | null;
  operator_name: string | null;
}

export const useLossFormValidation = () => {
  const isValidLossType = (value: string): value is LossType => {
    const validLossTypes: LossType[] = ["theft", "damage", "expiry", "spillage", "breakage", "other"];
    return validLossTypes.includes(value as LossType);
  };

  const validateFormData = (formData: Partial<LossFormData>) => {
    // Validate required fields
    if (!formData.product_id || !formData.hr_shop_id || !formData.loss_type || !formData.quantity_lost) {
      console.error('❌ [LossFormModal] Missing required fields');
      return false;
    }
    
    if (!isValidLossType(formData.loss_type)) {
      console.error('❌ [LossFormModal] Invalid loss type');
      return false;
    }
    
    return true;
  };

  const createValidatedData = (formData: Partial<LossFormData>): LossFormData => {
    return {
      product_id: formData.product_id!,
      hr_shop_id: formData.hr_shop_id!,
      shift_id: formData.shift_id || "",
      loss_type: formData.loss_type as LossType,
      quantity_lost: formData.quantity_lost!,
      reason: formData.reason || null,
      operator_name: formData.operator_name || null,
    };
  };

  return {
    validateFormData,
    createValidatedData
  };
};
