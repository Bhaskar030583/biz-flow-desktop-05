
import React from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { LossType } from "./LossFilters";
import { X } from "lucide-react";
import { LossFormFields } from "./LossFormFields";
import { useLossFormValidation } from "./LossFormValidation";
import { Store, Product, Shift } from "@/types/stock";

interface LossFormData {
  product_id: string;
  hr_shop_id: string;
  shift_id: string;
  loss_type: LossType;
  quantity_lost: number;
  reason: string | null;
  operator_name: string | null;
}

interface LossFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: LossFormData) => void;
  isSubmitting: boolean;
  stores?: Store[];
  products?: Product[];
  shifts?: Shift[];
}

export const LossFormModal: React.FC<LossFormModalProps> = ({
  isOpen,
  onClose,
  onSubmit,
  isSubmitting,
  stores,
  products,
  shifts
}) => {
  const [formData, setFormData] = React.useState<Partial<LossFormData>>({});
  const { validateFormData, createValidatedData } = useLossFormValidation();

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    
    console.log('📝 [LossFormModal] Form submitted with data:', formData);
    
    if (!validateFormData(formData)) {
      return;
    }
    
    const data = createValidatedData(formData);
    console.log('✅ [LossFormModal] Submitting validated data:', data);
    onSubmit(data);
  };

  const handleInputChange = (field: keyof LossFormData, value: any) => {
    console.log(`📝 [LossFormModal] Updating ${field}:`, value);
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  // Reset form when modal closes
  React.useEffect(() => {
    if (!isOpen) {
      setFormData({});
    }
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
      <Card className="w-full max-w-md max-h-[90vh] overflow-y-auto">
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Record Loss</CardTitle>
          <Button variant="ghost" size="sm" onClick={onClose}>
            <X className="h-4 w-4" />
          </Button>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <LossFormFields
              formData={formData}
              onInputChange={handleInputChange}
              stores={stores}
              products={products}
              shifts={shifts}
            />

            <div className="flex gap-2 pt-4">
              <Button type="submit" disabled={isSubmitting} className="flex-1">
                {isSubmitting ? "Recording..." : "Record Loss"}
              </Button>
              <Button
                type="button"
                variant="outline"
                onClick={onClose}
                className="flex-1"
              >
                Cancel
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};
