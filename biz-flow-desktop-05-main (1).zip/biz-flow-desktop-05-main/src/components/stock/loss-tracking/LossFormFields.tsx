
import React from "react";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { LossType } from "./LossFilters";
import { Store, Product, Shift } from "@/types/stock";

interface LossFormData {
  product_id: string;
  hr_shop_id: string;
  shift_id: string;
  loss_type: LossType;
  quantity_lost: number;
  reason: string | null;
  operator_name: string | null;
}

interface LossFormFieldsProps {
  formData: Partial<LossFormData>;
  onInputChange: (field: keyof LossFormData, value: any) => void;
  stores?: Store[];
  products?: Product[];
  shifts?: Shift[];
}

export const LossFormFields: React.FC<LossFormFieldsProps> = ({
  formData,
  onInputChange,
  stores,
  products,
  shifts
}) => {
  return (
    <div className="space-y-4">
      <div>
        <Label htmlFor="product_id">Product *</Label>
        <Select onValueChange={(value) => onInputChange('product_id', value)} required>
          <SelectTrigger>
            <SelectValue placeholder="Select product" />
          </SelectTrigger>
          <SelectContent>
            {products?.map((product) => (
              <SelectItem key={product.id} value={product.id}>
                {product.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div>
        <Label htmlFor="hr_shop_id">Store *</Label>
        <Select onValueChange={(value) => onInputChange('hr_shop_id', value)} required>
          <SelectTrigger>
            <SelectValue placeholder="Select store" />
          </SelectTrigger>
          <SelectContent>
            {stores?.map((store) => (
              <SelectItem key={store.id} value={store.id}>
                {store.store_name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div>
        <Label htmlFor="shift_id">Shift</Label>
        <Select onValueChange={(value) => onInputChange('shift_id', value)}>
          <SelectTrigger>
            <SelectValue placeholder="Select shift (optional)" />
          </SelectTrigger>
          <SelectContent>
            {shifts?.map((shift) => (
              <SelectItem key={shift.id} value={shift.id}>
                {shift.shift_name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div>
        <Label htmlFor="loss_type">Loss Type *</Label>
        <Select onValueChange={(value) => onInputChange('loss_type', value)} required>
          <SelectTrigger>
            <SelectValue placeholder="Select loss type" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="theft">Theft</SelectItem>
            <SelectItem value="damage">Damage</SelectItem>
            <SelectItem value="expiry">Expiry</SelectItem>
            <SelectItem value="spillage">Spillage</SelectItem>
            <SelectItem value="breakage">Breakage</SelectItem>
            <SelectItem value="other">Other</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div>
        <Label htmlFor="quantity_lost">Quantity Lost *</Label>
        <Input
          id="quantity_lost"
          type="number"
          min="1"
          required
          placeholder="Enter quantity"
          value={formData.quantity_lost || ''}
          onChange={(e) => onInputChange('quantity_lost', parseInt(e.target.value) || 0)}
        />
      </div>

      <div>
        <Label htmlFor="operator_name">Operator Name</Label>
        <Input
          id="operator_name"
          placeholder="Who reported this loss?"
          value={formData.operator_name || ''}
          onChange={(e) => onInputChange('operator_name', e.target.value)}
        />
      </div>

      <div>
        <Label htmlFor="reason">Reason</Label>
        <Textarea
          id="reason"
          placeholder="Describe the reason for the loss..."
          rows={3}
          value={formData.reason || ''}
          onChange={(e) => onInputChange('reason', e.target.value)}
        />
      </div>
    </div>
  );
};
