
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

interface Store {
  id: string;
  store_name: string;
  store_code: string;
  address: string;
  latitude?: number;
  longitude?: number;
  geo_fence_radius: number;
  created_at: string;
}

interface StoresListProps {
  stores: Store[];
}

const StoresList: React.FC<StoresListProps> = ({ stores }) => {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Stores</CardTitle>
        <CardDescription>Manage all store locations</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {stores.map((store) => (
            <div key={store.id} className="flex items-center justify-between p-4 border rounded-lg">
              <div>
                <h3 className="font-medium">{store.store_name}</h3>
                <p className="text-sm text-muted-foreground">{store.store_code}</p>
                <p className="text-sm text-muted-foreground">{store.address}</p>
                <div className="flex items-center space-x-2 mt-1">
                  {store.latitude && store.longitude && (
                    <Badge variant="outline">Geo-fenced ({store.geo_fence_radius}m)</Badge>
                  )}
                </div>
              </div>
              <div className="text-right">
                <p className="text-sm text-muted-foreground">
                  Created: {new Date(store.created_at).toLocaleDateString()}
                </p>
                {store.latitude && store.longitude && (
                  <p className="text-xs text-muted-foreground">
                    {store.latitude.toFixed(4)}, {store.longitude.toFixed(4)}
                  </p>
                )}
              </div>
            </div>
          ))}

          {stores.length === 0 && (
            <div className="text-center py-8">
              <p className="text-muted-foreground">No stores found</p>
              <p className="text-sm text-muted-foreground mt-2">
                Create your first store to get started
              </p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default StoresList;
