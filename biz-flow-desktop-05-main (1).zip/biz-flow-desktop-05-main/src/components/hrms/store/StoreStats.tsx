
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { MapPin } from 'lucide-react';

interface Store {
  id: string;
  latitude?: number;
  longitude?: number;
  geo_fence_radius: number;
}

interface StoreStatsProps {
  stores: Store[];
}

const StoreStats: React.FC<StoreStatsProps> = ({ stores }) => {
  const withLocation = stores.filter(s => s.latitude && s.longitude).length;
  const withGeofencing = stores.filter(s => s.latitude && s.longitude && s.geo_fence_radius > 0).length;

  return (
    <div className="grid gap-4 md:grid-cols-3">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Total Stores</CardTitle>
          <MapPin className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{stores.length}</div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">With Location</CardTitle>
          <MapPin className="h-4 w-4 text-green-500" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{withLocation}</div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">With Geo-fencing</CardTitle>
          <MapPin className="h-4 w-4 text-blue-500" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{withGeofencing}</div>
        </CardContent>
      </Card>
    </div>
  );
};

export default StoreStats;
