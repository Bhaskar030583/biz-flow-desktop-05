
import React from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';

interface StoreFormData {
  store_name: string;
  store_code: string;
  address: string;
  latitude: string;
  longitude: string;
  geo_fence_radius: number;
}

interface StoreFormProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  formData: StoreFormData;
  setFormData: (data: StoreFormData) => void;
  onSubmit: (e: React.FormEvent) => void;
  loading: boolean;
}

const StoreForm: React.FC<StoreFormProps> = ({
  open,
  onOpenChange,
  formData,
  setFormData,
  onSubmit,
  loading
}) => {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Add New Store</DialogTitle>
          <DialogDescription>
            Create a new store location with geo-fencing
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={onSubmit} className="space-y-4">
          <div>
            <Label htmlFor="store_name">Store Name</Label>
            <Input
              id="store_name"
              value={formData.store_name}
              onChange={(e) => setFormData({...formData, store_name: e.target.value})}
              placeholder="e.g., Main Branch"
              required
            />
          </div>

          <div>
            <Label htmlFor="store_code">Store Code</Label>
            <Input
              id="store_code"
              value={formData.store_code}
              onChange={(e) => setFormData({...formData, store_code: e.target.value})}
              placeholder="e.g., MB001"
              required
            />
          </div>

          <div>
            <Label htmlFor="address">Address</Label>
            <Textarea
              id="address"
              value={formData.address}
              onChange={(e) => setFormData({...formData, address: e.target.value})}
              placeholder="Enter complete address"
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="latitude">Latitude (Optional)</Label>
              <Input
                id="latitude"
                type="number"
                step="any"
                value={formData.latitude}
                onChange={(e) => setFormData({...formData, latitude: e.target.value})}
                placeholder="e.g., 28.6139"
              />
            </div>
            <div>
              <Label htmlFor="longitude">Longitude (Optional)</Label>
              <Input
                id="longitude"
                type="number"
                step="any"
                value={formData.longitude}
                onChange={(e) => setFormData({...formData, longitude: e.target.value})}
                placeholder="e.g., 77.2090"
              />
            </div>
          </div>

          <div>
            <Label htmlFor="geo_fence_radius">Geofence Radius (meters)</Label>
            <Input
              id="geo_fence_radius"
              type="number"
              value={formData.geo_fence_radius}
              onChange={(e) => setFormData({...formData, geo_fence_radius: parseInt(e.target.value) || 100})}
              placeholder="100"
            />
          </div>

          <div className="flex justify-end space-x-2 pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={loading}>
              {loading ? 'Creating...' : 'Create Store'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default StoreForm;
