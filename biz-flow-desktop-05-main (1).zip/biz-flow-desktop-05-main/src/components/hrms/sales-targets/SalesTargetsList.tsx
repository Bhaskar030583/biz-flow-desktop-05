
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Edit, Trash2, Target, Clock, DollarSign } from 'lucide-react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface SalesTargetsListProps {
  targets: any[];
  loading: boolean;
  onEdit: (target: any) => void;
  onRefresh: () => void;
}

const SalesTargetsList: React.FC<SalesTargetsListProps> = ({
  targets,
  loading,
  onEdit,
  onRefresh
}) => {
  const queryClient = useQueryClient();

  const deleteMutation = useMutation({
    mutationFn: async (targetId: string) => {
      const { error } = await supabase
        .from('sales_targets')
        .delete()
        .eq('id', targetId);
      
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success('Target deleted successfully');
      queryClient.invalidateQueries({ queryKey: ['sales-targets'] });
    },
    onError: (error) => {
      console.error('Error deleting target:', error);
      toast.error('Failed to delete target');
    },
  });

  const handleDelete = (targetId: string) => {
    if (confirm('Are you sure you want to delete this target?')) {
      deleteMutation.mutate(targetId);
    }
  };

  const getIncentiveDisplay = (target: any) => {
    if (!target.incentive_amount && !target.incentive_percentage) {
      return <span className="text-gray-400">No incentive</span>;
    }

    switch (target.incentive_type) {
      case 'fixed':
        return (
          <div className="flex items-center gap-1">
            <DollarSign className="h-3 w-3" />
            <span>₹{target.incentive_amount?.toFixed(2)}</span>
          </div>
        );
      case 'percentage':
        return (
          <div className="flex items-center gap-1">
            <span>{target.incentive_percentage}% of sales</span>
          </div>
        );
      case 'tiered':
        return (
          <div className="flex items-center gap-1">
            <DollarSign className="h-3 w-3" />
            <span>₹{target.incentive_amount?.toFixed(2)} + bonus</span>
          </div>
        );
      default:
        return <span className="text-gray-400">No incentive</span>;
    }
  };

  if (loading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-center">
            Loading targets...
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Target className="h-5 w-5" />
          Sales Targets
        </CardTitle>
      </CardHeader>
      <CardContent>
        {targets.length === 0 ? (
          <div className="text-center py-8">
            <Target className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-500">No sales targets found</p>
            <p className="text-sm text-gray-400">Create your first sales target to get started</p>
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Employee</TableHead>
                <TableHead>Store</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Target Amount</TableHead>
                <TableHead>Target Qty</TableHead>
                <TableHead>Incentive</TableHead>
                <TableHead>Period</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {targets.map((target) => (
                <TableRow key={target.id}>
                  <TableCell>
                    <div>
                      <div className="font-medium">
                        {target.hr_employees?.first_name} {target.hr_employees?.last_name}
                      </div>
                      <div className="text-sm text-gray-500">
                        {target.hr_employees?.employee_code}
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div>
                      <div className="font-medium">{target.hr_stores?.store_name}</div>
                      <div className="text-sm text-gray-500">{target.hr_stores?.store_code}</div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge variant={target.target_type === 'hourly' ? 'default' : 'secondary'}>
                      <Clock className="h-3 w-3 mr-1" />
                      {target.target_type}
                    </Badge>
                  </TableCell>
                  <TableCell>₹{target.target_amount?.toFixed(2)}</TableCell>
                  <TableCell>{target.target_quantity || '-'}</TableCell>
                  <TableCell>
                    {getIncentiveDisplay(target)}
                  </TableCell>
                  <TableCell>
                    <div className="text-sm">
                      <div>From: {new Date(target.effective_from).toLocaleDateString()}</div>
                      {target.effective_until && (
                        <div>Until: {new Date(target.effective_until).toLocaleDateString()}</div>
                      )}
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge variant={target.is_active ? 'default' : 'secondary'}>
                      {target.is_active ? 'Active' : 'Inactive'}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => onEdit(target)}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleDelete(target.id)}
                        disabled={deleteMutation.isPending}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </CardContent>
    </Card>
  );
};

export default SalesTargetsList;
