import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { useAuth } from '@/context/AuthContext';

interface SalesTargetFormProps {
  target?: any;
  onClose: () => void;
}

const SalesTargetForm: React.FC<SalesTargetFormProps> = ({ target, onClose }) => {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [formData, setFormData] = useState({
    employee_id: '',
    store_id: '',
    target_type: 'daily',
    target_amount: '',
    target_quantity: '',
    effective_from: new Date().toISOString().split('T')[0],
    effective_until: '',
    is_active: true,
    incentive_type: 'fixed',
    incentive_amount: '',
    incentive_percentage: '',
  });

  const { data: employees } = useQuery({
    queryKey: ['hr-employees'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('hr_employees')
        .select('id, first_name, last_name, employee_code')
        .eq('employment_status', 'active')
        .order('first_name');
      
      if (error) throw error;
      return data || [];
    },
  });

  const { data: stores } = useQuery({
    queryKey: ['hr-stores'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('hr_stores')
        .select('id, store_name, store_code')
        .order('store_name');
      
      if (error) throw error;
      return data || [];
    },
  });

  useEffect(() => {
    if (target) {
      setFormData({
        employee_id: target.employee_id || '',
        store_id: target.store_id || '',
        target_type: target.target_type || 'daily',
        target_amount: target.target_amount?.toString() || '',
        target_quantity: target.target_quantity?.toString() || '',
        effective_from: target.effective_from || new Date().toISOString().split('T')[0],
        effective_until: target.effective_until || '',
        is_active: target.is_active ?? true,
        incentive_type: target.incentive_type || 'fixed',
        incentive_amount: target.incentive_amount?.toString() || '',
        incentive_percentage: target.incentive_percentage?.toString() || '',
      });
    }
  }, [target]);

  const saveMutation = useMutation({
    mutationFn: async (data: any) => {
      const payload = {
        ...data,
        target_amount: parseFloat(data.target_amount) || 0,
        target_quantity: parseInt(data.target_quantity) || 0,
        incentive_amount: parseFloat(data.incentive_amount) || 0,
        incentive_percentage: parseFloat(data.incentive_percentage) || 0,
        user_id: user?.id,
      };

      if (target) {
        const { data: result, error } = await supabase
          .from('sales_targets')
          .update(payload)
          .eq('id', target.id)
          .select()
          .single();
        
        if (error) throw error;
        return result;
      } else {
        const { data: result, error } = await supabase
          .from('sales_targets')
          .insert(payload)
          .select()
          .single();
        
        if (error) throw error;
        return result;
      }
    },
    onSuccess: () => {
      toast.success(target ? 'Target updated successfully' : 'Target created successfully');
      queryClient.invalidateQueries({ queryKey: ['sales-targets'] });
      onClose();
    },
    onError: (error) => {
      console.error('Error saving target:', error);
      toast.error('Failed to save target');
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.employee_id || !formData.store_id || !formData.target_amount) {
      toast.error('Please fill in all required fields');
      return;
    }

    saveMutation.mutate(formData);
  };

  const handleInputChange = (field: string, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>
            {target ? 'Edit Sales Target' : 'Create Sales Target'}
          </DialogTitle>
          <DialogDescription>
            Set sales targets and incentives for employees
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Target Details Section */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium">Target Details</h3>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="employee">Employee*</Label>
                <Select 
                  value={formData.employee_id} 
                  onValueChange={(value) => handleInputChange('employee_id', value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select employee" />
                  </SelectTrigger>
                  <SelectContent>
                    {employees?.map((emp) => (
                      <SelectItem key={emp.id} value={emp.id}>
                        {emp.first_name} {emp.last_name} ({emp.employee_code})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="store">Store*</Label>
                <Select 
                  value={formData.store_id} 
                  onValueChange={(value) => handleInputChange('store_id', value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select store" />
                  </SelectTrigger>
                  <SelectContent>
                    {stores?.map((store) => (
                      <SelectItem key={store.id} value={store.id}>
                        {store.store_name} ({store.store_code})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="target_type">Target Type</Label>
              <Select 
                value={formData.target_type} 
                onValueChange={(value) => handleInputChange('target_type', value)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="hourly">Hourly Target</SelectItem>
                  <SelectItem value="daily">Daily Target</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="target_amount">Target Amount (₹)*</Label>
                <Input
                  id="target_amount"
                  type="number"
                  step="0.01"
                  value={formData.target_amount}
                  onChange={(e) => handleInputChange('target_amount', e.target.value)}
                  placeholder="0.00"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="target_quantity">Target Quantity</Label>
                <Input
                  id="target_quantity"
                  type="number"
                  value={formData.target_quantity}
                  onChange={(e) => handleInputChange('target_quantity', e.target.value)}
                  placeholder="0"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="effective_from">Effective From</Label>
                <Input
                  id="effective_from"
                  type="date"
                  value={formData.effective_from}
                  onChange={(e) => handleInputChange('effective_from', e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="effective_until">Effective Until</Label>
                <Input
                  id="effective_until"
                  type="date"
                  value={formData.effective_until}
                  onChange={(e) => handleInputChange('effective_until', e.target.value)}
                />
              </div>
            </div>

            <div className="flex items-center space-x-2">
              <Switch
                id="is_active"
                checked={formData.is_active}
                onCheckedChange={(checked) => handleInputChange('is_active', checked)}
              />
              <Label htmlFor="is_active">Active</Label>
            </div>
          </div>

          {/* Incentive Section */}
          <div className="space-y-4 border-t pt-4">
            <h3 className="text-lg font-medium">Incentive Settings</h3>
            
            <div className="space-y-2">
              <Label htmlFor="incentive_type">Incentive Type</Label>
              <Select 
                value={formData.incentive_type} 
                onValueChange={(value) => handleInputChange('incentive_type', value)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="fixed">Fixed Amount</SelectItem>
                  <SelectItem value="percentage">Percentage of Sales</SelectItem>
                  <SelectItem value="tiered">Tiered (Base + Overachievement)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {formData.incentive_type === 'fixed' || formData.incentive_type === 'tiered' ? (
              <div className="space-y-2">
                <Label htmlFor="incentive_amount">Incentive Amount (₹)</Label>
                <Input
                  id="incentive_amount"
                  type="number"
                  step="0.01"
                  value={formData.incentive_amount}
                  onChange={(e) => handleInputChange('incentive_amount', e.target.value)}
                  placeholder="0.00"
                />
              </div>
            ) : (
              <div className="space-y-2">
                <Label htmlFor="incentive_percentage">Incentive Percentage (%)</Label>
                <Input
                  id="incentive_percentage"
                  type="number"
                  step="0.1"
                  value={formData.incentive_percentage}
                  onChange={(e) => handleInputChange('incentive_percentage', e.target.value)}
                  placeholder="0.0"
                />
              </div>
            )}

            <div className="text-sm text-gray-600">
              {formData.incentive_type === 'fixed' && 
                'Employee will receive a fixed amount when target is achieved (100% or more)'}
              {formData.incentive_type === 'percentage' && 
                'Employee will receive a percentage of their actual sales amount when target is achieved'}
              {formData.incentive_type === 'tiered' && 
                'Employee receives base amount at 100% achievement + additional amount for overachievement'}
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-4">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit" disabled={saveMutation.isPending}>
              {saveMutation.isPending ? 'Saving...' : target ? 'Update Target' : 'Create Target'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default SalesTargetForm;
