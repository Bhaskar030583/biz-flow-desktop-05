
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { DollarSign, Check, Clock, TrendingUp } from 'lucide-react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

const IncentiveManagement: React.FC = () => {
  const queryClient = useQueryClient();

  const { data: incentivePayouts, isLoading } = useQuery({
    queryKey: ['incentive-payouts'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('incentive_payouts')
        .select(`
          *,
          hr_employees!incentive_payouts_employee_id_fkey (
            first_name,
            last_name,
            employee_code
          ),
          sales_targets (
            target_amount,
            incentive_type
          ),
          sales_performance (
            actual_sales_amount,
            achievement_percentage,
            performance_date
          )
        `)
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      return data || [];
    },
  });

  const { data: eligiblePerformances } = useQuery({
    queryKey: ['eligible-performances'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('sales_performance')
        .select(`
          *,
          hr_employees!sales_performance_employee_id_fkey (
            first_name,
            last_name,
            employee_code
          )
        `)
        .gte('achievement_percentage', 100)
        .eq('performance_date', new Date().toISOString().split('T')[0])
        .order('achievement_percentage', { ascending: false });
      
      if (error) throw error;
      return data || [];
    },
  });

  const processIncentiveMutation = useMutation({
    mutationFn: async (performanceId: string) => {
      const { data, error } = await supabase.rpc('calculate_incentive_payout', {
        p_performance_id: performanceId,
        p_user_id: (await supabase.auth.getUser()).data.user?.id
      });
      
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      toast.success('Incentive calculated and added to pending payouts');
      queryClient.invalidateQueries({ queryKey: ['incentive-payouts'] });
      queryClient.invalidateQueries({ queryKey: ['eligible-performances'] });
    },
    onError: (error) => {
      console.error('Error processing incentive:', error);
      toast.error('Failed to process incentive');
    },
  });

  const approvePayoutMutation = useMutation({
    mutationFn: async (payoutId: string) => {
      const { error } = await supabase
        .from('incentive_payouts')
        .update({
          status: 'approved',
          approved_at: new Date().toISOString(),
        })
        .eq('id', payoutId);
      
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success('Incentive payout approved');
      queryClient.invalidateQueries({ queryKey: ['incentive-payouts'] });
    },
    onError: (error) => {
      console.error('Error approving payout:', error);
      toast.error('Failed to approve payout');
    },
  });

  const markPaidMutation = useMutation({
    mutationFn: async (payoutId: string) => {
      const { error } = await supabase
        .from('incentive_payouts')
        .update({
          status: 'paid',
          paid_at: new Date().toISOString(),
        })
        .eq('id', payoutId);
      
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success('Incentive marked as paid');
      queryClient.invalidateQueries({ queryKey: ['incentive-payouts'] });
    },
    onError: (error) => {
      console.error('Error marking as paid:', error);
      toast.error('Failed to mark as paid');
    },
  });

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return <Badge variant="outline"><Clock className="h-3 w-3 mr-1" />Pending</Badge>;
      case 'approved':
        return <Badge variant="secondary"><Check className="h-3 w-3 mr-1" />Approved</Badge>;
      case 'paid':
        return <Badge variant="default"><DollarSign className="h-3 w-3 mr-1" />Paid</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-center">
              Loading incentive data...
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Eligible for Incentives */}
      {eligiblePerformances && eligiblePerformances.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5" />
              Eligible for Incentives (Today)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Employee</TableHead>
                  <TableHead>Achievement</TableHead>
                  <TableHead>Sales Amount</TableHead>
                  <TableHead>Action</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {eligiblePerformances.map((performance) => (
                  <TableRow key={performance.id}>
                    <TableCell>
                      <div>
                        <div className="font-medium">
                          {performance.hr_employees?.first_name} {performance.hr_employees?.last_name}
                        </div>
                        <div className="text-sm text-gray-500">
                          {performance.hr_employees?.employee_code}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="default" className="text-green-600">
                        {performance.achievement_percentage?.toFixed(1)}%
                      </Badge>
                    </TableCell>
                    <TableCell>₹{performance.actual_sales_amount?.toFixed(2)}</TableCell>
                    <TableCell>
                      <Button
                        size="sm"
                        onClick={() => processIncentiveMutation.mutate(performance.id)}
                        disabled={processIncentiveMutation.isPending}
                      >
                        Calculate Incentive
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}

      {/* Incentive Payouts */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <DollarSign className="h-5 w-5" />
            Incentive Payouts
          </CardTitle>
        </CardHeader>
        <CardContent>
          {incentivePayouts && incentivePayouts.length === 0 ? (
            <div className="text-center py-8">
              <DollarSign className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-500">No incentive payouts found</p>
              <p className="text-sm text-gray-400">Incentives will appear here when targets are achieved</p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Employee</TableHead>
                  <TableHead>Achievement</TableHead>
                  <TableHead>Payout Amount</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {incentivePayouts?.map((payout) => (
                  <TableRow key={payout.id}>
                    <TableCell>
                      <div>
                        <div className="font-medium">
                          {payout.hr_employees?.first_name} {payout.hr_employees?.last_name}
                        </div>
                        <div className="text-sm text-gray-500">
                          {payout.hr_employees?.employee_code}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="default" className="text-green-600">
                        {payout.achievement_percentage?.toFixed(1)}%
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="font-medium">₹{payout.payout_amount?.toFixed(2)}</div>
                    </TableCell>
                    <TableCell>
                      {new Date(payout.sales_performance?.performance_date || payout.payout_date).toLocaleDateString()}
                    </TableCell>
                    <TableCell>
                      {getStatusBadge(payout.status)}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        {payout.status === 'pending' && (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => approvePayoutMutation.mutate(payout.id)}
                            disabled={approvePayoutMutation.isPending}
                          >
                            Approve
                          </Button>
                        )}
                        {payout.status === 'approved' && (
                          <Button
                            size="sm"
                            onClick={() => markPaidMutation.mutate(payout.id)}
                            disabled={markPaidMutation.isPending}
                          >
                            Mark Paid
                          </Button>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default IncentiveManagement;
