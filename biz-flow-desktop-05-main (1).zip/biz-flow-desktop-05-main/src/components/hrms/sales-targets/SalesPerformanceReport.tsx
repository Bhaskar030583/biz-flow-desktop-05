
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { TrendingUp, TrendingDown, Target, Clock } from 'lucide-react';

interface SalesPerformanceReportProps {
  performanceData: any[];
  loading: boolean;
}

const SalesPerformanceReport: React.FC<SalesPerformanceReportProps> = ({
  performanceData,
  loading
}) => {
  if (loading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-center">
            Loading performance data...
          </div>
        </CardContent>
      </Card>
    );
  }

  const dailyPerformance = performanceData.filter(p => !p.performance_hour);
  const hourlyPerformance = performanceData.filter(p => p.performance_hour !== null);

  const getAchievementColor = (percentage: number) => {
    if (percentage >= 100) return 'text-green-600';
    if (percentage >= 80) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getAchievementIcon = (percentage: number) => {
    return percentage >= 100 ? <TrendingUp className="h-4 w-4" /> : <TrendingDown className="h-4 w-4" />;
  };

  return (
    <div className="space-y-6">
      {/* Daily Performance */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="h-5 w-5" />
            Daily Performance (Today)
          </CardTitle>
        </CardHeader>
        <CardContent>
          {dailyPerformance.length === 0 ? (
            <div className="text-center py-8">
              <Target className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-500">No daily performance data found</p>
              <p className="text-sm text-gray-400">Performance will be tracked as sales are made</p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Employee</TableHead>
                  <TableHead>Store</TableHead>
                  <TableHead>Target</TableHead>
                  <TableHead>Actual</TableHead>
                  <TableHead>Achievement</TableHead>
                  <TableHead>Progress</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {dailyPerformance.map((performance) => (
                  <TableRow key={performance.id}>
                    <TableCell>
                      <div>
                        <div className="font-medium">
                          {performance.hr_employees?.first_name} {performance.hr_employees?.last_name}
                        </div>
                        <div className="text-sm text-gray-500">
                          {performance.hr_employees?.employee_code}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>{performance.hr_stores?.store_name}</TableCell>
                    <TableCell>
                      <div>
                        <div>₹{performance.target_amount?.toFixed(2)}</div>
                        {performance.target_quantity > 0 && (
                          <div className="text-sm text-gray-500">
                            {performance.target_quantity} items
                          </div>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div>
                        <div>₹{performance.actual_sales_amount?.toFixed(2)}</div>
                        {performance.actual_sales_quantity > 0 && (
                          <div className="text-sm text-gray-500">
                            {performance.actual_sales_quantity} items
                          </div>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className={`flex items-center gap-2 ${getAchievementColor(performance.achievement_percentage || 0)}`}>
                        {getAchievementIcon(performance.achievement_percentage || 0)}
                        <span className="font-medium">
                          {(performance.achievement_percentage || 0).toFixed(1)}%
                        </span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="w-full">
                        <Progress 
                          value={Math.min(performance.achievement_percentage || 0, 100)} 
                          className="w-full"
                        />
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* Hourly Performance */}
      {hourlyPerformance.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="h-5 w-5" />
              Hourly Performance (Today)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Employee</TableHead>
                  <TableHead>Store</TableHead>
                  <TableHead>Hour</TableHead>
                  <TableHead>Target</TableHead>
                  <TableHead>Actual</TableHead>
                  <TableHead>Achievement</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {hourlyPerformance.map((performance) => (
                  <TableRow key={performance.id}>
                    <TableCell>
                      <div>
                        <div className="font-medium">
                          {performance.hr_employees?.first_name} {performance.hr_employees?.last_name}
                        </div>
                        <div className="text-sm text-gray-500">
                          {performance.hr_employees?.employee_code}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>{performance.hr_stores?.store_name}</TableCell>
                    <TableCell>
                      <Badge variant="outline">
                        {performance.performance_hour}:00 - {performance.performance_hour + 1}:00
                      </Badge>
                    </TableCell>
                    <TableCell>₹{performance.target_amount?.toFixed(2)}</TableCell>
                    <TableCell>₹{performance.actual_sales_amount?.toFixed(2)}</TableCell>
                    <TableCell>
                      <div className={`flex items-center gap-2 ${getAchievementColor(performance.achievement_percentage || 0)}`}>
                        {getAchievementIcon(performance.achievement_percentage || 0)}
                        <span className="font-medium">
                          {(performance.achievement_percentage || 0).toFixed(1)}%
                        </span>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default SalesPerformanceReport;
