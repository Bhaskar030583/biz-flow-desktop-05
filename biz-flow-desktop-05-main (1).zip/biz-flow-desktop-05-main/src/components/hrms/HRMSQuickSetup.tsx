
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { CheckCircle2, Circle, ArrowRight, ArrowLeft } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const HRMSQuickSetup = () => {
  const navigate = useNavigate();
  const [completedSteps, setCompletedSteps] = useState<number[]>([]);

  const setupSteps = [
    {
      id: 1,
      title: 'Set up Stores',
      description: 'Create store locations with geo-fencing settings',
      path: '/hrms/stores',
      required: true,
    },
    {
      id: 2,
      title: 'Create Shifts',
      description: 'Define work shifts and time schedules',
      path: '/hrms/shifts',
      required: true,
    },
    {
      id: 3,
      title: 'Add Employees',
      description: 'Register employees with their details and assignments',
      path: '/hrms/employees',
      required: true,
    },
    {
      id: 4,
      title: 'Configure Attendance',
      description: 'Set up attendance tracking and policies',
      path: '/hrms/attendance',
      required: false,
    },
    {
      id: 5,
      title: 'Setup Leave Policies',
      description: 'Configure leave types and approval workflows',
      path: '/hrms/leaves',
      required: false,
    },
    {
      id: 6,
      title: 'Payroll Configuration',
      description: 'Set up salary structures and payment methods',
      path: '/hrms/payroll',
      required: false,
    },
  ];

  const handleStepComplete = (stepId: number) => {
    if (!completedSteps.includes(stepId)) {
      setCompletedSteps([...completedSteps, stepId]);
    }
  };

  const handleNavigateToStep = (path: string, stepId: number) => {
    navigate(path);
    // Mark as visited/in progress
    handleStepComplete(stepId);
  };

  const completionPercentage = (completedSteps.length / setupSteps.length) * 100;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div className="flex items-center gap-4">
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => navigate('/hrms')}
            className="flex items-center gap-2"
          >
            <ArrowLeft className="h-4 w-4" />
            Back to HRMS
          </Button>
          <div>
            <h1 className="text-3xl font-bold tracking-tight">HRMS Quick Setup</h1>
            <p className="text-muted-foreground">
              Get your HR system up and running in a few simple steps
            </p>
          </div>
        </div>
        <div className="text-right">
          <div className="text-2xl font-bold text-primary">
            {Math.round(completionPercentage)}%
          </div>
          <p className="text-sm text-muted-foreground">Complete</p>
        </div>
      </div>

      {/* Progress Overview */}
      <Card>
        <CardHeader>
          <CardTitle>Setup Progress</CardTitle>
          <CardDescription>
            Complete these steps to set up your HRMS system
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="w-full bg-muted rounded-full h-2 mb-4">
            <div 
              className="bg-primary h-2 rounded-full transition-all duration-300"
              style={{ width: `${completionPercentage}%` }}
            />
          </div>
          <div className="text-sm text-muted-foreground">
            {completedSteps.length} of {setupSteps.length} steps completed
          </div>
        </CardContent>
      </Card>

      {/* Setup Steps */}
      <div className="grid gap-4">
        {setupSteps.map((step) => {
          const isCompleted = completedSteps.includes(step.id);
          
          return (
            <Card key={step.id} className={`cursor-pointer hover:shadow-lg transition-shadow ${isCompleted ? 'border-green-500 bg-green-50' : ''}`}>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className="flex-shrink-0">
                      {isCompleted ? (
                        <CheckCircle2 className="h-8 w-8 text-green-500" />
                      ) : (
                        <Circle className="h-8 w-8 text-muted-foreground" />
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <h3 className="text-lg font-medium">{step.title}</h3>
                        {step.required && (
                          <Badge variant="destructive" className="text-xs">
                            Required
                          </Badge>
                        )}
                        {isCompleted && (
                          <Badge variant="secondary" className="text-xs">
                            Completed
                          </Badge>
                        )}
                      </div>
                      <p className="text-sm text-muted-foreground mt-1">
                        {step.description}
                      </p>
                    </div>
                  </div>
                  <Button
                    onClick={() => handleNavigateToStep(step.path, step.id)}
                    variant={isCompleted ? "outline" : "default"}
                    className="flex items-center gap-2"
                  >
                    {isCompleted ? "Review" : "Start"}
                    <ArrowRight className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Quick Actions</CardTitle>
          <CardDescription>
            Jump to specific areas after completing the basic setup
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            <Button
              variant="outline"
              onClick={() => navigate('/hrms/employee-login')}
              className="h-auto p-4 flex flex-col items-center gap-2"
            >
              <div className="text-sm font-medium">Employee Portal</div>
              <div className="text-xs text-muted-foreground">Access employee features</div>
            </Button>
            <Button
              variant="outline"
              onClick={() => navigate('/hrms/mobile-app')}
              className="h-auto p-4 flex flex-col items-center gap-2"
            >
              <div className="text-sm font-medium">Mobile App</div>
              <div className="text-xs text-muted-foreground">Attendance tracking</div>
            </Button>
            <Button
              variant="outline"
              onClick={() => navigate('/hrms')}
              className="h-auto p-4 flex flex-col items-center gap-2"
            >
              <div className="text-sm font-medium">Dashboard</div>
              <div className="text-xs text-muted-foreground">View overview</div>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default HRMSQuickSetup;
