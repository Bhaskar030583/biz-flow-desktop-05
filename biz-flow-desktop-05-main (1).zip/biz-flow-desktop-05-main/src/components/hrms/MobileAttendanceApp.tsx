
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { 
  MapPin, 
  Camera, 
  Clock, 
  CheckCircle2, 
  LogOut, 
  User, 
  Calendar,
  Wifi,
  WifiOff
} from 'lucide-react';
import { toast } from 'sonner';

const MobileAttendanceApp = () => {
  const [isCheckedIn, setIsCheckedIn] = useState(false);
  const [currentLocation, setCurrentLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [checkInTime, setCheckInTime] = useState<string>('');
  const [workingHours, setWorkingHours] = useState('0h 0m');

  useEffect(() => {
    // Get current location
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setCurrentLocation({
            lat: position.coords.latitude,
            lng: position.coords.longitude
          });
        },
        (error) => {
          console.error('Error getting location:', error);
          toast.error('Please enable location access for attendance');
        }
      );
    }

    // Monitor online status
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  useEffect(() => {
    // Update working hours every minute if checked in
    if (isCheckedIn && checkInTime) {
      const interval = setInterval(() => {
        const start = new Date(checkInTime);
        const now = new Date();
        const diff = now.getTime() - start.getTime();
        const hours = Math.floor(diff / (1000 * 60 * 60));
        const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
        setWorkingHours(`${hours}h ${minutes}m`);
      }, 60000);

      return () => clearInterval(interval);
    }
  }, [isCheckedIn, checkInTime]);

  const handleCheckIn = async () => {
    if (!currentLocation) {
      toast.error('Location required for check-in');
      return;
    }

    // Simulate camera capture for selfie
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode: 'user' } 
      });
      
      // In a real app, you'd capture the photo here
      stream.getTracks().forEach(track => track.stop());
      
      setIsCheckedIn(true);
      setCheckInTime(new Date().toISOString());
      toast.success('Successfully checked in!');
    } catch (error) {
      toast.error('Camera access required for check-in');
    }
  };

  const handleCheckOut = () => {
    setIsCheckedIn(false);
    setCheckInTime('');
    setWorkingHours('0h 0m');
    toast.success('Successfully checked out!');
  };

  const requestPermission = async () => {
    try {
      await navigator.mediaDevices.getUserMedia({ video: true });
      await new Promise((resolve, reject) => {
        navigator.geolocation.getCurrentPosition(resolve, reject);
      });
      toast.success('Permissions granted');
    } catch (error) {
      toast.error('Please grant camera and location permissions');
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-md mx-auto space-y-4">
        {/* Header */}
        <Card>
          <CardHeader className="text-center">
            <CardTitle className="flex items-center justify-center gap-2">
              <User className="h-5 w-5" />
              Employee Check-in
            </CardTitle>
            <div className="flex items-center justify-center gap-2 text-sm">
              {isOnline ? (
                <>
                  <Wifi className="h-4 w-4 text-green-500" />
                  <span className="text-green-500">Online</span>
                </>
              ) : (
                <>
                  <WifiOff className="h-4 w-4 text-red-500" />
                  <span className="text-red-500">Offline</span>
                </>
              )}
            </div>
          </CardHeader>
        </Card>

        {/* Current Status */}
        <Card>
          <CardContent className="pt-6">
            <div className="text-center space-y-4">
              <div className="text-3xl font-bold">
                {new Date().toLocaleTimeString('en-US', {
                  hour: '2-digit',
                  minute: '2-digit'
                })}
              </div>
              <div className="text-sm text-muted-foreground">
                {new Date().toLocaleDateString('en-US', {
                  weekday: 'long',
                  year: 'numeric',
                  month: 'long',
                  day: 'numeric'
                })}
              </div>
              
              {isCheckedIn ? (
                <div className="space-y-2">
                  <Badge className="bg-green-500 text-white">
                    <CheckCircle2 className="h-3 w-3 mr-1" />
                    Checked In
                  </Badge>
                  <div className="text-lg font-semibold">
                    Working for: {workingHours}
                  </div>
                  <div className="text-sm text-muted-foreground">
                    Since: {checkInTime ? new Date(checkInTime).toLocaleTimeString() : ''}
                  </div>
                </div>
              ) : (
                <Badge variant="outline">Not Checked In</Badge>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Location Status */}
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <MapPin className="h-5 w-5 text-blue-500" />
              <div className="flex-1">
                <div className="font-medium">Location Status</div>
                {currentLocation ? (
                  <div className="text-sm text-green-600">
                    ✓ Within store premises
                  </div>
                ) : (
                  <div className="text-sm text-red-600">
                    ✗ Location not available
                  </div>
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Action Buttons */}
        <div className="space-y-3">
          {!isCheckedIn ? (
            <Button 
              onClick={handleCheckIn}
              className="w-full h-16 text-lg bg-green-600 hover:bg-green-700"
              disabled={!currentLocation}
            >
              <Camera className="h-6 w-6 mr-2" />
              Check In
            </Button>
          ) : (
            <Button 
              onClick={handleCheckOut}
              className="w-full h-16 text-lg bg-red-600 hover:bg-red-700"
            >
              <LogOut className="h-6 w-6 mr-2" />
              Check Out
            </Button>
          )}

          <div className="grid grid-cols-2 gap-3">
            <Button variant="outline" className="h-12">
              <Clock className="h-4 w-4 mr-2" />
              Break
            </Button>
            <Button variant="outline" className="h-12">
              <Calendar className="h-4 w-4 mr-2" />
              Leave
            </Button>
          </div>
        </div>

        {/* Quick Actions */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Quick Actions</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <Button variant="ghost" className="w-full justify-start">
              <User className="h-4 w-4 mr-2" />
              View My Profile
            </Button>
            <Button variant="ghost" className="w-full justify-start">
              <Calendar className="h-4 w-4 mr-2" />
              Leave History
            </Button>
            <Button variant="ghost" className="w-full justify-start">
              <Clock className="h-4 w-4 mr-2" />
              Attendance Report
            </Button>
            <Button variant="ghost" className="w-full justify-start" onClick={requestPermission}>
              <Camera className="h-4 w-4 mr-2" />
              Grant Permissions
            </Button>
          </CardContent>
        </Card>

        {/* Offline Sync Notice */}
        {!isOnline && (
          <Card className="border-orange-200 bg-orange-50">
            <CardContent className="pt-4">
              <div className="flex items-center gap-2 text-orange-600">
                <WifiOff className="h-4 w-4" />
                <span className="text-sm">
                  You're offline. Data will sync when connection is restored.
                </span>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
};

export default MobileAttendanceApp;
