import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Plus, ArrowLeft } from 'lucide-react';
import { toast } from 'sonner';
import { useNavigate } from 'react-router-dom';
import PayrollStats from './payroll/PayrollStats';
import PayrollRecordsList from './payroll/PayrollRecordsList';
import AutoCalculatedPayrollForm from './payroll/AutoCalculatedPayrollForm';
import { PayslipRaw, Employee } from '@/types/hrms';

interface PayrollFormData {
  employee_id: string;
  month: number;
  year: number;
  total_working_days: number;
  days_worked: number;
  total_hours: number;
  regular_hours: number;
  overtime_hours: number;
  other_deductions: number;
  bonuses: number;
}

const PayrollManagement = () => {
  const navigate = useNavigate();
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [formData, setFormData] = useState<PayrollFormData>({
    employee_id: '',
    month: new Date().getMonth() + 1,
    year: new Date().getFullYear(),
    total_working_days: 22,
    days_worked: 0,
    total_hours: 0,
    regular_hours: 0,
    overtime_hours: 0,
    other_deductions: 0,
    bonuses: 0,
  });

  const queryClient = useQueryClient();

  // Fetch payroll records
  const { data: payrollRecords = [], isLoading: loadingPayroll } = useQuery({
    queryKey: ['payroll-records'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('hr_payslips')
        .select(`
          *,
          hr_employees!employee_id (
            first_name,
            last_name,
            employee_code,
            hourly_rate
          )
        `)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching payroll records:', error);
        throw error;
      }
      
      const transformedData = (data || []).map(record => ({
        ...record,
        hr_employees: record.hr_employees ? {
          first_name: record.hr_employees.first_name,
          last_name: record.hr_employees.last_name,
          employee_code: record.hr_employees.employee_code,
          hourly_rate: record.hr_employees.hourly_rate
        } : null
      }));
      
      return transformedData as PayslipRaw[];
    },
  });

  // Fetch employees for dropdown
  const { data: employees = [] } = useQuery({
    queryKey: ['employees'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('hr_employees')
        .select('id, first_name, last_name, employee_code, hourly_rate')
        .eq('employment_status', 'active');

      if (error) {
        console.error('Error fetching employees:', error);
        throw error;
      }
      return data as Employee[] || [];
    },
  });

  // Calculate pay based on form data
  const calculatePay = () => {
    const selectedEmployee = employees.find(emp => emp.id === formData.employee_id);
    if (!selectedEmployee) {
      return { grossSalary: 0, netSalary: 0 };
    }

    const regularPay = formData.regular_hours * selectedEmployee.hourly_rate;
    const overtimePay = formData.overtime_hours * selectedEmployee.hourly_rate * 1.5;
    const grossSalary = regularPay + overtimePay + formData.bonuses;
    
    const netSalary = grossSalary - formData.other_deductions;

    return { grossSalary, netSalary };
  };

  // Create payroll record
  const createPayrollMutation = useMutation({
    mutationFn: async (data: PayrollFormData) => {
      const { grossSalary, netSalary } = calculatePay();

      // Get pending penalties and advances for this employee
      const [pendingPenalties, pendingAdvances] = await Promise.all([
        supabase
          .from('hr_inventory_penalties')
          .select('*')
          .eq('employee_id', data.employee_id)
          .eq('status', 'approved')
          .is('deducted_in_payslip', null),
        supabase
          .from('hr_advances')
          .select('*')
          .eq('employee_id', data.employee_id)
          .eq('status', 'approved')
          .is('deducted_in_payslip', null)
      ]);

      if (pendingPenalties.error) throw pendingPenalties.error;
      if (pendingAdvances.error) throw pendingAdvances.error;

      const totalPenalties = pendingPenalties.data?.reduce((sum, p) => sum + (p.total_penalty || 0), 0) || 0;
      const totalAdvances = pendingAdvances.data?.reduce((sum, a) => sum + (a.amount || 0), 0) || 0;
      const finalNetSalary = netSalary - totalPenalties - totalAdvances;

      // Create payslip
      const { data: payslip, error } = await supabase
        .from('hr_payslips')
        .insert({
          employee_id: data.employee_id,
          month: data.month,
          year: data.year,
          total_working_days: data.total_working_days,
          days_worked: data.days_worked,
          total_hours: data.total_hours,
          regular_hours: data.regular_hours,
          overtime_hours: data.overtime_hours,
          gross_salary: grossSalary,
          advance_deductions: totalAdvances,
          penalty_deductions: totalPenalties,
          other_deductions: data.other_deductions,
          bonuses: data.bonuses,
          net_salary: finalNetSalary,
          is_final: false,
        })
        .select()
        .single();

      if (error) throw error;

      // Update penalties and advances to mark them as deducted
      const updatePromises = [];
      
      if (pendingPenalties.data && pendingPenalties.data.length > 0) {
        updatePromises.push(
          supabase
            .from('hr_inventory_penalties')
            .update({ deducted_in_payslip: payslip.id })
            .in('id', pendingPenalties.data.map(p => p.id))
        );
      }

      if (pendingAdvances.data && pendingAdvances.data.length > 0) {
        updatePromises.push(
          supabase
            .from('hr_advances')
            .update({ deducted_in_payslip: payslip.id })
            .in('id', pendingAdvances.data.map(a => a.id))
        );
      }

      if (updatePromises.length > 0) {
        const results = await Promise.all(updatePromises);
        results.forEach(result => {
          if (result.error) throw result.error;
        });
      }

      return payslip;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['payroll-records'] });
      queryClient.invalidateQueries({ queryKey: ['inventory-penalties'] });
      queryClient.invalidateQueries({ queryKey: ['employee-advances'] });
      toast.success('Payroll record created successfully');
      setIsFormOpen(false);
      setFormData({
        employee_id: '',
        month: new Date().getMonth() + 1,
        year: new Date().getFullYear(),
        total_working_days: 22,
        days_worked: 0,
        total_hours: 0,
        regular_hours: 0,
        overtime_hours: 0,
        other_deductions: 0,
        bonuses: 0,
      });
    },
    onError: (error) => {
      console.error('Error creating payroll record:', error);
      toast.error('Failed to create payroll record');
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.employee_id) {
      toast.error('Please select an employee');
      return;
    }
    createPayrollMutation.mutate(formData);
  };

  if (loadingPayroll) {
    return <div className="flex items-center justify-center p-8">Loading payroll data...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div className="flex items-center gap-4">
          <Button 
            variant="outline" 
            onClick={() => navigate('/hrms')}
            className="flex items-center gap-2"
          >
            <ArrowLeft className="h-4 w-4" />
            Back to HRMS
          </Button>
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Payroll Management</h1>
            <p className="text-muted-foreground">
              Manage employee salaries with automatic calculations from attendance
            </p>
          </div>
        </div>
        <Button onClick={() => setIsFormOpen(true)}>
          <Plus className="mr-2 h-4 w-4" />
          Create Payroll
        </Button>
      </div>

      <PayrollStats payrollRecords={payrollRecords} />

      <PayrollRecordsList payrollRecords={payrollRecords} />

      <AutoCalculatedPayrollForm
        open={isFormOpen}
        onOpenChange={setIsFormOpen}
        formData={formData}
        setFormData={setFormData}
        onSubmit={handleSubmit}
        loading={createPayrollMutation.isPending}
        employees={employees}
        calculatePay={calculatePay}
      />
    </div>
  );
};

export default PayrollManagement;
