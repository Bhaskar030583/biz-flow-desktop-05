import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useNavigate } from 'react-router-dom';
import SalesTargetForm from './sales-targets/SalesTargetForm';
import SalesTargetsList from './sales-targets/SalesTargetsList';
import SalesPerformanceReport from './sales-targets/SalesPerformanceReport';
import IncentiveManagement from './sales-targets/IncentiveManagement';
import { Target, TrendingUp, Users, Calendar, DollarSign, ArrowLeft } from 'lucide-react';

const SalesTargetManagement = () => {
  const navigate = useNavigate();
  const [showForm, setShowForm] = useState(false);
  const [editingTarget, setEditingTarget] = useState(null);

  const { data: salesTargets, isLoading: targetsLoading, refetch: refetchTargets } = useQuery({
    queryKey: ['sales-targets'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('sales_targets')
        .select(`
          *,
          hr_employees (
            first_name,
            last_name,
            employee_code
          ),
          hr_stores (
            store_name,
            store_code
          )
        `)
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      return data || [];
    },
  });

  const { data: performanceData, isLoading: performanceLoading } = useQuery({
    queryKey: ['sales-performance-summary'],
    queryFn: async () => {
      const today = new Date().toISOString().split('T')[0];
      const { data, error } = await supabase
        .from('sales_performance')
        .select(`
          *,
          hr_employees (
            first_name,
            last_name,
            employee_code
          ),
          hr_stores (
            store_name
          )
        `)
        .eq('performance_date', today)
        .order('achievement_percentage', { ascending: false });
      
      if (error) throw error;
      return data || [];
    },
  });

  const { data: incentiveSummary } = useQuery({
    queryKey: ['incentive-summary'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('incentive_payouts')
        .select('payout_amount, status')
        .eq('payout_date', new Date().toISOString().split('T')[0]);
      
      if (error) throw error;
      
      const totalPending = data?.filter(p => p.status === 'pending').reduce((sum, p) => sum + (p.payout_amount || 0), 0) || 0;
      const totalPaid = data?.filter(p => p.status === 'paid').reduce((sum, p) => sum + (p.payout_amount || 0), 0) || 0;
      
      return { totalPending, totalPaid, totalPayouts: data?.length || 0 };
    },
  });

  const handleEdit = (target) => {
    setEditingTarget(target);
    setShowForm(true);
  };

  const handleFormClose = () => {
    setShowForm(false);
    setEditingTarget(null);
    refetchTargets();
  };

  const todayPerformance = performanceData?.filter(p => !p.performance_hour) || [];
  const avgAchievement = todayPerformance.length > 0 
    ? todayPerformance.reduce((sum, p) => sum + (p.achievement_percentage || 0), 0) / todayPerformance.length 
    : 0;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div className="flex items-center gap-4">
          <Button 
            variant="outline" 
            onClick={() => navigate('/hrms')}
            className="flex items-center gap-2"
          >
            <ArrowLeft className="h-4 w-4" />
            Back to HRMS
          </Button>
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Sales Target Management</h1>
            <p className="text-muted-foreground">
              Set and track sales targets with automated incentive calculation
            </p>
          </div>
        </div>
        <Button onClick={() => setShowForm(true)} className="flex items-center gap-2">
          <Target className="h-4 w-4" />
          Set New Target
        </Button>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Targets</CardTitle>
            <Target className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {salesTargets?.filter(t => t.is_active).length || 0}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Avg Achievement</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {avgAchievement.toFixed(1)}%
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Staff</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {new Set(salesTargets?.map(t => t.employee_id)).size || 0}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending Incentives</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              ₹{incentiveSummary?.totalPending?.toFixed(0) || 0}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Today's Date</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-lg font-bold">
              {new Date().toLocaleDateString()}
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="targets" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="targets">Sales Targets</TabsTrigger>
          <TabsTrigger value="performance">Performance</TabsTrigger>
          <TabsTrigger value="incentives">Incentives</TabsTrigger>
          <TabsTrigger value="reports">Reports</TabsTrigger>
        </TabsList>

        <TabsContent value="targets">
          <SalesTargetsList
            targets={salesTargets || []}
            loading={targetsLoading}
            onEdit={handleEdit}
            onRefresh={refetchTargets}
          />
        </TabsContent>

        <TabsContent value="performance">
          <SalesPerformanceReport
            performanceData={performanceData || []}
            loading={performanceLoading}
          />
        </TabsContent>

        <TabsContent value="incentives">
          <IncentiveManagement />
        </TabsContent>

        <TabsContent value="reports">
          <Card>
            <CardHeader>
              <CardTitle>Performance Reports</CardTitle>
              <CardDescription>Detailed analytics and reports coming soon</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                Advanced reporting features will include weekly/monthly performance trends,
                target vs achievement analysis, team comparisons, and incentive analytics.
              </p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {showForm && (
        <SalesTargetForm
          target={editingTarget}
          onClose={handleFormClose}
        />
      )}
    </div>
  );
};

export default SalesTargetManagement;
