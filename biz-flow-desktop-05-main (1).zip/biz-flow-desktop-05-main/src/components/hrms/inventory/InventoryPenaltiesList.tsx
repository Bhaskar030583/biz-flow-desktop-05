
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Check, X, AlertTriangle } from 'lucide-react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface InventoryPenaltiesListProps {
  penalties: any[];
  loading: boolean;
}

const InventoryPenaltiesList: React.FC<InventoryPenaltiesListProps> = ({
  penalties,
  loading
}) => {
  const queryClient = useQueryClient();

  const approvePenaltyMutation = useMutation({
    mutationFn: async (penaltyId: string) => {
      const { error } = await supabase
        .from('hr_inventory_penalties')
        .update({
          status: 'approved',
          approved_on: new Date().toISOString(),
        })
        .eq('id', penaltyId);
      
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success('Penalty approved successfully');
      queryClient.invalidateQueries({ queryKey: ['inventory-penalties'] });
    },
    onError: (error) => {
      console.error('Error approving penalty:', error);
      toast.error('Failed to approve penalty');
    },
  });

  const rejectPenaltyMutation = useMutation({
    mutationFn: async (penaltyId: string) => {
      const { error } = await supabase
        .from('hr_inventory_penalties')
        .update({
          status: 'rejected',
        })
        .eq('id', penaltyId);
      
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success('Penalty rejected');
      queryClient.invalidateQueries({ queryKey: ['inventory-penalties'] });
    },
    onError: (error) => {
      console.error('Error rejecting penalty:', error);
      toast.error('Failed to reject penalty');
    },
  });

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return <Badge variant="outline"><AlertTriangle className="h-3 w-3 mr-1" />Pending</Badge>;
      case 'approved':
        return <Badge variant="default"><Check className="h-3 w-3 mr-1" />Approved</Badge>;
      case 'rejected':
        return <Badge variant="destructive"><X className="h-3 w-3 mr-1" />Rejected</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  if (loading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-center">
            Loading penalties...
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <AlertTriangle className="h-5 w-5" />
          Inventory Penalties
        </CardTitle>
      </CardHeader>
      <CardContent>
        {penalties.length === 0 ? (
          <div className="text-center py-8">
            <AlertTriangle className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-500">No inventory penalties found</p>
            <p className="text-sm text-gray-400">Penalties will appear here when products are lost</p>
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Employee</TableHead>
                <TableHead>Store</TableHead>
                <TableHead>Product</TableHead>
                <TableHead>Quantity</TableHead>
                <TableHead>Unit Value</TableHead>
                <TableHead>Total Penalty</TableHead>
                <TableHead>Date</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {penalties.map((penalty) => (
                <TableRow key={penalty.id}>
                  <TableCell>
                    <div>
                      <div className="font-medium">
                        {penalty.hr_employees?.first_name} {penalty.hr_employees?.last_name}
                      </div>
                      <div className="text-sm text-gray-500">
                        {penalty.hr_employees?.employee_code}
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div>
                      <div className="font-medium">{penalty.hr_stores?.store_name}</div>
                      <div className="text-sm text-gray-500">{penalty.hr_stores?.store_code}</div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="font-medium">{penalty.product_name}</div>
                    {penalty.description && (
                      <div className="text-sm text-gray-500">{penalty.description}</div>
                    )}
                  </TableCell>
                  <TableCell>{penalty.quantity_lost}</TableCell>
                  <TableCell>₹{penalty.unit_value?.toFixed(2)}</TableCell>
                  <TableCell>
                    <div className="font-medium text-red-600">₹{penalty.total_penalty?.toFixed(2)}</div>
                  </TableCell>
                  <TableCell>
                    {new Date(penalty.incident_date).toLocaleDateString()}
                  </TableCell>
                  <TableCell>
                    {getStatusBadge(penalty.status)}
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      {penalty.status === 'pending' && (
                        <>
                          <Button
                            size="sm"
                            onClick={() => approvePenaltyMutation.mutate(penalty.id)}
                            disabled={approvePenaltyMutation.isPending}
                          >
                            <Check className="h-4 w-4" />
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => rejectPenaltyMutation.mutate(penalty.id)}
                            disabled={rejectPenaltyMutation.isPending}
                          >
                            <X className="h-4 w-4" />
                          </Button>
                        </>
                      )}
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </CardContent>
    </Card>
  );
};

export default InventoryPenaltiesList;
