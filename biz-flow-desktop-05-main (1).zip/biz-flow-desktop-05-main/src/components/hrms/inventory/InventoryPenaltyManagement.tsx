
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { AlertTriangle, Plus, Users, DollarSign } from 'lucide-react';
import InventoryPenaltyForm from './InventoryPenaltyForm';
import InventoryPenaltiesList from './InventoryPenaltiesList';

const InventoryPenaltyManagement = () => {
  const [showForm, setShowForm] = useState(false);

  const { data: penalties, isLoading: penaltiesLoading } = useQuery({
    queryKey: ['inventory-penalties'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('hr_inventory_penalties')
        .select(`
          *,
          hr_employees!hr_inventory_penalties_employee_id_fkey (
            first_name,
            last_name,
            employee_code
          ),
          hr_stores!hr_inventory_penalties_store_id_fkey (
            store_name,
            store_code
          )
        `)
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      return data || [];
    },
  });

  const { data: penaltyStats } = useQuery({
    queryKey: ['penalty-stats'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('hr_inventory_penalties')
        .select('status, total_penalty');
      
      if (error) throw error;
      
      const pending = data?.filter(p => p.status === 'pending').length || 0;
      const approved = data?.filter(p => p.status === 'approved').length || 0;
      const totalPending = data?.filter(p => p.status === 'pending').reduce((sum, p) => sum + (p.total_penalty || 0), 0) || 0;
      const totalApproved = data?.filter(p => p.status === 'approved').reduce((sum, p) => sum + (p.total_penalty || 0), 0) || 0;
      
      return { pending, approved, totalPending, totalApproved };
    },
  });

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Inventory Penalty Management</h1>
          <p className="text-muted-foreground">
            Track and manage product losses with salary deductions
          </p>
        </div>
        <Button onClick={() => setShowForm(true)} className="flex items-center gap-2">
          <Plus className="h-4 w-4" />
          Record Penalty
        </Button>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending Penalties</CardTitle>
            <AlertTriangle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {penaltyStats?.pending || 0}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Approved Penalties</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {penaltyStats?.approved || 0}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending Amount</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">
              ₹{penaltyStats?.totalPending?.toFixed(0) || 0}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Deductions</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">
              ₹{penaltyStats?.totalApproved?.toFixed(0) || 0}
            </div>
          </CardContent>
        </Card>
      </div>

      <InventoryPenaltiesList
        penalties={penalties || []}
        loading={penaltiesLoading}
      />

      <InventoryPenaltyForm
        open={showForm}
        onOpenChange={setShowForm}
      />
    </div>
  );
};

export default InventoryPenaltyManagement;
