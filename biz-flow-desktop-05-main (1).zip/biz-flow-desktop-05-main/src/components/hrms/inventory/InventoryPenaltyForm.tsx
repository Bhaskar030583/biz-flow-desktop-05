
import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface InventoryPenaltyFormProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  penalty?: any;
}

const InventoryPenaltyForm: React.FC<InventoryPenaltyFormProps> = ({
  open,
  onOpenChange,
  penalty
}) => {
  const [formData, setFormData] = useState({
    employee_id: penalty?.employee_id || '',
    store_id: penalty?.store_id || '',
    product_name: penalty?.product_name || '',
    quantity_lost: penalty?.quantity_lost || 0,
    unit_value: penalty?.unit_value || 0,
    incident_date: penalty?.incident_date || new Date().toISOString().split('T')[0],
    description: penalty?.description || '',
  });

  const queryClient = useQueryClient();

  const { data: employees = [] } = useQuery({
    queryKey: ['employees'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('hr_employees')
        .select('id, first_name, last_name, employee_code')
        .eq('employment_status', 'active');
      
      if (error) throw error;
      return data || [];
    },
  });

  const { data: stores = [] } = useQuery({
    queryKey: ['hr-stores'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('hr_stores')
        .select('id, store_name, store_code');
      
      if (error) throw error;
      return data || [];
    },
  });

  const createPenaltyMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      const totalPenalty = data.quantity_lost * data.unit_value;
      
      const { data: result, error } = await supabase
        .from('hr_inventory_penalties')
        .insert({
          ...data,
          total_penalty: totalPenalty,
        })
        .select()
        .single();

      if (error) throw error;
      return result;
    },
    onSuccess: () => {
      toast.success('Inventory penalty created successfully');
      queryClient.invalidateQueries({ queryKey: ['inventory-penalties'] });
      onOpenChange(false);
      setFormData({
        employee_id: '',
        store_id: '',
        product_name: '',
        quantity_lost: 0,
        unit_value: 0,
        incident_date: new Date().toISOString().split('T')[0],
        description: '',
      });
    },
    onError: (error) => {
      console.error('Error creating penalty:', error);
      toast.error('Failed to create inventory penalty');
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.employee_id || !formData.store_id || !formData.product_name) {
      toast.error('Please fill in all required fields');
      return;
    }
    createPenaltyMutation.mutate(formData);
  };

  const totalPenalty = formData.quantity_lost * formData.unit_value;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Record Inventory Penalty</DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="employee_id">Employee *</Label>
            <Select value={formData.employee_id} onValueChange={(value) => setFormData({...formData, employee_id: value})}>
              <SelectTrigger>
                <SelectValue placeholder="Select employee" />
              </SelectTrigger>
              <SelectContent>
                {employees.map((employee) => (
                  <SelectItem key={employee.id} value={employee.id}>
                    {employee.first_name} {employee.last_name} ({employee.employee_code})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="store_id">Store *</Label>
            <Select value={formData.store_id} onValueChange={(value) => setFormData({...formData, store_id: value})}>
              <SelectTrigger>
                <SelectValue placeholder="Select store" />
              </SelectTrigger>
              <SelectContent>
                {stores.map((store) => (
                  <SelectItem key={store.id} value={store.id}>
                    {store.store_name} ({store.store_code})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="product_name">Product Name *</Label>
            <Input
              id="product_name"
              value={formData.product_name}
              onChange={(e) => setFormData({...formData, product_name: e.target.value})}
              placeholder="Enter product name"
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="quantity_lost">Quantity Lost *</Label>
              <Input
                id="quantity_lost"
                type="number"
                min="1"
                value={formData.quantity_lost}
                onChange={(e) => setFormData({...formData, quantity_lost: parseInt(e.target.value) || 0})}
                required
              />
            </div>

            <div>
              <Label htmlFor="unit_value">Unit Value (₹) *</Label>
              <Input
                id="unit_value"
                type="number"
                step="0.01"
                min="0"
                value={formData.unit_value}
                onChange={(e) => setFormData({...formData, unit_value: parseFloat(e.target.value) || 0})}
                required
              />
            </div>
          </div>

          <div>
            <Label htmlFor="incident_date">Incident Date *</Label>
            <Input
              id="incident_date"
              type="date"
              value={formData.incident_date}
              onChange={(e) => setFormData({...formData, incident_date: e.target.value})}
              required
            />
          </div>

          <div>
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => setFormData({...formData, description: e.target.value})}
              placeholder="Describe the incident"
              rows={3}
            />
          </div>

          {totalPenalty > 0 && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-lg">
              <p className="text-sm font-medium text-red-800">
                Total Penalty: ₹{totalPenalty.toFixed(2)}
              </p>
            </div>
          )}

          <div className="flex justify-end gap-2">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={createPenaltyMutation.isPending}>
              Create Penalty
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default InventoryPenaltyForm;
