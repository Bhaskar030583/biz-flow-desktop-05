
import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

interface PayrollFormProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  formData: any;
  setFormData: (data: any) => void;
  onSubmit: (e: React.FormEvent) => void;
  loading: boolean;
  employees: any[];
  calculatePay: () => { grossSalary: number; netSalary: number };
}

const PayrollForm: React.FC<PayrollFormProps> = ({
  open,
  onOpenChange,
  formData,
  setFormData,
  onSubmit,
  loading,
  employees,
  calculatePay
}) => {
  const { grossSalary, netSalary } = calculatePay();

  // Fetch pending penalties for selected employee
  const { data: pendingPenalties = [] } = useQuery({
    queryKey: ['pending-penalties', formData.employee_id],
    queryFn: async () => {
      if (!formData.employee_id) return [];
      
      const { data, error } = await supabase
        .from('hr_inventory_penalties')
        .select('*')
        .eq('employee_id', formData.employee_id)
        .eq('status', 'approved')
        .is('deducted_in_payslip', null);
      
      if (error) throw error;
      return data || [];
    },
    enabled: !!formData.employee_id,
  });

  const totalPendingPenalties = pendingPenalties.reduce((sum, p) => sum + (p.total_penalty || 0), 0);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Create Payroll Record</DialogTitle>
        </DialogHeader>
        
        <form onSubmit={onSubmit} className="space-y-6">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="employee_id">Employee *</Label>
              <Select value={formData.employee_id} onValueChange={(value) => setFormData({...formData, employee_id: value})}>
                <SelectTrigger>
                  <SelectValue placeholder="Select employee" />
                </SelectTrigger>
                <SelectContent>
                  {employees.map((employee) => (
                    <SelectItem key={employee.id} value={employee.id}>
                      {employee.first_name} {employee.last_name} ({employee.employee_code})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <Label htmlFor="month">Month *</Label>
                <Select value={formData.month.toString()} onValueChange={(value) => setFormData({...formData, month: parseInt(value)})}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {Array.from({length: 12}, (_, i) => (
                      <SelectItem key={i + 1} value={(i + 1).toString()}>
                        {new Date(2024, i).toLocaleString('default', { month: 'long' })}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="year">Year *</Label>
                <Input
                  id="year"
                  type="number"
                  value={formData.year}
                  onChange={(e) => setFormData({...formData, year: parseInt(e.target.value)})}
                  required
                />
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="total_working_days">Total Working Days</Label>
              <Input
                id="total_working_days"
                type="number"
                value={formData.total_working_days}
                onChange={(e) => setFormData({...formData, total_working_days: parseInt(e.target.value)})}
                required
              />
            </div>

            <div>
              <Label htmlFor="days_worked">Days Worked</Label>
              <Input
                id="days_worked"
                type="number"
                value={formData.days_worked}
                onChange={(e) => setFormData({...formData, days_worked: parseInt(e.target.value)})}
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div>
              <Label htmlFor="regular_hours">Regular Hours</Label>
              <Input
                id="regular_hours"
                type="number"
                step="0.5"
                value={formData.regular_hours}
                onChange={(e) => setFormData({...formData, regular_hours: parseFloat(e.target.value) || 0})}
                required
              />
            </div>

            <div>
              <Label htmlFor="overtime_hours">Overtime Hours</Label>
              <Input
                id="overtime_hours"
                type="number"
                step="0.5"
                value={formData.overtime_hours}
                onChange={(e) => setFormData({...formData, overtime_hours: parseFloat(e.target.value) || 0})}
              />
            </div>

            <div>
              <Label htmlFor="total_hours">Total Hours</Label>
              <Input
                id="total_hours"
                type="number"
                step="0.5"
                value={formData.regular_hours + formData.overtime_hours}
                onChange={(e) => setFormData({...formData, total_hours: parseFloat(e.target.value) || 0})}
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="bonuses">Bonuses</Label>
              <Input
                id="bonuses"
                type="number"
                step="0.01"
                value={formData.bonuses}
                onChange={(e) => setFormData({...formData, bonuses: parseFloat(e.target.value) || 0})}
              />
            </div>

            <div>
              <Label htmlFor="advance_deductions">Advance Deductions</Label>
              <Input
                id="advance_deductions"
                type="number"
                step="0.01"
                value={formData.advance_deductions}
                onChange={(e) => setFormData({...formData, advance_deductions: parseFloat(e.target.value) || 0})}
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="unpaid_leave_deductions">Unpaid Leave Deductions</Label>
              <Input
                id="unpaid_leave_deductions"
                type="number"
                step="0.01"
                value={formData.unpaid_leave_deductions}
                onChange={(e) => setFormData({...formData, unpaid_leave_deductions: parseFloat(e.target.value) || 0})}
              />
            </div>

            <div>
              <Label htmlFor="other_deductions">Other Deductions</Label>
              <Input
                id="other_deductions"
                type="number"
                step="0.01"
                value={formData.other_deductions}
                onChange={(e) => setFormData({...formData, other_deductions: parseFloat(e.target.value) || 0})}
              />
            </div>
          </div>

          {/* Pending Penalties Section */}
          {pendingPenalties.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Pending Inventory Penalties</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {pendingPenalties.map((penalty) => (
                    <div key={penalty.id} className="flex justify-between items-center p-2 bg-red-50 border border-red-200 rounded">
                      <div>
                        <span className="font-medium">{penalty.product_name}</span>
                        <span className="text-sm text-gray-500 ml-2">
                          ({penalty.quantity_lost} units × ₹{penalty.unit_value})
                        </span>
                      </div>
                      <Badge variant="destructive">₹{penalty.total_penalty}</Badge>
                    </div>
                  ))}
                  <div className="flex justify-between items-center pt-2 border-t border-red-200">
                    <span className="font-medium">Total Penalties:</span>
                    <Badge variant="destructive">₹{totalPendingPenalties.toFixed(2)}</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Salary Calculation */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Salary Calculation</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span>Gross Salary:</span>
                  <span className="font-medium">₹{grossSalary.toFixed(2)}</span>
                </div>
                {totalPendingPenalties > 0 && (
                  <div className="flex justify-between text-red-600">
                    <span>Penalty Deductions:</span>
                    <span className="font-medium">-₹{totalPendingPenalties.toFixed(2)}</span>
                  </div>
                )}
                <div className="flex justify-between text-lg font-bold border-t pt-2">
                  <span>Net Salary:</span>
                  <span>₹{(netSalary - totalPendingPenalties).toFixed(2)}</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="flex justify-end gap-2">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={loading}>
              Create Payroll
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default PayrollForm;
