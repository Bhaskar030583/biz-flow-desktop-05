
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Download } from 'lucide-react';

interface PayrollRecord {
  id: string;
  month: number;
  year: number;
  gross_salary: number;
  net_salary: number;
  is_final: boolean;
  hr_employees?: {
    first_name: string;
    last_name: string;
    employee_code: string;
    hourly_rate: number;
  } | null;
}

interface PayrollRecordsListProps {
  payrollRecords: PayrollRecord[];
}

const PayrollRecordsList: React.FC<PayrollRecordsListProps> = ({ payrollRecords }) => {
  const getStatusBadge = (isFinal: boolean) => {
    return isFinal ? 
      <Badge className="bg-green-500">Final</Badge> : 
      <Badge variant="secondary">Draft</Badge>;
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Payroll Records</CardTitle>
        <CardDescription>Manage all employee payroll records</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {payrollRecords.map((record) => (
            <div key={record.id} className="flex items-center justify-between p-4 border rounded-lg">
              <div className="flex items-center space-x-4">
                <div>
                  <p className="font-medium">
                    {record.hr_employees?.first_name || 'Unknown'} {record.hr_employees?.last_name || ''}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    {record.hr_employees?.employee_code || 'N/A'}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    {new Date(0, record.month - 1).toLocaleString('default', { month: 'long' })} {record.year}
                  </p>
                </div>
              </div>

              <div className="flex items-center space-x-4">
                <div className="text-center">
                  <p className="text-sm font-medium">Gross Salary</p>
                  <p className="text-sm text-muted-foreground">
                    ₹{record.gross_salary.toFixed(2)}
                  </p>
                </div>

                <div className="text-center">
                  <p className="text-sm font-medium">Net Salary</p>
                  <p className="text-sm font-medium text-green-600">
                    ₹{record.net_salary.toFixed(2)}
                  </p>
                </div>

                <div className="text-center">
                  <p className="text-sm font-medium">Status</p>
                  {getStatusBadge(record.is_final)}
                </div>

                <Button variant="outline" size="sm">
                  <Download className="h-4 w-4" />
                </Button>
              </div>
            </div>
          ))}

          {payrollRecords.length === 0 && (
            <div className="text-center py-8">
              <p className="text-muted-foreground">No payroll records found</p>
              <p className="text-sm text-muted-foreground mt-2">
                Create your first payroll record to get started
              </p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default PayrollRecordsList;
