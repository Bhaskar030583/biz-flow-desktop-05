
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { DollarSign, Calendar } from 'lucide-react';

interface PayrollRecord {
  id: string;
  month: number;
  year: number;
  net_salary: number;
  is_final: boolean;
}

interface PayrollStatsProps {
  payrollRecords: PayrollRecord[];
}

const PayrollStats: React.FC<PayrollStatsProps> = ({ payrollRecords }) => {
  const currentMonth = new Date().getMonth() + 1;
  const currentYear = new Date().getFullYear();

  const thisMonthTotal = payrollRecords
    .filter(r => r.month === currentMonth && r.year === currentYear)
    .reduce((sum, r) => sum + r.net_salary, 0);

  const draftRecords = payrollRecords.filter(r => !r.is_final).length;
  const finalRecords = payrollRecords.filter(r => r.is_final).length;

  return (
    <div className="grid gap-4 md:grid-cols-4">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Total Records</CardTitle>
          <DollarSign className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{payrollRecords.length}</div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">This Month Total</CardTitle>
          <DollarSign className="h-4 w-4 text-green-500" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">
            ₹{thisMonthTotal.toFixed(0)}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Draft Records</CardTitle>
          <Calendar className="h-4 w-4 text-orange-500" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{draftRecords}</div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Final Records</CardTitle>
          <DollarSign className="h-4 w-4 text-blue-500" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{finalRecords}</div>
        </CardContent>
      </Card>
    </div>
  );
};

export default PayrollStats;
