
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { 
  User, 
  FileText, 
  Target, 
  MessageSquare, 
  Upload, 
  Calendar,
  Clock,
  Star,
  Award,
  BookOpen
} from 'lucide-react';

const EmployeeSelfService = () => {
  const [activeGoals, setActiveGoals] = useState([
    { id: 1, title: 'Complete Sales Training', progress: 75, deadline: '2024-02-15' },
    { id: 2, title: 'Improve Customer Satisfaction', progress: 60, deadline: '2024-03-01' },
  ]);

  const [documents, setDocuments] = useState([
    { id: 1, name: 'Aadhar Card', type: 'Identity', uploaded: '2024-01-15', status: 'verified' },
    { id: 2, name: 'PAN Card', type: 'Identity', uploaded: '2024-01-15', status: 'verified' },
    { id: 3, name: 'Bank Statement', type: 'Financial', uploaded: '2024-01-20', status: 'pending' },
  ]);

  const [feedback, setFeedback] = useState([
    { id: 1, from: 'Manager', rating: 4, comment: 'Great performance this quarter', date: '2024-01-20' },
    { id: 2, from: 'Peer', rating: 5, comment: 'Excellent team collaboration', date: '2024-01-18' },
  ]);

  const trainingModules = [
    { id: 1, title: 'Customer Service Excellence', progress: 100, completed: true },
    { id: 2, title: 'Product Knowledge', progress: 80, completed: false },
    { id: 3, title: 'Sales Techniques', progress: 45, completed: false },
    { id: 4, title: 'Digital Tools Training', progress: 0, completed: false },
  ];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Employee Self Service</h2>
        <Button>
          <User className="h-4 w-4 mr-2" />
          Update Profile
        </Button>
      </div>

      <Tabs defaultValue="documents" className="space-y-4">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="documents">Documents</TabsTrigger>
          <TabsTrigger value="goals">Goals</TabsTrigger>
          <TabsTrigger value="feedback">Feedback</TabsTrigger>
          <TabsTrigger value="training">Training</TabsTrigger>
          <TabsTrigger value="requests">Requests</TabsTrigger>
        </TabsList>

        <TabsContent value="documents">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Document Management
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="border-2 border-dashed border-muted rounded-lg p-6 text-center">
                  <Upload className="h-8 w-8 mx-auto mb-2 text-muted-foreground" />
                  <p className="text-sm text-muted-foreground mb-2">
                    Drag and drop files here or click to upload
                  </p>
                  <Button variant="outline" size="sm">
                    Choose Files
                  </Button>
                </div>

                <div className="space-y-3">
                  {documents.map((doc) => (
                    <div key={doc.id} className="flex items-center justify-between p-3 border rounded-lg">
                      <div className="flex items-center gap-3">
                        <FileText className="h-4 w-4" />
                        <div>
                          <p className="font-medium">{doc.name}</p>
                          <p className="text-sm text-muted-foreground">
                            {doc.type} • Uploaded {doc.uploaded}
                          </p>
                        </div>
                      </div>
                      <Badge 
                        variant={doc.status === 'verified' ? 'default' : 'secondary'}
                        className={doc.status === 'verified' ? 'bg-green-500' : ''}
                      >
                        {doc.status}
                      </Badge>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="goals">
          <div className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Target className="h-5 w-5" />
                  Goal Setting & Tracking
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {activeGoals.map((goal) => (
                    <div key={goal.id} className="p-4 border rounded-lg">
                      <div className="flex justify-between items-start mb-3">
                        <h4 className="font-medium">{goal.title}</h4>
                        <Badge variant="outline">
                          Deadline: {goal.deadline}
                        </Badge>
                      </div>
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>Progress</span>
                          <span>{goal.progress}%</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div 
                            className="bg-blue-600 h-2 rounded-full" 
                            style={{ width: `${goal.progress}%` }}
                          ></div>
                        </div>
                      </div>
                    </div>
                  ))}

                  <div className="border-2 border-dashed border-muted rounded-lg p-6">
                    <h4 className="font-medium mb-3">Add New Goal</h4>
                    <div className="space-y-3">
                      <Input placeholder="Goal title" />
                      <Textarea placeholder="Goal description" />
                      <Input type="date" />
                      <Button>Add Goal</Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="feedback">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MessageSquare className="h-5 w-5" />
                360° Feedback & Reviews
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {feedback.map((item) => (
                  <div key={item.id} className="p-4 border rounded-lg">
                    <div className="flex justify-between items-start mb-2">
                      <div className="flex items-center gap-2">
                        <span className="font-medium">From: {item.from}</span>
                        <div className="flex">
                          {[...Array(5)].map((_, i) => (
                            <Star 
                              key={i} 
                              className={`h-4 w-4 ${
                                i < item.rating ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'
                              }`} 
                            />
                          ))}
                        </div>
                      </div>
                      <Badge variant="outline">{item.date}</Badge>
                    </div>
                    <p className="text-sm text-muted-foreground">{item.comment}</p>
                  </div>
                ))}

                <div className="border-2 border-dashed border-muted rounded-lg p-6">
                  <h4 className="font-medium mb-3">Request Feedback</h4>
                  <div className="space-y-3">
                    <Input placeholder="Select colleague or manager" />
                    <Textarea placeholder="What would you like feedback on?" />
                    <Button>Send Request</Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="training">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BookOpen className="h-5 w-5" />
                Training & Development
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {trainingModules.map((module) => (
                  <div key={module.id} className="p-4 border rounded-lg">
                    <div className="flex justify-between items-center mb-3">
                      <h4 className="font-medium">{module.title}</h4>
                      {module.completed ? (
                        <Badge className="bg-green-500">
                          <Award className="h-3 w-3 mr-1" />
                          Completed
                        </Badge>
                      ) : (
                        <Badge variant="outline">In Progress</Badge>
                      )}
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>Progress</span>
                        <span>{module.progress}%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div 
                          className={`h-2 rounded-full ${
                            module.completed ? 'bg-green-500' : 'bg-blue-600'
                          }`}
                          style={{ width: `${module.progress}%` }}
                        ></div>
                      </div>
                      {!module.completed && (
                        <Button variant="outline" size="sm" className="mt-2">
                          Continue Learning
                        </Button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="requests">
          <div className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Quick Requests</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4 md:grid-cols-2">
                  <Button variant="outline" className="h-20 flex-col">
                    <Calendar className="h-6 w-6 mb-2" />
                    <span>Apply for Leave</span>
                  </Button>
                  <Button variant="outline" className="h-20 flex-col">
                    <Clock className="h-6 w-6 mb-2" />
                    <span>Permission Request</span>
                  </Button>
                  <Button variant="outline" className="h-20 flex-col">
                    <FileText className="h-6 w-6 mb-2" />
                    <span>Salary Certificate</span>
                  </Button>
                  <Button variant="outline" className="h-20 flex-col">
                    <User className="h-6 w-6 mb-2" />
                    <span>Profile Update</span>
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Request History</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <p className="font-medium">Leave Application</p>
                      <p className="text-sm text-muted-foreground">Applied on Jan 20, 2024</p>
                    </div>
                    <Badge className="bg-green-500">Approved</Badge>
                  </div>
                  <div className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <p className="font-medium">Permission Request</p>
                      <p className="text-sm text-muted-foreground">Applied on Jan 18, 2024</p>
                    </div>
                    <Badge variant="secondary">Pending</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default EmployeeSelfService;
