
import React from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';

interface ShiftFormData {
  shift_name: string;
  start_time: string;
  end_time: string;
  break_duration: number;
  is_active: boolean;
}

interface ShiftFormProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  formData: ShiftFormData;
  setFormData: (data: ShiftFormData) => void;
  onSubmit: (e: React.FormEvent) => void;
  loading: boolean;
}

const ShiftForm: React.FC<ShiftFormProps> = ({
  open,
  onOpenChange,
  formData,
  setFormData,
  onSubmit,
  loading
}) => {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Add New Shift</DialogTitle>
          <DialogDescription>
            Create a new work shift with time schedules
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={onSubmit} className="space-y-4">
          <div>
            <Label htmlFor="shift_name">Shift Name</Label>
            <Input
              id="shift_name"
              value={formData.shift_name}
              onChange={(e) => setFormData({...formData, shift_name: e.target.value})}
              placeholder="e.g., Morning Shift"
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="start_time">Start Time</Label>
              <Input
                id="start_time"
                type="time"
                value={formData.start_time}
                onChange={(e) => setFormData({...formData, start_time: e.target.value})}
                required
              />
            </div>
            <div>
              <Label htmlFor="end_time">End Time</Label>
              <Input
                id="end_time"
                type="time"
                value={formData.end_time}
                onChange={(e) => setFormData({...formData, end_time: e.target.value})}
                required
              />
            </div>
          </div>

          <div>
            <Label htmlFor="break_duration">Break Duration (minutes)</Label>
            <Input
              id="break_duration"
              type="number"
              value={formData.break_duration}
              onChange={(e) => setFormData({...formData, break_duration: parseInt(e.target.value) || 0})}
              placeholder="30"
            />
          </div>

          <div className="flex justify-end space-x-2 pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={loading}>
              {loading ? 'Creating...' : 'Create Shift'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default ShiftForm;
