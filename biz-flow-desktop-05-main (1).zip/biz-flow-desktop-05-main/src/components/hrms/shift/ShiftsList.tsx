
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

interface Shift {
  id: string;
  shift_name: string;
  start_time: string;
  end_time: string;
  break_duration: number;
  is_active: boolean;
}

interface ShiftsListProps {
  shifts: Shift[];
}

const ShiftsList: React.FC<ShiftsListProps> = ({ shifts }) => {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Shifts</CardTitle>
        <CardDescription>Manage all work shifts</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {shifts.map((shift) => (
            <div key={shift.id} className="flex items-center justify-between p-4 border rounded-lg">
              <div>
                <h3 className="font-medium">{shift.shift_name}</h3>
                <p className="text-sm text-muted-foreground">
                  {shift.start_time} - {shift.end_time}
                </p>
                <p className="text-sm text-muted-foreground">
                  Break: {shift.break_duration} minutes
                </p>
              </div>
              <div className="flex items-center space-x-2">
                <Badge variant={shift.is_active ? "default" : "secondary"}>
                  {shift.is_active ? "Active" : "Inactive"}
                </Badge>
              </div>
            </div>
          ))}

          {shifts.length === 0 && (
            <div className="text-center py-8">
              <p className="text-muted-foreground">No shifts found</p>
              <p className="text-sm text-muted-foreground mt-2">
                Create your first shift to get started
              </p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default ShiftsList;
