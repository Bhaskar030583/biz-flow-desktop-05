
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Users, Clock, Calendar, DollarSign, MapPin, CheckCircle, ArrowLeft, Bell, BarChart3, User, Target } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import RealtimeAttendanceDashboard from './RealtimeAttendanceDashboard';
import NotificationCenter from './NotificationCenter';
import AdvancedAnalytics from './AdvancedAnalytics';
import EmployeeSelfService from './EmployeeSelfService';

const HRMSDashboard = () => {
  const navigate = useNavigate();

  // Fetch real data from database
  const { data: employees } = useQuery({
    queryKey: ['hr-employees'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('hr_employees')
        .select('*')
        .eq('employment_status', 'active');
      if (error) throw error;
      return data || [];
    }
  });

  const { data: stores } = useQuery({
    queryKey: ['hr-stores'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('hr_stores')
        .select('*');
      if (error) throw error;
      return data || [];
    }
  });

  const { data: todayAttendance } = useQuery({
    queryKey: ['hr-attendance-today'],
    queryFn: async () => {
      const today = new Date().toISOString().split('T')[0];
      const { data, error } = await supabase
        .from('hr_attendance')
        .select('*')
        .eq('attendance_date', today)
        .eq('status', 'present');
      if (error) throw error;
      return data || [];
    }
  });

  const { data: pendingLeaves } = useQuery({
    queryKey: ['hr-pending-leaves'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('hr_leave_requests')
        .select('*')
        .eq('status', 'pending');
      if (error) throw error;
      return data || [];
    }
  });

  const quickStats = [
    { 
      label: 'Total Employees', 
      value: employees?.length.toString() || '0', 
      icon: Users, 
      color: 'bg-blue-500' 
    },
    { 
      label: 'Present Today', 
      value: todayAttendance?.length.toString() || '0', 
      icon: CheckCircle, 
      color: 'bg-green-500' 
    },
    { 
      label: 'Active Stores', 
      value: stores?.length.toString() || '0', 
      icon: MapPin, 
      color: 'bg-purple-500' 
    },
    { 
      label: 'Pending Leaves', 
      value: pendingLeaves?.length.toString() || '0', 
      icon: Calendar, 
      color: 'bg-orange-500' 
    },
  ];

  const moduleCards = [
    {
      title: 'Employee Management',
      description: 'Manage employee records, profiles, and basic information',
      path: 'employees',
      icon: Users,
    },
    {
      title: 'Store Management',
      description: 'Manage store locations, geo-fencing, and store settings',
      path: 'stores',
      icon: MapPin,
    },
    {
      title: 'Shift Management',
      description: 'Create and manage work shifts, assignments, and schedules',
      path: 'shifts',
      icon: Clock,
    },
    {
      title: 'Attendance Tracking',
      description: 'Monitor employee attendance, check-ins, and working hours',
      path: 'attendance',
      icon: CheckCircle,
    },
    {
      title: 'Leave Management',
      description: 'Handle leave requests, approvals, and leave policies',
      path: 'leaves',
      icon: Calendar,
    },
    {
      title: 'Payroll & Salary',
      description: 'Manage salaries, advances, deductions, and payslips',
      path: 'payroll',
      icon: DollarSign,
    },
    {
      title: 'Sales Targets',
      description: 'Set and track sales targets for employees and stores',
      path: 'sales-targets',
      icon: Target,
    },
  ];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">HRMS Dashboard</h1>
          <p className="text-muted-foreground">
            Human Resource Management System - Comprehensive employee management
          </p>
        </div>
        <div className="flex gap-2">
          <Button 
            onClick={() => navigate('/hrms/employee-login')}
            variant="outline"
          >
            Employee Login
          </Button>
          <Button onClick={() => navigate('/hrms/quick-setup')}>
            Quick Setup
          </Button>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {quickStats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <Card key={index}>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  {stat.label}
                </CardTitle>
                <div className={`p-2 rounded-md ${stat.color}`}>
                  <Icon className="h-4 w-4 text-white" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stat.value}</div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="realtime">Live Tracking</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
          <TabsTrigger value="notifications">Notifications</TabsTrigger>
          <TabsTrigger value="selfservice">Self Service</TabsTrigger>
        </TabsList>

        <TabsContent value="overview">
          {/* HRMS Modules */}
          <div>
            <h2 className="text-2xl font-semibold mb-4">HRMS Modules</h2>
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {moduleCards.map((module, index) => {
                const Icon = module.icon;
                return (
                  <Card key={index} className="cursor-pointer hover:shadow-lg transition-shadow">
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          <Icon className="h-6 w-6 text-primary" />
                          <CardTitle className="text-lg">{module.title}</CardTitle>
                        </div>
                      </div>
                      <CardDescription>{module.description}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <Button 
                        onClick={() => navigate(`/hrms/${module.path}`)}
                        className="w-full"
                      >
                        Open Module
                      </Button>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>

          {/* Getting Started Guide */}
          <Card>
            <CardHeader>
              <CardTitle>Getting Started with HRMS</CardTitle>
              <CardDescription>
                Follow these steps to set up your HR system
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center space-x-3">
                  <Badge variant="secondary">1</Badge>
                  <div>
                    <p className="font-medium">Set up Stores</p>
                    <p className="text-sm text-muted-foreground">
                      Create store locations with geo-fencing settings
                    </p>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <Badge variant="secondary">2</Badge>
                  <div>
                    <p className="font-medium">Create Shifts</p>
                    <p className="text-sm text-muted-foreground">
                      Define work shifts and time schedules
                    </p>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <Badge variant="secondary">3</Badge>
                  <div>
                    <p className="font-medium">Add Employees</p>
                    <p className="text-sm text-muted-foreground">
                      Register employees with their details and assignments
                    </p>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <Badge variant="secondary">4</Badge>
                  <div>
                    <p className="font-medium">Start Tracking</p>
                    <p className="text-sm text-muted-foreground">
                      Begin attendance tracking and payroll management
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="realtime">
          <RealtimeAttendanceDashboard />
        </TabsContent>

        <TabsContent value="analytics">
          <AdvancedAnalytics />
        </TabsContent>

        <TabsContent value="notifications">
          <NotificationCenter />
        </TabsContent>

        <TabsContent value="selfservice">
          <EmployeeSelfService />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default HRMSDashboard;
