
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell } from 'recharts';
import { TrendingUp, TrendingDown, Users, Clock, Calendar, Download } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { format, subDays, startOfWeek, endOfWeek } from 'date-fns';

const AdvancedAnalytics = () => {
  const [selectedPeriod, setSelectedPeriod] = useState('month');

  // Fetch real attendance data
  const { data: attendanceData } = useQuery({
    queryKey: ['hr-attendance-analytics', selectedPeriod],
    queryFn: async () => {
      const endDate = new Date();
      let startDate = new Date();
      
      switch (selectedPeriod) {
        case 'week':
          startDate = startOfWeek(endDate);
          break;
        case 'month':
          startDate = subDays(endDate, 30);
          break;
        case 'quarter':
          startDate = subDays(endDate, 90);
          break;
      }

      const { data, error } = await supabase
        .from('hr_attendance')
        .select(`
          *,
          hr_employees!hr_attendance_employee_id_fkey(first_name, last_name, department)
        `)
        .gte('attendance_date', format(startDate, 'yyyy-MM-dd'))
        .lte('attendance_date', format(endDate, 'yyyy-MM-dd'));

      if (error) throw error;
      return data || [];
    }
  });

  // Fetch payroll data
  const { data: payrollData } = useQuery({
    queryKey: ['hr-payroll-analytics'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('hr_payslips')
        .select(`
          *,
          hr_employees!hr_payslips_employee_id_fkey(first_name, last_name, department)
        `)
        .order('month', { ascending: false })
        .limit(6);

      if (error) throw error;
      return data || [];
    }
  });

  // Process attendance data for charts
  const processedAttendanceData = React.useMemo(() => {
    if (!attendanceData) return [];
    
    const dailyData = attendanceData.reduce((acc, record) => {
      const date = format(new Date(record.attendance_date), 'MMM dd');
      if (!acc[date]) {
        acc[date] = { name: date, present: 0, absent: 0, late: 0 };
      }
      
      if (record.status === 'present') {
        acc[date].present += 1;
        if (record.is_late) {
          acc[date].late += 1;
        }
      } else {
        acc[date].absent += 1;
      }
      
      return acc;
    }, {} as Record<string, any>);

    return Object.values(dailyData);
  }, [attendanceData]);

  // Process productivity data
  const productivityData = React.useMemo(() => {
    if (!attendanceData) return [];
    
    const monthlyData = attendanceData.reduce((acc, record) => {
      const month = format(new Date(record.attendance_date), 'MMM');
      if (!acc[month]) {
        acc[month] = { month, hours: 0, overtime: 0 };
      }
      
      acc[month].hours += Number(record.total_hours) || 0;
      acc[month].overtime += Number(record.overtime_hours) || 0;
      
      return acc;
    }, {} as Record<string, any>);

    return Object.values(monthlyData);
  }, [attendanceData]);

  // Process department data
  const departmentData = React.useMemo(() => {
    if (!attendanceData) return [];
    
    const deptCount = attendanceData.reduce((acc, record) => {
      const dept = record.hr_employees?.department || 'Other';
      acc[dept] = (acc[dept] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    const colors = ['#8884d8', '#82ca9d', '#ffc658', '#ff7300', '#00ff88'];
    return Object.entries(deptCount).map(([name, value], index) => ({
      name,
      value,
      color: colors[index % colors.length]
    }));
  }, [attendanceData]);

  // Calculate KPIs
  const kpis = React.useMemo(() => {
    if (!attendanceData) return [];
    
    const totalRecords = attendanceData.length;
    const presentRecords = attendanceData.filter(r => r.status === 'present').length;
    const lateRecords = attendanceData.filter(r => r.is_late).length;
    const totalHours = attendanceData.reduce((sum, r) => sum + (Number(r.total_hours) || 0), 0);
    const overtimeHours = attendanceData.reduce((sum, r) => sum + (Number(r.overtime_hours) || 0), 0);
    
    const attendanceRate = totalRecords > 0 ? (presentRecords / totalRecords) * 100 : 0;
    const avgHours = presentRecords > 0 ? totalHours / presentRecords : 0;
    const punctualityRate = presentRecords > 0 ? ((presentRecords - lateRecords) / presentRecords) * 100 : 0;

    return [
      {
        title: 'Attendance Rate',
        value: `${attendanceRate.toFixed(1)}%`,
        change: '+2.1%',
        trend: 'up',
        icon: Users
      },
      {
        title: 'Average Hours',
        value: `${avgHours.toFixed(1)}h`,
        change: '+0.3h',
        trend: 'up',
        icon: Clock
      },
      {
        title: 'Overtime Hours',
        value: `${overtimeHours.toFixed(0)}h`,
        change: '-12h',
        trend: 'down',
        icon: Clock
      },
      {
        title: 'Punctuality Rate',
        value: `${punctualityRate.toFixed(0)}%`,
        change: '+5%',
        trend: 'up',
        icon: Calendar
      }
    ];
  }, [attendanceData]);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">HR Analytics Dashboard</h2>
        <div className="flex gap-2">
          <Button
            variant={selectedPeriod === 'week' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setSelectedPeriod('week')}
          >
            Week
          </Button>
          <Button
            variant={selectedPeriod === 'month' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setSelectedPeriod('month')}
          >
            Month
          </Button>
          <Button
            variant={selectedPeriod === 'quarter' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setSelectedPeriod('quarter')}
          >
            Quarter
          </Button>
          <Button variant="outline" size="sm">
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid gap-4 md:grid-cols-4">
        {kpis.map((kpi, index) => {
          const Icon = kpi.icon;
          return (
            <Card key={index}>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">{kpi.title}</CardTitle>
                <Icon className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{kpi.value}</div>
                <div className="flex items-center gap-1 text-sm">
                  {kpi.trend === 'up' ? (
                    <TrendingUp className="h-3 w-3 text-green-500" />
                  ) : (
                    <TrendingDown className="h-3 w-3 text-red-500" />
                  )}
                  <span className={kpi.trend === 'up' ? 'text-green-500' : 'text-red-500'}>
                    {kpi.change}
                  </span>
                  <span className="text-muted-foreground">from last {selectedPeriod}</span>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        {/* Attendance Trends */}
        <Card>
          <CardHeader>
            <CardTitle>Attendance Trends</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={processedAttendanceData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="present" fill="#22c55e" name="Present" />
                <Bar dataKey="late" fill="#f59e0b" name="Late" />
                <Bar dataKey="absent" fill="#ef4444" name="Absent" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Productivity Trends */}
        <Card>
          <CardHeader>
            <CardTitle>Productivity Trends</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={productivityData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip />
                <Line type="monotone" dataKey="hours" stroke="#3b82f6" name="Regular Hours" />
                <Line type="monotone" dataKey="overtime" stroke="#f59e0b" name="Overtime Hours" />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        {/* Department Distribution */}
        <Card>
          <CardHeader>
            <CardTitle>Employee Distribution by Department</CardTitle>
          </CardHeader>
          <CardContent>
            {departmentData.length > 0 ? (
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={departmentData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {departmentData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="flex items-center justify-center h-[300px] text-muted-foreground">
                No department data available
              </div>
            )}
          </CardContent>
        </Card>

        {/* Performance Metrics */}
        <Card>
          <CardHeader>
            <CardTitle>Performance Insights</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {attendanceData && attendanceData.length > 0 ? (
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm">Total Records</span>
                  <Badge>{attendanceData.length}</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm">Present Today</span>
                  <Badge>{attendanceData.filter(r => r.status === 'present').length}</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm">Late Arrivals</span>
                  <Badge variant="destructive">{attendanceData.filter(r => r.is_late).length}</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm">Average Hours</span>
                  <Badge className="bg-green-500">
                    {(attendanceData.reduce((sum, r) => sum + (Number(r.total_hours) || 0), 0) / Math.max(attendanceData.length, 1)).toFixed(1)}h
                  </Badge>
                </div>
              </div>
            ) : (
              <div className="text-center text-muted-foreground">
                No attendance data available for the selected period
              </div>
            )}
            
            <div className="pt-4 border-t">
              <h4 className="font-medium mb-2">Recommendations</h4>
              <div className="space-y-2 text-sm text-muted-foreground">
                <p>• Add employees and record attendance to see analytics</p>
                <p>• Set up shifts and stores for better tracking</p>
                <p>• Monitor attendance patterns for insights</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default AdvancedAnalytics;
