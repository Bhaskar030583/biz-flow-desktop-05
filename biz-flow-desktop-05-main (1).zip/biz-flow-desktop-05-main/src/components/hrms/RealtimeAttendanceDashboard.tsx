
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Users, Clock, MapPin, CheckCircle2, User } from 'lucide-react';
import { useRealtimeAttendance } from '@/hooks/useRealtimeAttendance';

const RealtimeAttendanceDashboard = () => {
  const { attendanceRecords, onlineEmployees } = useRealtimeAttendance();

  const todayRecords = attendanceRecords.filter(
    record => record.attendance_date === new Date().toISOString().split('T')[0]
  );

  const checkedInToday = todayRecords.filter(record => record.check_in_time);
  const stillWorking = checkedInToday.filter(record => !record.check_out_time);

  return (
    <div className="space-y-6">
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Checked In Today</CardTitle>
            <CheckCircle2 className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{checkedInToday.length}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Currently Working</CardTitle>
            <Clock className="h-4 w-4 text-blue-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">{stillWorking.length}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Online Now</CardTitle>
            <User className="h-4 w-4 text-orange-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">{onlineEmployees.length}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Late Check-ins</CardTitle>
            <Clock className="h-4 w-4 text-red-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">
              {todayRecords.filter(record => record.is_late).length}
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="h-5 w-5" />
            Live Attendance Feed
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {stillWorking.slice(0, 10).map((record) => (
              <div key={record.id} className="flex items-center justify-between p-3 border rounded-lg">
                <div className="flex items-center space-x-3">
                  <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                  <div>
                    <p className="font-medium">
                      {record.hr_employees?.first_name} {record.hr_employees?.last_name}
                    </p>
                    <p className="text-sm text-muted-foreground">
                      {record.hr_employees?.employee_code} • {record.hr_stores?.store_name}
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <Badge className="bg-green-500">Working</Badge>
                  <p className="text-sm text-muted-foreground mt-1">
                    Since {record.check_in_time ? 
                      new Date(record.check_in_time).toLocaleTimeString('en-US', {
                        hour: '2-digit',
                        minute: '2-digit'
                      }) : 'N/A'
                    }
                  </p>
                </div>
              </div>
            ))}
            
            {stillWorking.length === 0 && (
              <div className="text-center py-8">
                <p className="text-muted-foreground">No employees currently working</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default RealtimeAttendanceDashboard;
