import React, { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Calendar, Plus, Check, X, Clock } from 'lucide-react';
import { toast } from 'sonner';
import { Employee, LeaveRequest } from '@/types/hrms';

interface LeaveFormData {
  employee_id: string;
  leave_type: 'sick' | 'casual' | 'paid' | 'unpaid' | 'maternity' | 'paternity';
  start_date: string;
  end_date: string;
  reason: string;
  is_half_day: boolean;
}

const LeaveManagement = () => {
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [formData, setFormData] = useState<LeaveFormData>({
    employee_id: '',
    leave_type: 'casual',
    start_date: '',
    end_date: '',
    reason: '',
    is_half_day: false,
  });

  const queryClient = useQueryClient();

  // Fetch employees
  const { data: employees = [] } = useQuery({
    queryKey: ['employees'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('hr_employees')
        .select('*')
        .eq('employment_status', 'active');

      if (error) {
        console.error('Error fetching employees:', error);
        throw error;
      }
      
      // Map employees with hire_date
      const mappedEmployees: Employee[] = (data || []).map(emp => ({
        ...emp,
        hire_date: emp.date_of_joining || emp.created_at,
      }));
      
      return mappedEmployees;
    },
  });

  // Fetch leave requests
  const { data: leaveRequests = [], isLoading } = useQuery({
    queryKey: ['leave-requests'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('hr_leave_requests')
        .select(`
          *,
          hr_employees!employee_id (
            first_name,
            last_name,
            employee_code
          )
        `)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching leave requests:', error);
        throw error;
      }
      return data as LeaveRequest[];
    },
  });

  // Create leave request mutation
  const createLeaveRequestMutation = useMutation({
    mutationFn: async (data: LeaveFormData) => {
      const startDate = new Date(data.start_date);
      const endDate = new Date(data.end_date);
      
      // Calculate total days
      let totalDays = Math.ceil((endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24)) + 1;
      
      if (data.is_half_day) {
        totalDays = 0.5;
      }

      const { data: result, error } = await supabase
        .from('hr_leave_requests')
        .insert({
          employee_id: data.employee_id,
          leave_type: data.leave_type,
          start_date: data.start_date,
          end_date: data.end_date,
          total_days: totalDays,
          reason: data.reason,
          is_half_day: data.is_half_day,
        })
        .select()
        .single();

      if (error) throw error;
      return result;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['leave-requests'] });
      toast.success('Leave request submitted successfully');
      setIsFormOpen(false);
      setFormData({
        employee_id: '',
        leave_type: 'casual',
        start_date: '',
        end_date: '',
        reason: '',
        is_half_day: false,
      });
    },
    onError: (error) => {
      console.error('Error creating leave request:', error);
      toast.error('Failed to submit leave request');
    },
  });

  // Approve leave request mutation
  const approveLeaveRequestMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from('hr_leave_requests')
        .update({
          status: 'approved',
          approved_by: (await supabase.auth.getUser()).data.user?.id,
          approved_on: new Date().toISOString(),
        })
        .eq('id', id);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['leave-requests'] });
      toast.success('Leave request approved');
    },
    onError: (error) => {
      console.error('Error approving leave request:', error);
      toast.error('Failed to approve leave request');
    },
  });

  // Reject leave request mutation
  const rejectLeaveRequestMutation = useMutation({
    mutationFn: async ({ id, reason }: { id: string; reason: string }) => {
      const { error } = await supabase
        .from('hr_leave_requests')
        .update({
          status: 'rejected',
          rejection_reason: reason,
          approved_by: (await supabase.auth.getUser()).data.user?.id,
          approved_on: new Date().toISOString(),
        })
        .eq('id', id);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['leave-requests'] });
      toast.success('Leave request rejected');
    },
    onError: (error) => {
      console.error('Error rejecting leave request:', error);
      toast.error('Failed to reject leave request');
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.employee_id || !formData.start_date || !formData.end_date || !formData.reason) {
      toast.error('Please fill in all required fields');
      return;
    }
    createLeaveRequestMutation.mutate(formData);
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'approved':
        return <Badge className="bg-green-500">Approved</Badge>;
      case 'rejected':
        return <Badge variant="destructive">Rejected</Badge>;
      default:
        return <Badge variant="secondary">Pending</Badge>;
    }
  };

  const getLeaveTypeBadge = (type: string) => {
    const colorMap: Record<string, string> = {
      sick: 'bg-red-100 text-red-800',
      casual: 'bg-green-100 text-green-800',
      paid: 'bg-indigo-100 text-indigo-800',
      unpaid: 'bg-gray-100 text-gray-800',
      maternity: 'bg-pink-100 text-pink-800',
      paternity: 'bg-cyan-100 text-cyan-800',
    };

    return (
      <Badge variant="outline" className={colorMap[type] || 'bg-gray-100 text-gray-800'}>
        {type.charAt(0).toUpperCase() + type.slice(1)}
      </Badge>
    );
  };

  if (isLoading) {
    return <div className="flex items-center justify-center p-8">Loading leave requests...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Leave Management</h1>
          <p className="text-muted-foreground">
            Manage employee leave requests and approvals
          </p>
        </div>
        <Dialog open={isFormOpen} onOpenChange={setIsFormOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              New Leave Request
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Submit Leave Request</DialogTitle>
              <DialogDescription>
                Fill in the details for the leave request
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="employee_id">Employee</Label>
                <Select value={formData.employee_id} onValueChange={(value) => setFormData({...formData, employee_id: value})}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select employee" />
                  </SelectTrigger>
                  <SelectContent>
                    {employees.map((employee) => (
                      <SelectItem key={employee.id} value={employee.id}>
                        {employee.first_name} {employee.last_name} ({employee.employee_code})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="leave_type">Leave Type</Label>
                <Select value={formData.leave_type} onValueChange={(value: any) => setFormData({...formData, leave_type: value})}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="sick">Sick Leave</SelectItem>
                    <SelectItem value="casual">Casual Leave</SelectItem>
                    <SelectItem value="paid">Paid Leave</SelectItem>
                    <SelectItem value="unpaid">Unpaid Leave</SelectItem>
                    <SelectItem value="maternity">Maternity Leave</SelectItem>
                    <SelectItem value="paternity">Paternity Leave</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="start_date">Start Date</Label>
                  <Input
                    id="start_date"
                    type="date"
                    value={formData.start_date}
                    onChange={(e) => setFormData({...formData, start_date: e.target.value})}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="end_date">End Date</Label>
                  <Input
                    id="end_date"
                    type="date"
                    value={formData.end_date}
                    onChange={(e) => setFormData({...formData, end_date: e.target.value})}
                    required
                  />
                </div>
              </div>

              <div className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  id="is_half_day"
                  checked={formData.is_half_day}
                  onChange={(e) => setFormData({...formData, is_half_day: e.target.checked})}
                />
                <Label htmlFor="is_half_day">Half Day Leave</Label>
              </div>

              <div>
                <Label htmlFor="reason">Reason</Label>
                <Textarea
                  id="reason"
                  value={formData.reason}
                  onChange={(e) => setFormData({...formData, reason: e.target.value})}
                  placeholder="Please provide a reason for the leave request"
                  required
                />
              </div>

              <div className="flex justify-end space-x-2 pt-4">
                <Button type="button" variant="outline" onClick={() => setIsFormOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" disabled={createLeaveRequestMutation.isPending}>
                  {createLeaveRequestMutation.isPending ? 'Submitting...' : 'Submit Request'}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Leave Requests List */}
      <Card>
        <CardHeader>
          <CardTitle>Leave Requests</CardTitle>
          <CardDescription>All employee leave requests</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {leaveRequests.map((request) => (
              <div key={request.id} className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex items-center space-x-4">
                  <div>
                    <p className="font-medium">
                      {request.hr_employees?.first_name || 'Unknown'} {request.hr_employees?.last_name || ''}
                    </p>
                    <p className="text-sm text-muted-foreground">
                      {request.hr_employees?.employee_code || 'N/A'}
                    </p>
                    <p className="text-sm text-muted-foreground">
                      {request.is_half_day ? 'Half Day' : `${request.total_days} day(s)`}
                    </p>
                  </div>
                  <div>
                    {getLeaveTypeBadge(request.leave_type)}
                  </div>
                </div>

                <div className="flex items-center space-x-4">
                  <div className="text-center">
                    <p className="text-sm font-medium">Duration</p>
                    <p className="text-sm text-muted-foreground">
                      {new Date(request.start_date).toLocaleDateString()} - {new Date(request.end_date).toLocaleDateString()}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      Applied: {new Date(request.applied_on || request.created_at).toLocaleDateString()}
                    </p>
                  </div>

                  <div className="text-center">
                    <p className="text-sm font-medium">Status</p>
                    {getStatusBadge(request.status)}
                  </div>

                  {request.status === 'pending' && (
                    <div className="flex space-x-2">
                      <Button
                        size="sm"
                        onClick={() => approveLeaveRequestMutation.mutate(request.id)}
                        disabled={approveLeaveRequestMutation.isPending}
                      >
                        <Check className="h-4 w-4" />
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => {
                          const reason = prompt('Please provide a reason for rejection:');
                          if (reason) {
                            rejectLeaveRequestMutation.mutate({ id: request.id, reason });
                          }
                        }}
                        disabled={rejectLeaveRequestMutation.isPending}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  )}
                </div>
              </div>
            ))}

            {leaveRequests.length === 0 && (
              <div className="text-center py-8">
                <p className="text-muted-foreground">No leave requests found</p>
                <p className="text-sm text-muted-foreground mt-2">
                  Submit your first leave request to get started
                </p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default LeaveManagement;
