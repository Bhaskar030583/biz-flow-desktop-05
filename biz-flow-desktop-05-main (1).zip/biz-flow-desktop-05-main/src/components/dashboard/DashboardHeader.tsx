
import React from "react";
import { useAuth } from '@/context/AuthContext';
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";

interface DashboardHeaderProps {
  title: string;
  subtitle?: string;
}

export const DashboardHeader: React.FC<DashboardHeaderProps> = ({ 
  title, 
  subtitle 
}) => {
  const { user, userRole } = useAuth();
  const userInitials = user?.email ? user.email.substring(0, 2).toUpperCase() : "US";

  const getRoleBadgeColor = (role: string) => {
    switch (role) {
      case 'admin':
        return 'bg-destructive/10 text-destructive dark:bg-destructive/20 dark:text-destructive';
      case 'lead':
        return 'bg-primary/10 text-primary dark:bg-primary/20 dark:text-primary';
      case 'sales':
        return 'bg-secondary/10 text-secondary dark:bg-secondary/20 dark:text-secondary';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };

  return (
    <div className="w-full mb-6">
      <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4 p-4 sm:p-6 bg-gradient-to-r from-card/90 to-primary/5 backdrop-blur-md rounded-xl border border-primary/10 shadow-lg">
        {/* Main Content Section */}
        <div className="flex items-start gap-3 sm:gap-4 flex-1 min-w-0">
          <img 
            src="/lovable-uploads/c1c145c9-7010-4fbf-9b2d-d46663dadb23.png" 
            alt="ABC Cafe Logo" 
            className="h-10 sm:h-12 lg:h-14 w-auto rounded-lg shadow-md flex-shrink-0"
          />
          <div className="min-w-0 flex-1">
            <h1 className="text-xl sm:text-2xl lg:text-3xl xl:text-4xl font-bold bg-gradient-to-r from-primary via-secondary to-primary bg-clip-text text-transparent mb-1 sm:mb-2 leading-tight break-words">
              {title}
            </h1>
            {subtitle && (
              <p className="text-xs sm:text-sm lg:text-base text-muted-foreground font-medium leading-relaxed break-words pr-2">
                {subtitle}
              </p>
            )}
          </div>
        </div>
        
        {/* User Profile Section */}
        <div className="flex items-center justify-end gap-3 flex-shrink-0">
          <div className="text-right hidden sm:block">
            <p className="text-xs sm:text-sm font-medium text-foreground truncate max-w-24 lg:max-w-32 xl:max-w-none">
              {user?.user_metadata?.full_name || user?.email?.split('@')[0] || 'User'}
            </p>
            <div className="flex items-center justify-end mt-1">
              <Badge 
                variant="secondary" 
                className={`text-xs font-medium px-2 py-0.5 ${getRoleBadgeColor(userRole)}`}
              >
                {userRole.charAt(0).toUpperCase() + userRole.slice(1)}
              </Badge>
            </div>
          </div>
          <Avatar className="h-8 sm:h-10 lg:h-12 w-8 sm:w-10 lg:w-12 border-2 border-primary/20 shadow-lg ring-2 ring-primary/10 flex-shrink-0">
            <AvatarImage src={user?.user_metadata?.avatar_url || ""} alt="User" />
            <AvatarFallback className="bg-gradient-to-br from-primary to-secondary text-primary-foreground font-bold text-xs sm:text-sm">
              {userInitials}
            </AvatarFallback>
          </Avatar>
        </div>
      </div>
    </div>
  );
};
