
import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { format } from "date-fns";

interface SalesDataPoint {
  date: string;
  sales: number;
  profit: number;
}

interface SalesChartDataProps {
  startDate: Date | null;
  endDate: Date | null;
  shopIds: string[];
  categoryId: string | null;
  productId: string | null;
}

export const useSalesChartData = ({ startDate, endDate, shopIds, categoryId, productId }: SalesChartDataProps) => {
  const [salesData, setSalesData] = useState<SalesDataPoint[]>([]);
  const [loading, setLoading] = useState(true);
  const [debugInfo, setDebugInfo] = useState<string>("");

  useEffect(() => {
    async function fetchSalesData() {
      try {
        setLoading(true);
        setDebugInfo("");
        
        console.log('🔍 [SalesChart] Fetching sales data with filters:', {
          startDate,
          endDate,
          shopIds,
          categoryId,
          productId
        });
        
        // First, let's check if we have any sales data at all
        const { data: totalSalesCount, error: countError } = await supabase
          .from("sales")
          .select("id", { count: 'exact' });
        
        if (countError) {
          console.error('❌ [SalesChart] Error counting sales:', countError);
          setDebugInfo(`Error counting sales: ${countError.message}`);
        } else {
          console.log('📊 [SalesChart] Total sales in database:', totalSalesCount?.length || 0);
          setDebugInfo(`Total sales in database: ${totalSalesCount?.length || 0}`);
        }
        
        // Build the query with simplified approach
        let query = supabase
          .from("sales")
          .select(`
            sale_date,
            quantity,
            price,
            products(id, name, cost_price, price, category)
          `)
          .order("sale_date");
        
        // Add filters
        if (startDate) {
          const formattedStartDate = format(startDate, "yyyy-MM-dd");
          query = query.gte("sale_date", formattedStartDate);
          console.log('📅 [SalesChart] Start date filter:', formattedStartDate);
        }
        if (endDate) {
          const formattedEndDate = format(endDate, "yyyy-MM-dd");
          query = query.lte("sale_date", formattedEndDate);
          console.log('📅 [SalesChart] End date filter:', formattedEndDate);
        }
        if (shopIds && shopIds.length > 0) {
          query = query.in("shop_id", shopIds);
          console.log('🏪 [SalesChart] Shop filter:', shopIds);
        }
        if (productId) {
          query = query.eq("product_id", productId);
          console.log('📦 [SalesChart] Product filter:', productId);
        }
        
        const { data, error } = await query;
        
        if (error) {
          console.error('❌ [SalesChart] Error fetching sales:', error);
          setDebugInfo(prev => prev + ` | Query error: ${error.message}`);
          setSalesData([]);
          return;
        }
        
        console.log('📊 [SalesChart] Raw sales data:', data?.length || 0, 'records');
        setDebugInfo(prev => prev + ` | Filtered results: ${data?.length || 0}`);
        
        if (!data || data.length === 0) {
          console.log('⚠️ [SalesChart] No sales data found');
          setSalesData([]);
          return;
        }
        
        // Process data
        const processedData: Record<string, SalesDataPoint> = {};
        
        data?.forEach((sale: any) => {
          if (!sale.products) {
            console.warn('⚠️ [SalesChart] Sale without product data:', sale);
            return;
          }
          
          // Apply category filter
          if (categoryId && sale.products.category !== categoryId) {
            return;
          }
          
          const date = sale.sale_date;
          
          if (!processedData[date]) {
            processedData[date] = {
              date,
              sales: 0,
              profit: 0
            };
          }
          
          const totalSale = Number(sale.price) * sale.quantity;
          // Use cost_price from products table, default to 0 if not available
          const costPrice = Number(sale.products.cost_price || 0) * sale.quantity;
          const profit = totalSale - costPrice;
          
          processedData[date].sales += totalSale;
          processedData[date].profit += profit;
          
          console.log(`📈 [SalesChart] Processing ${date}: sale=${totalSale}, profit=${profit}`);
        });
        
        // Convert to array and sort
        const sortedData = Object.values(processedData).sort((a, b) => 
          new Date(a.date).getTime() - new Date(b.date).getTime()
        );
        
        console.log('📊 [SalesChart] Final processed data:', sortedData.length, 'data points');
        setSalesData(sortedData);
      } catch (error: any) {
        console.error("❌ [SalesChart] Unexpected error:", error);
        setDebugInfo(prev => prev + ` | Unexpected error: ${error.message}`);
      } finally {
        setLoading(false);
      }
    }
    
    fetchSalesData();
  }, [startDate, endDate, shopIds, categoryId, productId]);

  return { salesData, loading, debugInfo };
};
