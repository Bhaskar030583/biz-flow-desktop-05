
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useSalesChartData } from "./SalesChartData";
import { SalesChartRenderer } from "./SalesChartRenderer";

interface SalesChartProps {
  startDate: Date | null;
  endDate: Date | null;
  shopIds: string[];
  categoryId: string | null;
  productId: string | null;
}

export function SalesChart({ startDate, endDate, shopIds, categoryId, productId }: SalesChartProps) {
  const { salesData, loading, debugInfo } = useSalesChartData({
    startDate,
    endDate,
    shopIds,
    categoryId,
    productId
  });

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Sales and Profit Analysis</CardTitle>
        </CardHeader>
        <CardContent className="h-80 flex items-center justify-center">
          <p>Loading sales data...</p>
        </CardContent>
      </Card>
    );
  }

  if (salesData.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Sales and Profit Analysis</CardTitle>
        </CardHeader>
        <CardContent className="h-80 flex flex-col items-center justify-center">
          <p className="text-muted-foreground mb-2">No sales data available for the selected filters.</p>
          <p className="text-xs text-muted-foreground">{debugInfo}</p>
          <div className="mt-4 text-xs text-muted-foreground">
            <p>This chart shows data from the "sales" table.</p>
            <p>Try adjusting your date range or removing filters to see data.</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Sales and Profit Analysis</CardTitle>
        <p className="text-xs text-muted-foreground">{debugInfo}</p>
      </CardHeader>
      <CardContent>
        <SalesChartRenderer salesData={salesData} />
      </CardContent>
    </Card>
  );
}
