
import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Banknote, Plus, Clock, Eye, Trash2, AlertCircle, CheckCircle, Calculator } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/context/AuthContext";
import { toast } from "sonner";
import { DayClosingModal } from "./DayClosingModal";
import { useDenominations } from "@/hooks/useDenominations";

interface HRStore {
  id: string;
  store_name: string;
  store_code: string;
}

interface Denominations {
  [key: string]: number;
}

export const DenominationManagement = () => {
  const { user } = useAuth();
  const [stores, setStores] = useState<HRStore[]>([]);
  const [selectedStoreId, setSelectedStoreId] = useState<string>("");
  const [terminalId, setTerminalId] = useState<string>("main");
  const [denominations, setDenominations] = useState<Denominations>({
    500: 0, 200: 0, 100: 0, 50: 0, 20: 0, 10: 0, 5: 0, 2: 0, 1: 0
  });
  const [showDayClosing, setShowDayClosing] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [existingRecord, setExistingRecord] = useState<any>(null);

  const denominationHook = useDenominations(selectedStoreId, terminalId);
  const { currentDenominations, fetchCurrentDenominations } = denominationHook;

  const denominationValues = [500, 200, 100, 50, 20, 10, 5, 2, 1];

  // Fetch stores
  useEffect(() => {
    const fetchStores = async () => {
      try {
        const { data, error } = await supabase
          .from('hr_stores')
          .select('id, store_name, store_code')
          .order('store_name');

        if (error) throw error;
        setStores(data || []);
      } catch (error) {
        console.error('Error fetching stores:', error);
        toast.error('Failed to load stores. Please try again.');
      }
    };

    if (user?.id) {
      fetchStores();
    }
  }, [user?.id]);

  // Check for existing denomination record
  const checkExistingRecord = async () => {
    if (!selectedStoreId || !user?.id) return;

    try {
      const today = new Date().toISOString().split('T')[0];
      const { data, error } = await supabase
        .from('store_denominations')
        .select('*')
        .eq('hr_shop_id', selectedStoreId)
        .eq('terminal_id', terminalId)
        .eq('date', today)
        .eq('user_id', user.id)
        .single();

      if (error && error.code !== 'PGRST116') {
        console.error('Error checking existing record:', error);
        return;
      }

      if (data) {
        setExistingRecord(data);
        const denominationsData = data.denominations as Denominations;
        setDenominations(denominationsData);
      } else {
        setExistingRecord(null);
        setDenominations({
          500: 0, 200: 0, 100: 0, 50: 0, 20: 0, 10: 0, 5: 0, 2: 0, 1: 0
        });
      }
    } catch (error) {
      console.error('Error in checkExistingRecord:', error);
      toast.error('Failed to load denomination data. Please refresh and try again.');
    }
  };

  useEffect(() => {
    checkExistingRecord();
  }, [selectedStoreId, terminalId, user?.id]);

  const handleDenominationChange = (value: number, count: string) => {
    const numCount = parseInt(count) || 0;
    setDenominations(prev => ({
      ...prev,
      [value]: numCount
    }));
  };

  const calculateTotal = () => {
    return denominationValues.reduce((total, value) => {
      return total + (value * (denominations[value] || 0));
    }, 0);
  };

  const handleSave = async () => {
    if (!selectedStoreId || !user?.id) {
      toast.error('Please select a store before saving');
      return;
    }

    const totalAmount = calculateTotal();
    if (totalAmount <= 0) {
      toast.error('Please enter at least one denomination count');
      return;
    }

    setIsLoading(true);
    try {
      const today = new Date().toISOString().split('T')[0];

      if (existingRecord) {
        const { data, error } = await supabase
          .from('store_denominations')
          .update({
            denominations,
            total_amount: totalAmount,
            updated_at: new Date().toISOString()
          })
          .eq('id', existingRecord.id)
          .select()
          .single();

        if (error) throw error;
        
        setExistingRecord(data);
        toast.success('Morning denominations updated successfully');
      } else {
        const { data, error } = await supabase
          .from('store_denominations')
          .insert({
            hr_shop_id: selectedStoreId,
            terminal_id: terminalId,
            date: today,
            denominations,
            total_amount: totalAmount,
            user_id: user.id
          })
          .select()
          .single();

        if (error) throw error;
        
        setExistingRecord(data);
        toast.success('Morning denominations saved successfully');
      }

      await fetchCurrentDenominations();
    } catch (error) {
      console.error('Error saving denominations:', error);
      toast.error('Failed to save denominations. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleDelete = async () => {
    if (!existingRecord) return;

    if (!confirm('Are you sure you want to delete this denomination record? This action cannot be undone.')) {
      return;
    }

    try {
      const { error } = await supabase
        .from('store_denominations')
        .delete()
        .eq('id', existingRecord.id);

      if (error) throw error;

      setExistingRecord(null);
      setDenominations({
        500: 0, 200: 0, 100: 0, 50: 0, 20: 0, 10: 0, 5: 0, 2: 0, 1: 0
      });
      toast.success('Denomination record deleted successfully');
      await fetchCurrentDenominations();
    } catch (error) {
      console.error('Error deleting denominations:', error);
      toast.error('Failed to delete denomination record. Please try again.');
    }
  };

  const selectedStore = stores.find(store => store.id === selectedStoreId);
  const totalAmount = calculateTotal();
  const hasUnsavedChanges = existingRecord && JSON.stringify(existingRecord.denominations) !== JSON.stringify(denominations);

  return (
    <Card className="w-full shadow-lg border-slate-200 bg-white">
      <CardHeader className="pb-4 bg-gradient-to-r from-emerald-50 to-blue-50 border-b border-slate-200">
        <CardTitle className="flex items-center gap-2 text-xl text-slate-800">
          <Banknote className="h-6 w-6 text-emerald-600" />
          Cash Denomination Management
        </CardTitle>
        <p className="text-sm text-slate-600 font-medium">
          Manage daily cash denominations and track denomination changes throughout the day
        </p>
      </CardHeader>
      
      <CardContent className="space-y-6 p-6">
        {/* Store and Terminal Selection */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-5 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg border border-blue-200 shadow-sm">
          <div className="space-y-2">
            <Label className="text-sm font-semibold text-slate-800">Store Selection *</Label>
            <Select value={selectedStoreId} onValueChange={setSelectedStoreId}>
              <SelectTrigger className="bg-white border-slate-300 text-slate-800 shadow-sm hover:border-blue-400 focus:border-blue-500">
                <SelectValue placeholder="Select your store" className="text-slate-600" />
              </SelectTrigger>
              <SelectContent className="bg-white border-slate-200 shadow-lg">
                {stores.map((store) => (
                  <SelectItem key={store.id} value={store.id} className="text-slate-800 hover:bg-blue-50">
                    <div className="flex flex-col">
                      <span className="font-medium text-slate-800">{store.store_name}</span>
                      <span className="text-xs text-slate-500">Code: {store.store_code}</span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label className="text-sm font-semibold text-slate-800">Terminal ID</Label>
            <Input
              value={terminalId}
              onChange={(e) => setTerminalId(e.target.value)}
              placeholder="Enter terminal ID"
              className="bg-white border-slate-300 text-slate-800 shadow-sm hover:border-blue-400 focus:border-blue-500"
            />
            <p className="text-xs text-slate-500 font-medium">Default: main</p>
          </div>
        </div>

        {!selectedStoreId && (
          <div className="flex items-center gap-2 p-4 bg-amber-50 border border-amber-300 rounded-lg shadow-sm">
            <AlertCircle className="h-5 w-5 text-amber-600" />
            <span className="text-sm text-amber-800 font-medium">Please select a store to continue</span>
          </div>
        )}

        {selectedStoreId && (
          <>
            {/* Current Available Denominations */}
            {Object.keys(currentDenominations).length > 0 && (
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <Eye className="h-5 w-5 text-blue-600" />
                  <Label className="text-sm font-semibold text-slate-800">Current Available Cash</Label>
                  <Badge variant="outline" className="text-blue-700 border-blue-300 bg-blue-50">Live Data</Badge>
                </div>
                <div className="grid grid-cols-3 md:grid-cols-5 lg:grid-cols-9 gap-2">
                  {denominationValues.map(value => {
                    const current = currentDenominations[value.toString()] || 0;
                    const morning = denominations[value] || 0;
                    const diff = current - morning;
                    
                    return (
                      <div key={value} className="text-center p-3 bg-gradient-to-b from-slate-50 to-slate-100 rounded-lg border border-slate-200 shadow-sm">
                        <div className="text-xs font-semibold text-slate-700">₹{value}</div>
                        <div className="text-lg font-bold text-slate-800">{current}</div>
                        {diff !== 0 && (
                          <div className={`text-xs font-medium ${diff > 0 ? 'text-emerald-600' : 'text-red-600'}`}>
                            {diff > 0 ? '+' : ''}{diff}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
                <p className="text-xs text-slate-600 font-medium">
                  Numbers show: Available count (Change from morning setup)
                </p>
              </div>
            )}

            <Separator className="bg-slate-200" />

            {/* Morning Denomination Setup */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-emerald-600" />
                  <Label className="text-lg font-semibold text-slate-800">
                    {existingRecord ? 'Update Morning Setup' : 'Morning Denomination Setup'}
                  </Label>
                </div>
                <div className="flex items-center gap-2">
                  {existingRecord && (
                    <Badge variant="secondary" className="flex items-center gap-1 bg-emerald-100 text-emerald-800 border-emerald-200">
                      <CheckCircle className="h-3 w-3" />
                      {new Date(existingRecord.date).toLocaleDateString()}
                    </Badge>
                  )}
                  {hasUnsavedChanges && (
                    <Badge variant="outline" className="text-amber-700 border-amber-400 bg-amber-50">
                      Unsaved Changes
                    </Badge>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-3 md:grid-cols-5 lg:grid-cols-9 gap-3">
                {denominationValues.map(value => (
                  <div key={value} className="space-y-2">
                    <Label htmlFor={`denom-${value}`} className="text-sm font-medium text-slate-700 text-center block">
                      ₹{value} Notes
                    </Label>
                    <Input
                      id={`denom-${value}`}
                      type="number"
                      min="0"
                      step="1"
                      value={denominations[value]}
                      onChange={(e) => handleDenominationChange(value, e.target.value)}
                      placeholder="0"
                      className="text-center font-medium border-slate-300 text-slate-800 hover:border-blue-400 focus:border-blue-500"
                    />
                    <div className="text-xs text-slate-600 text-center bg-slate-50 p-1 rounded border">
                      ₹{(value * (denominations[value] || 0)).toLocaleString()}
                    </div>
                  </div>
                ))}
              </div>

              <div className="flex items-center justify-between p-4 bg-gradient-to-r from-emerald-50 to-green-50 rounded-lg border border-emerald-200 shadow-sm">
                <div>
                  <Label className="text-sm font-medium text-emerald-800">Total Opening Amount</Label>
                  <div className="text-2xl font-bold text-emerald-700">
                    ₹{totalAmount.toLocaleString()}
                  </div>
                </div>
                {totalAmount > 0 && (
                  <div className="text-right">
                    <div className="text-xs text-emerald-700 font-medium">Total Notes</div>
                    <div className="text-sm font-semibold text-emerald-800">
                      {denominationValues.reduce((sum, value) => sum + (denominations[value] || 0), 0)}
                    </div>
                  </div>
                )}
              </div>

              <div className="flex gap-3">
                <Button 
                  onClick={handleSave} 
                  disabled={isLoading || totalAmount <= 0} 
                  className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white font-medium shadow-sm"
                >
                  <Plus className="h-4 w-4 mr-2" />
                  {isLoading ? "Saving..." : existingRecord ? "Update Setup" : "Save Setup"}
                </Button>
                
                {existingRecord && (
                  <Button 
                    variant="outline" 
                    onClick={handleDelete}
                    className="text-red-600 hover:text-red-700 hover:bg-red-50 border-red-300 font-medium"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                )}
              </div>
            </div>

            <Separator className="bg-slate-200" />

            {/* Day Closing Section */}
            <div className="space-y-4 p-5 bg-gradient-to-r from-orange-50 to-amber-50 rounded-lg border border-orange-200 shadow-sm">
              <div className="flex items-center gap-2">
                <Clock className="h-5 w-5 text-orange-600" />
                <Label className="text-lg font-semibold text-slate-800">End of Day Process</Label>
              </div>
              
              <p className="text-sm text-slate-700 font-medium">
                Complete your daily cash reconciliation and record final denomination counts
              </p>
              
              <Button 
                onClick={() => setShowDayClosing(true)}
                className="w-full bg-orange-600 hover:bg-orange-700 text-white font-medium shadow-sm"
                disabled={!existingRecord}
              >
                <Clock className="h-4 w-4 mr-2" />
                Start Day Closing Process
              </Button>
              
              {!existingRecord && (
                <div className="flex items-center gap-2 p-3 bg-amber-50 border border-amber-300 rounded shadow-sm">
                  <AlertCircle className="h-4 w-4 text-amber-600" />
                  <span className="text-sm text-amber-800 font-medium">
                    Complete morning denomination setup to enable day closing
                  </span>
                </div>
              )}
            </div>
          </>
        )}

        {/* Day Closing Modal */}
        {showDayClosing && selectedStore && (
          <DayClosingModal
            isOpen={showDayClosing}
            onClose={() => setShowDayClosing(false)}
            storeId={selectedStoreId}
            storeName={selectedStore.store_name}
            terminalId={terminalId}
          />
        )}
      </CardContent>
    </Card>
  );
};
