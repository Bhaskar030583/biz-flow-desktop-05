
import React from "react";
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, ResponsiveContainer, Tooltip, Legend } from "recharts";
import { IndianRupee } from "lucide-react";

interface SalesDataPoint {
  date: string;
  sales: number;
  profit: number;
}

interface SalesChartRendererProps {
  salesData: SalesDataPoint[];
}

export const SalesChartRenderer: React.FC<SalesChartRendererProps> = ({ salesData }) => {
  return (
    <div className="h-80">
      <ChartContainer
        config={{
          sales: {
            label: "Sales",
            color: "#4f46e5"
          },
          profit: {
            label: "Profit",
            color: "#22c55e"
          }
        }}
      >
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={salesData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="date" />
            <YAxis 
              tickFormatter={(value) => `₹${value}`}
            />
            <Tooltip
              content={({ active, payload }) => {
                if (active && payload && payload.length) {
                  return (
                    <ChartTooltipContent
                      className="border border-slate-200"
                      payload={payload}
                      formatter={(value, name) => (
                        <div className="flex items-center justify-between gap-2">
                          <span className="font-medium">{name}:</span>
                          <div className="flex items-center">
                            <IndianRupee className="h-3 w-3 mr-1" />
                            {Number(value).toFixed(2)}
                          </div>
                        </div>
                      )}
                    />
                  );
                }
                return null;
              }}
            />
            <Legend />
            <Bar dataKey="sales" name="Sales" fill="#4f46e5" />
            <Bar dataKey="profit" name="Profit" fill="#22c55e" />
          </BarChart>
        </ResponsiveContainer>
      </ChartContainer>
    </div>
  );
};
