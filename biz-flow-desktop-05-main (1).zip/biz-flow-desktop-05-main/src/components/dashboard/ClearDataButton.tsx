
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Trash2, AlertTriangle } from 'lucide-react';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/context/AuthContext';

const ClearDataButton = () => {
  const [isClearing, setIsClearing] = useState(false);
  const { toast } = useToast();
  const { user } = useAuth();

  const clearAllData = async () => {
    if (!user) {
      toast({
        title: "Error",
        description: "You must be logged in to clear data",
        variant: "destructive",
      });
      return;
    }

    setIsClearing(true);
    
    try {
      let totalDeleted = 0;

      // Clear data in dependency order (child tables first)
      const tablesToClear = [
        'bill_items',
        'bills', 
        'credit_transactions',
        'expenses',
        'stocks',
        'losses',
        'reorder_points',
        'low_stock_alerts',
        'stock_requests',
        'denomination_transactions',
        'store_denominations',
        'products',
        'customers',
        'hr_stores'
      ];

      for (const table of tablesToClear) {
        try {
          const { count, error } = await supabase
            .from(table as any)
            .delete()
            .eq('user_id', user.id);

          if (error) {
            console.error(`Error clearing ${table}:`, error);
            // Continue with other tables even if one fails
          } else {
            totalDeleted += count || 0;
          }
        } catch (tableError) {
          console.error(`Error with table ${table}:`, tableError);
          // Continue with other tables
        }
      }

      toast({
        title: "Data Cleared Successfully",
        description: `Cleared ${totalDeleted} records from the database`,
      });

      // Refresh the page to update all components
      window.location.reload();

    } catch (error) {
      console.error('Error clearing data:', error);
      toast({
        title: "Error",
        description: "Failed to clear some data. Check console for details.",
        variant: "destructive",
      });
    } finally {
      setIsClearing(false);
    }
  };

  // Only show in development (you can remove this condition later)
  const isDevelopment = process.env.NODE_ENV === 'development' || window.location.hostname === 'localhost';
  
  if (!isDevelopment) {
    return null;
  }

  return (
    <AlertDialog>
      <AlertDialogTrigger asChild>
        <Button 
          variant="destructive" 
          size="sm"
          className="flex items-center gap-2"
          disabled={isClearing}
        >
          <Trash2 className="h-4 w-4" />
          {isClearing ? 'Clearing...' : 'Clear Test Data'}
        </Button>
      </AlertDialogTrigger>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle className="flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-red-500" />
            Clear All Test Data
          </AlertDialogTitle>
          <AlertDialogDescription>
            This will permanently delete ALL data from the following tables:
            <ul className="list-disc list-inside mt-2 text-sm">
              <li>Bills and Bill Items</li>
              <li>Products and Stock Records</li>
              <li>Customers and Credit Transactions</li>
              <li>Expenses and Stores</li>
              <li>Stock Requests and Movements</li>
              <li>Denomination Records</li>
            </ul>
            <p className="mt-2 font-semibold text-red-600">
              This action cannot be undone. Only use this for testing purposes.
            </p>
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel>Cancel</AlertDialogCancel>
          <AlertDialogAction 
            onClick={clearAllData}
            className="bg-red-600 hover:bg-red-700"
            disabled={isClearing}
          >
            {isClearing ? 'Clearing...' : 'Yes, Clear All Data'}
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
};

export default ClearDataButton;
