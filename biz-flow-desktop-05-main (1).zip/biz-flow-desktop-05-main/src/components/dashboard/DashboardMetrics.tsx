
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { TrendingUp, TrendingDown, DollarSign, Package, ShoppingCart, CreditCard, Banknote, PiggyBank } from "lucide-react";
import { useSettings } from "@/context/SettingsContext";
import { formatCurrency } from "@/utils/formatters";

interface DashboardMetricsProps {
  totalRevenue: number;
  totalSales: number;
  totalProducts: number;
  averageSaleValue: number;
  creditGiven: number;
  creditReceived: number;
  creditBalance: number;
  grossProfit: number;
  netProfit: number;
  totalLoss: number;
  cashAmount: number;
  onlineAmount: number;
}

export function DashboardMetrics({
  totalRevenue,
  totalSales,
  totalProducts,
  averageSaleValue,
  creditGiven,
  creditReceived,
  creditBalance,
  grossProfit,
  netProfit,
  totalLoss,
  cashAmount,
  onlineAmount,
}: DashboardMetricsProps) {
  const { currency } = useSettings();

  const metrics = [
    {
      title: "Total Revenue",
      value: formatCurrency(totalRevenue, currency),
      icon: DollarSign,
      change: "+12.5%",
      changeType: "positive" as const,
      bgColor: "bg-gradient-to-br from-primary/10 to-primary/5",
      iconColor: "text-primary",
    },
    {
      title: "Total Sales",
      value: totalSales.toString(),
      icon: ShoppingCart,
      change: "+8.2%",
      changeType: "positive" as const,
      bgColor: "bg-gradient-to-br from-secondary/10 to-secondary/5",
      iconColor: "text-secondary",
    },
    {
      title: "Products",
      value: totalProducts.toString(),
      icon: Package,
      change: "+3.1%",
      changeType: "positive" as const,
      bgColor: "bg-gradient-to-br from-accent/20 to-accent/10",
      iconColor: "text-accent-foreground",
    },
    {
      title: "Avg Sale Value",
      value: formatCurrency(averageSaleValue, currency),
      icon: TrendingUp,
      change: "+5.4%",
      changeType: "positive" as const,
      bgColor: "bg-gradient-to-br from-primary/10 to-primary/5",
      iconColor: "text-primary",
    },
    {
      title: "Credit Given",
      value: formatCurrency(creditGiven, currency),
      icon: CreditCard,
      change: "-2.1%",
      changeType: "negative" as const,
      bgColor: "bg-gradient-to-br from-destructive/10 to-destructive/5",
      iconColor: "text-destructive",
    },
    {
      title: "Credit Received",
      value: formatCurrency(creditReceived, currency),
      icon: Banknote,
      change: "+7.8%",
      changeType: "positive" as const,
      bgColor: "bg-gradient-to-br from-secondary/10 to-secondary/5",
      iconColor: "text-secondary",
    },
    {
      title: "Credit Balance",
      value: formatCurrency(creditBalance, currency),
      icon: PiggyBank,
      change: creditBalance > 0 ? "+4.2%" : "-1.5%",
      changeType: creditBalance > 0 ? "positive" as const : "negative" as const,
      bgColor: "bg-gradient-to-br from-accent/20 to-accent/10",
      iconColor: "text-accent-foreground",
    },
    {
      title: "Net Profit",
      value: formatCurrency(netProfit, currency),
      icon: netProfit >= 0 ? TrendingUp : TrendingDown,
      change: netProfit >= 0 ? "+15.3%" : "-3.2%",
      changeType: netProfit >= 0 ? "positive" as const : "negative" as const,
      bgColor: netProfit >= 0 ? "bg-gradient-to-br from-secondary/10 to-secondary/5" : "bg-gradient-to-br from-destructive/10 to-destructive/5",
      iconColor: netProfit >= 0 ? "text-secondary" : "text-destructive",
    },
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
      {metrics.map((metric, index) => {
        const Icon = metric.icon;
        return (
          <Card key={index} className={`${metric.bgColor} border-border hover:shadow-lg transition-all duration-200 bg-card`}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-card-foreground">
                {metric.title}
              </CardTitle>
              <Icon className={`h-4 w-4 ${metric.iconColor}`} />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-card-foreground">{metric.value}</div>
              <p className={`text-xs ${
                metric.changeType === "positive" 
                  ? "text-secondary" 
                  : "text-destructive"
              }`}>
                {metric.change} from last month
              </p>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}
