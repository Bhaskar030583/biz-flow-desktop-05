
import React, { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { Calculator, Clock, TrendingUp, TrendingDown } from "lucide-react";
import { useDenominations } from "@/hooks/useDenominations";
import { toast } from "sonner";

interface DayClosingModalProps {
  isOpen: boolean;
  onClose: () => void;
  storeId: string;
  storeName: string;
  terminalId?: string;
}

interface Denominations {
  [key: string]: number;
}

export const DayClosingModal: React.FC<DayClosingModalProps> = ({
  isOpen,
  onClose,
  storeId,
  storeName,
  terminalId = 'main'
}) => {
  const [closingDenominations, setClosingDenominations] = useState<Denominations>({
    500: 0, 200: 0, 100: 0, 50: 0, 20: 0, 10: 0, 5: 0, 2: 0, 1: 0
  });
  const [totalCashSales, setTotalCashSales] = useState<string>("");
  const [totalChangeGiven, setTotalChangeGiven] = useState<string>("");
  const [notes, setNotes] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);

  const { currentDenominations, closeDayDenominations, transactions } = useDenominations(storeId, terminalId);

  const denominationValues = [500, 200, 100, 50, 20, 10, 5, 2, 1];

  useEffect(() => {
    if (isOpen) {
      // Pre-fill with current system denominations
      setClosingDenominations(prev => ({
        ...prev,
        ...currentDenominations
      }));

      // Calculate totals from transactions
      const cashSales = transactions
        .filter(t => t.transaction_type === 'cash_received')
        .reduce((sum, t) => sum + t.amount_change, 0);

      const changeGiven = transactions
        .filter(t => t.transaction_type === 'change_given')
        .reduce((sum, t) => sum + Math.abs(t.amount_change), 0);

      setTotalCashSales(cashSales.toString());
      setTotalChangeGiven(changeGiven.toString());
    }
  }, [isOpen, currentDenominations, transactions]);

  const handleDenominationChange = (value: number, count: string) => {
    const numCount = parseInt(count) || 0;
    setClosingDenominations(prev => ({
      ...prev,
      [value]: numCount
    }));
  };

  const calculateTotalFromDenominations = () => {
    return denominationValues.reduce((total, value) => {
      return total + (value * (closingDenominations[value] || 0));
    }, 0);
  };

  const calculateExpectedTotal = () => {
    return denominationValues.reduce((total, value) => {
      return total + (value * (currentDenominations[value] || 0));
    }, 0);
  };

  const getVariance = () => {
    return calculateTotalFromDenominations() - calculateExpectedTotal();
  };

  const handleSubmit = async () => {
    setIsProcessing(true);
    
    try {
      const success = await closeDayDenominations(
        closingDenominations,
        parseFloat(totalCashSales) || 0,
        parseFloat(totalChangeGiven) || 0,
        notes
      );

      if (success) {
        onClose();
        // Reset form
        setClosingDenominations({
          500: 0, 200: 0, 100: 0, 50: 0, 20: 0, 10: 0, 5: 0, 2: 0, 1: 0
        });
        setTotalCashSales("");
        setTotalChangeGiven("");
        setNotes("");
      }
    } catch (error) {
      console.error('Error closing day:', error);
      toast.error('Failed to close day');
    } finally {
      setIsProcessing(false);
    }
  };

  const expectedTotal = calculateExpectedTotal();
  const actualTotal = calculateTotalFromDenominations();
  const variance = getVariance();

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Clock className="h-5 w-5" />
            Day Closing - {storeName} ({terminalId})
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-blue-50 p-4 rounded-lg">
              <div className="text-sm text-blue-600 font-medium">Expected Total</div>
              <div className="text-2xl font-bold text-blue-800">₹{expectedTotal.toFixed(2)}</div>
            </div>
            <div className="bg-green-50 p-4 rounded-lg">
              <div className="text-sm text-green-600 font-medium">Actual Total</div>
              <div className="text-2xl font-bold text-green-800">₹{actualTotal.toFixed(2)}</div>
            </div>
            <div className={`p-4 rounded-lg ${variance >= 0 ? 'bg-green-50' : 'bg-red-50'}`}>
              <div className={`text-sm font-medium ${variance >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                <span className="flex items-center gap-1">
                  {variance >= 0 ? <TrendingUp className="h-4 w-4" /> : <TrendingDown className="h-4 w-4" />}
                  Variance
                </span>
              </div>
              <div className={`text-2xl font-bold ${variance >= 0 ? 'text-green-800' : 'text-red-800'}`}>
                ₹{Math.abs(variance).toFixed(2)}
              </div>
            </div>
          </div>

          <Separator />

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Denomination Counts */}
            <div className="space-y-4">
              <Label className="text-lg font-semibold">Actual Denomination Count</Label>
              <div className="grid grid-cols-3 gap-3">
                {denominationValues.map(value => (
                  <div key={value} className="space-y-1">
                    <Label htmlFor={`closing-${value}`} className="text-sm font-medium">
                      ₹{value} notes
                    </Label>
                    <Input
                      id={`closing-${value}`}
                      type="number"
                      min="0"
                      value={closingDenominations[value]}
                      onChange={(e) => handleDenominationChange(value, e.target.value)}
                      placeholder="0"
                      className="text-center"
                    />
                    <div className="text-xs text-gray-500 text-center">
                      = ₹{(value * (closingDenominations[value] || 0)).toFixed(0)}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Expected vs Actual Comparison */}
            <div className="space-y-4">
              <Label className="text-lg font-semibold">System vs Actual Comparison</Label>
              <div className="space-y-2">
                {denominationValues.map(value => {
                  const expected = currentDenominations[value] || 0;
                  const actual = closingDenominations[value] || 0;
                  const diff = actual - expected;
                  
                  return (
                    <div key={value} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                      <span className="font-medium">₹{value}</span>
                      <div className="flex items-center gap-4 text-sm">
                        <span>Expected: {expected}</span>
                        <span>Actual: {actual}</span>
                        <span className={`font-medium ${diff === 0 ? 'text-green-600' : diff > 0 ? 'text-blue-600' : 'text-red-600'}`}>
                          {diff > 0 ? '+' : ''}{diff}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Sales Summary */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="cash-sales">Total Cash Sales</Label>
              <Input
                id="cash-sales"
                type="number"
                step="0.01"
                value={totalCashSales}
                onChange={(e) => setTotalCashSales(e.target.value)}
                placeholder="0.00"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="change-given">Total Change Given</Label>
              <Input
                id="change-given"
                type="number"
                step="0.01"
                value={totalChangeGiven}
                onChange={(e) => setTotalChangeGiven(e.target.value)}
                placeholder="0.00"
              />
            </div>
          </div>

          {/* Notes */}
          <div className="space-y-2">
            <Label htmlFor="notes">Notes (Optional)</Label>
            <Textarea
              id="notes"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Any discrepancies or notes about the day..."
              rows={3}
            />
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3 pt-4">
            <Button variant="outline" onClick={onClose} className="flex-1">
              Cancel
            </Button>
            <Button
              onClick={handleSubmit}
              disabled={isProcessing}
              className="flex-1 bg-blue-600 hover:bg-blue-700"
            >
              <Calculator className="h-4 w-4 mr-2" />
              {isProcessing ? "Processing..." : "Close Day"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};
