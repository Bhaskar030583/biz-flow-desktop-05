
export class TextToSpeechService {
  private synth: SpeechSynthesis;
  private isEnabled: boolean = true;

  constructor() {
    this.synth = window.speechSynthesis;
  }

  setEnabled(enabled: boolean) {
    this.isEnabled = enabled;
  }

  speak(text: string, options?: { voice?: string; rate?: number; pitch?: number; volume?: number }) {
    if (!this.isEnabled) return;

    // Cancel any ongoing speech
    this.synth.cancel();

    const utterance = new SpeechSynthesisUtterance(text);
    
    // Set voice options
    utterance.rate = options?.rate || 1;
    utterance.pitch = options?.pitch || 1;
    utterance.volume = options?.volume || 0.8;

    // Try to set a specific voice if available
    const voices = this.synth.getVoices();
    if (options?.voice && voices.length > 0) {
      const selectedVoice = voices.find(voice => 
        voice.name.toLowerCase().includes(options.voice!.toLowerCase())
      );
      if (selectedVoice) {
        utterance.voice = selectedVoice;
      }
    }

    this.synth.speak(utterance);
  }

  // Specific methods for sales and expense alerts
  announceSale(amount: number, customerName?: string) {
    const message = customerName 
      ? `New sale recorded for ${customerName}. Amount: ${amount} rupees.`
      : `New sale recorded. Amount: ${amount} rupees.`;
    
    this.speak(message, { rate: 0.9, pitch: 1.1 });
  }

  announceExpense(amount: number, category: string, description?: string) {
    const message = description
      ? `New expense added. Category: ${category}. Amount: ${amount} rupees. ${description}.`
      : `New expense added. Category: ${category}. Amount: ${amount} rupees.`;
    
    this.speak(message, { rate: 0.9, pitch: 0.9 });
  }

  announceError(message: string) {
    this.speak(`Alert: ${message}`, { rate: 0.8, pitch: 0.8 });
  }

  stop() {
    this.synth.cancel();
  }
}

// Singleton instance
export const ttsService = new TextToSpeechService();
