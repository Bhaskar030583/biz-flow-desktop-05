
import { ThemeProvider } from "@/components/ThemeProvider"
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "sonner";
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import Dashboard from "./pages/Dashboard";
import Products from "./pages/Products";
import Recipes from "./pages/Recipes";
import Stocks from "./pages/Stocks";
import POS from "./pages/POS";
import Bills from "./pages/Bills";
import Customers from "./pages/Customers";
import Credits from "./pages/Credits";
import Expenses from "./pages/Expenses";
import Shops from "./pages/Shops";
import StockMovements from "./pages/StockMovements";
import Reports from "./pages/Reports";
import HRMS from "./pages/HRMS";
import AutoDebit from "./pages/AutoDebit";
import Users from "./pages/Users";
import Settings from "./pages/Settings";
import Auth from "./pages/Auth";
import DashboardLayout from "./components/DashboardLayout";
import PrivateRoute from "./components/PrivateRoute";
import EmployeeAuth from "@/pages/EmployeeAuth";
import EmployeeDashboardPage from "@/pages/EmployeeDashboardPage";
import { AuthProvider } from "./context/AuthContext";
import { EmployeeAuthProvider } from "@/context/EmployeeAuthContext";
import { SettingsProvider } from "@/context/SettingsContext";
import { DataSyncProvider } from "@/context/DataSyncContext";
import EmployeeProtectedRoute from "@/components/EmployeeProtectedRoute";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 5 * 60 * 1000, // 5 minutes
      retry: 1,
    },
  },
});

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider defaultTheme="system" storageKey="vite-ui-theme">
        <SettingsProvider>
          <DataSyncProvider>
            <BrowserRouter>
              <AuthProvider>
                <EmployeeAuthProvider>
                  <Routes>
                    <Route path="/auth" element={<Auth />} />
                    <Route path="/" element={<Auth />} />
                    
                    {/* Employee Authentication Routes */}
                    <Route path="/employee-auth" element={<EmployeeAuth />} />
                    <Route 
                      path="/employee-dashboard" 
                      element={
                        <EmployeeProtectedRoute>
                          <EmployeeDashboardPage />
                        </EmployeeProtectedRoute>
                      } 
                    />
                    
                    {/* Protected Dashboard Routes */}
                    <Route element={<PrivateRoute />}>
                      <Route element={<DashboardLayout />}>
                        <Route path="/dashboard" element={<Dashboard />} />
                        <Route path="/products" element={<Products />} />
                        <Route path="/recipes" element={<Recipes />} />
                        <Route path="/stocks" element={<Stocks />} />
                        <Route path="/pos" element={<POS />} />
                        <Route path="/bills" element={<Bills />} />
                        <Route path="/customers" element={<Customers />} />
                        <Route path="/credits" element={<Credits />} />
                        <Route path="/expenses" element={<Expenses />} />
                        <Route path="/shops" element={<Shops />} />
                        <Route path="/stock-movements" element={<StockMovements />} />
                        <Route path="/reports" element={<Reports />} />
                        <Route path="/hrms/*" element={<HRMS />} />
                        <Route path="/auto-debit" element={<AutoDebit />} />
                        <Route path="/users" element={<Users />} />
                        <Route path="/settings" element={<Settings />} />
                      </Route>
                    </Route>
                  </Routes>
                </EmployeeAuthProvider>
              </AuthProvider>
            </BrowserRouter>
          </DataSyncProvider>
        </SettingsProvider>
        <Toaster />
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
