
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

interface PayrollCalculationData {
  employee_id: string;
  month: number;
  year: number;
}

export const usePayrollCalculations = (data: PayrollCalculationData) => {
  return useQuery({
    queryKey: ['payroll-calculations', data.employee_id, data.month, data.year],
    queryFn: async () => {
      if (!data.employee_id) return null;

      const startDate = new Date(data.year, data.month - 1, 1);
      const endDate = new Date(data.year, data.month, 0);

      // Fetch attendance records for the month
      const { data: attendanceRecords, error: attendanceError } = await supabase
        .from('hr_attendance')
        .select(`
          *,
          hr_shifts!shift_id (
            start_time,
            end_time,
            break_duration
          )
        `)
        .eq('employee_id', data.employee_id)
        .gte('attendance_date', startDate.toISOString().split('T')[0])
        .lte('attendance_date', endDate.toISOString().split('T')[0]);

      if (attendanceError) throw attendanceError;

      // Calculate totals
      let totalDaysWorked = 0;
      let totalRegularHours = 0;
      let totalOvertimeHours = 0;

      attendanceRecords?.forEach(record => {
        if (record.status === 'present' && record.check_in_time && record.check_out_time) {
          totalDaysWorked++;
          totalRegularHours += record.total_hours || 0;
          totalOvertimeHours += record.overtime_hours || 0;
        }
      });

      return {
        daysWorked: totalDaysWorked,
        regularHours: totalRegularHours,
        overtimeHours: totalOvertimeHours,
        totalHours: totalRegularHours + totalOvertimeHours,
        attendanceRecords: attendanceRecords || []
      };
    },
    enabled: !!data.employee_id,
  });
};
