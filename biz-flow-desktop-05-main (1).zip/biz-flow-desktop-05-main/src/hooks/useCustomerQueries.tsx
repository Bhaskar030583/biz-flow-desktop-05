
import { useSupabaseQuery } from "./useSupabaseQuery";

export interface Customer {
  id: string;
  name: string;
  email?: string;
  phone: string;
  address?: string;
  credit_limit?: number;
  created_at: string;
  updated_at: string;
  user_id: string;
}

export const useCustomers = (options?: {
  searchTerm?: string;
  enabled?: boolean;
  staleTime?: number;
}) => {
  const filters = [];
  
  if (options?.searchTerm) {
    filters.push({
      column: 'name',
      operator: 'ilike' as const,
      value: `%${options.searchTerm}%`
    });
  }

  return useSupabaseQuery<Customer>({
    queryKey: ['customers', options],
    table: 'customers',
    filters,
    orderBy: { column: 'name', ascending: true },
    enabled: options?.enabled,
    staleTime: options?.staleTime ?? 10 * 60 * 1000 // 10 minutes for customers
  });
};

export const useCustomer = (customerId: string, enabled = true) => {
  return useSupabaseQuery<Customer>({
    queryKey: ['customer', customerId],
    table: 'customers',
    filters: [
      { column: 'id', operator: 'eq' as const, value: customerId }
    ],
    single: true,
    enabled: enabled && !!customerId
  });
};
