
import { useState, useCallback } from 'react';
import { ModalState } from '@/types/shared';

export interface UseModalManagerReturn {
  modals: Record<string, ModalState>;
  openModal: (modalName: string, data?: any) => void;
  closeModal: (modalName: string) => void;
  toggleModal: (modalName: string, data?: any) => void;
  closeAllModals: () => void;
  isModalOpen: (modalName: string) => boolean;
  getModalData: (modalName: string) => any;
}

export const useModalManager = (initialModals: string[] = []): UseModalManagerReturn => {
  const [modals, setModals] = useState<Record<string, ModalState>>(() => {
    return initialModals.reduce((acc, modalName) => {
      acc[modalName] = { isOpen: false };
      return acc;
    }, {} as Record<string, ModalState>);
  });

  const openModal = useCallback((modalName: string, data?: any) => {
    setModals(prev => ({
      ...prev,
      [modalName]: { isOpen: true, data }
    }));
  }, []);

  const closeModal = useCallback((modalName: string) => {
    setModals(prev => ({
      ...prev,
      [modalName]: { isOpen: false, data: undefined }
    }));
  }, []);

  const toggleModal = useCallback((modalName: string, data?: any) => {
    setModals(prev => {
      const currentModal = prev[modalName];
      return {
        ...prev,
        [modalName]: {
          isOpen: !currentModal?.isOpen,
          data: !currentModal?.isOpen ? data : undefined
        }
      };
    });
  }, []);

  const closeAllModals = useCallback(() => {
    setModals(prev => {
      const updated = { ...prev };
      Object.keys(updated).forEach(key => {
        updated[key] = { isOpen: false, data: undefined };
      });
      return updated;
    });
  }, []);

  const isModalOpen = useCallback((modalName: string) => {
    return modals[modalName]?.isOpen ?? false;
  }, [modals]);

  const getModalData = useCallback((modalName: string) => {
    return modals[modalName]?.data;
  }, [modals]);

  return {
    modals,
    openModal,
    closeModal,
    toggleModal,
    closeAllModals,
    isModalOpen,
    getModalData
  };
};
