
import { useState, useEffect } from 'react';
import { ttsService } from '@/services/textToSpeechService';

interface VoiceAlertSettings {
  enabled: boolean;
  salesAlerts: boolean;
  expenseAlerts: boolean;
  volume: number;
  rate: number;
  pitch: number;
}

const DEFAULT_SETTINGS: VoiceAlertSettings = {
  enabled: true,
  salesAlerts: true,
  expenseAlerts: true,
  volume: 0.8,
  rate: 0.9,
  pitch: 1.0,
};

export const useVoiceAlerts = () => {
  const [settings, setSettings] = useState<VoiceAlertSettings>(() => {
    const saved = localStorage.getItem('voiceAlertSettings');
    return saved ? JSON.parse(saved) : DEFAULT_SETTINGS;
  });

  useEffect(() => {
    localStorage.setItem('voiceAlertSettings', JSON.stringify(settings));
    ttsService.setEnabled(settings.enabled);
  }, [settings]);

  const updateSettings = (newSettings: Partial<VoiceAlertSettings>) => {
    setSettings(prev => ({ ...prev, ...newSettings }));
  };

  const announceSale = (amount: number, customerName?: string) => {
    if (settings.enabled && settings.salesAlerts) {
      ttsService.announceSale(amount, customerName);
    }
  };

  const announceExpense = (amount: number, category: string, description?: string) => {
    if (settings.enabled && settings.expenseAlerts) {
      ttsService.announceExpense(amount, category, description);
    }
  };

  const testVoice = () => {
    ttsService.speak('Voice alerts are working correctly', {
      rate: settings.rate,
      pitch: settings.pitch,
      volume: settings.volume
    });
  };

  return {
    settings,
    updateSettings,
    announceSale,
    announceExpense,
    testVoice,
    stopSpeech: () => ttsService.stop(),
  };
};
