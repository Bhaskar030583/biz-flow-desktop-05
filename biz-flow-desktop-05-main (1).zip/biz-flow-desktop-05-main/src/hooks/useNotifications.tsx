
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface Notification {
  id: string;
  title: string;
  message: string;
  type: 'info' | 'success' | 'warning' | 'error';
  read: boolean;
  created_at: string;
  user_id: string;
}

export const useNotifications = (userId?: string) => {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);

  useEffect(() => {
    if (!userId) return;

    // Subscribe to leave request changes
    const leaveChannel = supabase
      .channel('leave-notifications')
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'hr_leave_requests'
        },
        (payload) => {
          if (payload.new.status !== payload.old.status) {
            const message = payload.new.status === 'approved' 
              ? 'Your leave request has been approved'
              : payload.new.status === 'rejected'
              ? 'Your leave request has been rejected'
              : 'Your leave request status has been updated';
            
            toast.success(message);
            
            // Add to notifications
            const notification: Notification = {
              id: crypto.randomUUID(),
              title: 'Leave Request Update',
              message,
              type: payload.new.status === 'approved' ? 'success' : 'warning',
              read: false,
              created_at: new Date().toISOString(),
              user_id: userId
            };
            
            setNotifications(prev => [notification, ...prev]);
            setUnreadCount(prev => prev + 1);
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(leaveChannel);
    };
  }, [userId]);

  const markAsRead = (notificationId: string) => {
    setNotifications(prev => 
      prev.map(notification => 
        notification.id === notificationId 
          ? { ...notification, read: true }
          : notification
      )
    );
    setUnreadCount(prev => Math.max(0, prev - 1));
  };

  const markAllAsRead = () => {
    setNotifications(prev => 
      prev.map(notification => ({ ...notification, read: true }))
    );
    setUnreadCount(0);
  };

  return {
    notifications,
    unreadCount,
    markAsRead,
    markAllAsRead
  };
};
