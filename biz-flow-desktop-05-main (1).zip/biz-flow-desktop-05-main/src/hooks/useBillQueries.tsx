
import { useSupabaseQuery } from "./useSupabaseQuery";

export interface Bill {
  id: string;
  bill_number: string;
  customer_id?: string;
  total_amount: number;
  payment_method: string;
  payment_status: string;
  bill_date: string;
  created_at: string;
  updated_at: string;
  user_id: string;
}

export const useBills = (options?: {
  startDate?: string;
  endDate?: string;
  customerId?: string;
  enabled?: boolean;
  staleTime?: number;
}) => {
  const filters = [];
  
  if (options?.startDate) {
    filters.push({
      column: 'bill_date',
      operator: 'gte' as const,
      value: options.startDate
    });
  }
  
  if (options?.endDate) {
    filters.push({
      column: 'bill_date',
      operator: 'lte' as const,
      value: options.endDate
    });
  }
  
  if (options?.customerId) {
    filters.push({
      column: 'customer_id',
      operator: 'eq' as const,
      value: options.customerId
    });
  }

  return useSupabaseQuery<Bill>({
    queryKey: ['bills', options],
    table: 'bills',
    filters,
    orderBy: { column: 'bill_date', ascending: false },
    enabled: options?.enabled,
    staleTime: options?.staleTime ?? 5 * 60 * 1000 // 5 minutes for bills
  });
};

export const useBill = (billId: string, enabled = true) => {
  return useSupabaseQuery<Bill>({
    queryKey: ['bill', billId],
    table: 'bills',
    filters: [
      { column: 'id', operator: 'eq' as const, value: billId }
    ],
    single: true,
    enabled: enabled && !!billId
  });
};
