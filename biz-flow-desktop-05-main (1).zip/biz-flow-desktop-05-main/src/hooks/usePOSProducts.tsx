
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/context/AuthContext";
import { useEffect } from "react";

interface Product {
  id: string;
  name: string;
  price: number;
  category: string;
  quantity?: number;
  expectedClosing?: number;
  actualStock?: number;
  openingStock?: number;
  stockAdded?: number;
  soldToday?: number;
}

interface Shop {
  id: string;
  name: string;
  store_code?: string;
}

export const usePOSProducts = (selectedStoreId: string) => {
  const { user } = useAuth();
  const queryClient = useQueryClient();

  // Fetch shops data - only use hr_stores
  const { data: shops, isLoading: shopsLoading, error: shopsError } = useQuery({
    queryKey: ['pos-shops'],
    queryFn: async (): Promise<Shop[]> => {
      if (!user?.id) {
        console.log('🔍 [POS] User not authenticated');
        return [];
      }

      console.log('🔍 [POS] Fetching shops for user:', user.id);

      // Only query hr_stores
      const { data: hrStores, error: hrStoresError } = await supabase
        .from('hr_stores')
        .select('id, store_name, store_code')
        .order('store_name');

      if (hrStoresError) {
        console.error('❌ [POS] Error fetching HR stores:', hrStoresError);
        throw hrStoresError;
      }

      console.log('📍 [POS] Found HR stores:', hrStores);
      return hrStores?.map(store => ({
        id: store.id,
        name: store.store_name,
        store_code: store.store_code
      })) || [];
    },
    enabled: !!user?.id,
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  const { data: products, isLoading: productsLoading, refetch: refetchProducts, error: productsError } = useQuery({
    queryKey: ['pos-products', selectedStoreId],
    queryFn: async (): Promise<Product[]> => {
      if (!selectedStoreId || !user?.id) {
        console.log('🔍 [POS] No store selected or user not authenticated');
        return [];
      }
      
      console.log('🔍 [POS] Fetching products for store:', selectedStoreId);
      console.log('🔍 [POS] User ID:', user.id);
      
      const today = new Date().toISOString().split('T')[0];
      const yesterday = new Date();
      yesterday.setDate(yesterday.getDate() - 1);
      const yesterdayStr = yesterday.toISOString().split('T')[0];
      
      console.log('🔍 [POS] Today date:', today);
      console.log('🔍 [POS] Yesterday date:', yesterdayStr);
      
      // Check if selectedStoreId is a UUID
      const isUUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(selectedStoreId);
      console.log('🔍 [POS] Store ID is UUID:', isUUID);
      
      let productShops;
      let productShopsError;
      
      if (isUUID) {
        // Query with UUID hr_shop_id
        console.log('🔍 [POS] Querying with UUID hr_shop_id:', selectedStoreId);
        const result = await supabase
          .from('product_shops')
          .select(`
            products (
              id,
              name,
              price,
              category
            ),
            hr_shop_id,
            shop_id
          `)
          .eq('hr_shop_id', selectedStoreId)
          .eq('user_id', user.id);
        
        productShops = result.data;
        productShopsError = result.error;
      } else {
        // For string identifiers, try to find in hr_stores first
        console.log('🔍 [POS] Querying with string identifier:', selectedStoreId);
        
        const { data: hrStores, error: hrStoresError } = await supabase
          .from('hr_stores')
          .select('id, store_name, store_code')
          .or(`store_name.ilike.%${selectedStoreId}%,store_code.ilike.%${selectedStoreId}%`);
        
        if (!hrStoresError && hrStores && hrStores.length > 0) {
          const storeId = hrStores[0].id;
          console.log('🔍 [POS] Found HR store:', storeId);
          
          const result = await supabase
            .from('product_shops')
            .select(`
              products (
                id,
                name,
                price,
                category
              ),
              hr_shop_id,
              shop_id
            `)
            .eq('hr_shop_id', storeId)
            .eq('user_id', user.id);
          
          productShops = result.data;
          productShopsError = result.error;
        } else {
          console.log('🔍 [POS] No HR store found for identifier');
          productShops = [];
          productShopsError = null;
        }
      }
      
      if (productShopsError) {
        console.error('❌ [POS] Error fetching product_shops:', productShopsError);
        throw productShopsError;
      }

      console.log('📦 [POS] Product shops result:', productShops);

      const allProducts = productShops
        ?.map(item => item.products)
        .filter(product => product !== null) || [];

      console.log('📦 [POS] Products to process:', allProducts);

      if (allProducts.length === 0) {
        console.log('⚠️ [POS] No products assigned to this store');
        return [];
      }

      // Get product IDs
      const productIds = allProducts.map(product => product.id);
      console.log('🔍 [POS] Product IDs to lookup stock for:', productIds);

      // For stock data, use the actual store ID (UUID if available)
      let actualStoreId = selectedStoreId;
      if (!isUUID) {
        // Try to get the actual UUID from hr_stores
        const { data: hrStores } = await supabase
          .from('hr_stores')
          .select('id')
          .or(`store_name.ilike.%${selectedStoreId}%,store_code.ilike.%${selectedStoreId}%`)
          .limit(1);
        
        if (hrStores && hrStores.length > 0) {
          actualStoreId = hrStores[0].id;
        }
      }

      console.log('🔍 [POS] Using actualStoreId for stock lookup:', actualStoreId);

      // Get today's stock data - try both hr_shop_id and shop_id
      const { data: todayStockData, error: stockError } = await supabase
        .from('stocks')
        .select('product_id, opening_stock, stock_added, actual_stock, hr_shop_id, shop_id')
        .or(`hr_shop_id.eq.${actualStoreId},shop_id.eq.${actualStoreId}`)
        .eq('user_id', user.id)
        .eq('stock_date', today)
        .in('product_id', productIds);

      console.log('📊 [POS] Today stock query result:', { 
        data: todayStockData, 
        error: stockError,
        actualStoreId,
        today,
        productIds 
      });

      // Get yesterday's stock data for opening stock calculation
      const { data: yesterdayStockData } = await supabase
        .from('stocks')
        .select('product_id, actual_stock, closing_stock')
        .or(`hr_shop_id.eq.${actualStoreId},shop_id.eq.${actualStoreId}`)
        .eq('user_id', user.id)
        .eq('stock_date', yesterdayStr)
        .in('product_id', productIds);

      console.log('📊 [POS] Yesterday stock data:', yesterdayStockData);

      // Get today's sales data to calculate sold quantity
      const { data: salesData, error: salesError } = await supabase
        .from('bill_items')
        .select(`
          product_id,
          quantity,
          bills!inner(bill_date, user_id)
        `)
        .eq('bills.user_id', user.id)
        .gte('bills.bill_date', today)
        .lt('bills.bill_date', new Date(new Date(today).getTime() + 24 * 60 * 60 * 1000).toISOString().split('T')[0])
        .in('product_id', productIds);

      if (salesError) {
        console.error('❌ [POS] Error fetching sales data:', salesError);
      }

      console.log('💰 [POS] Sales data for today:', salesData);

      // Create maps for quick lookup
      const todayStockMap = new Map();
      todayStockData?.forEach(stock => {
        todayStockMap.set(stock.product_id, {
          opening: stock.opening_stock || 0,
          added: stock.stock_added || 0,
          actual: stock.actual_stock
        });
      });

      const yesterdayStockMap = new Map();
      yesterdayStockData?.forEach(stock => {
        yesterdayStockMap.set(stock.product_id, {
          actual: stock.actual_stock,
          closing: stock.closing_stock
        });
      });

      // Calculate total sales for each product today
      const salesMap = new Map();
      salesData?.forEach(sale => {
        const currentSales = salesMap.get(sale.product_id) || 0;
        salesMap.set(sale.product_id, currentSales + sale.quantity);
      });

      // Combine product data with stock information for POS
      const productsWithStock = allProducts.map(product => {
        const todayStock = todayStockMap.get(product.id);
        const yesterdayStock = yesterdayStockMap.get(product.id);
        const soldToday = salesMap.get(product.id) || 0;
        
        console.log(`🔍 [POS] Raw data for ${product.name}:`, {
          productId: product.id,
          todayStock,
          yesterdayStock,
          soldToday
        });
        
        // Calculate based on requirements
        const openingStock = (yesterdayStock?.actual ?? todayStock?.opening) || 0;
        const stockAdded = todayStock?.added || 0;
        
        // Expected closing = Opening Stock + Stock Added - Sold
        const expectedClosing = Math.max(0, openingStock + stockAdded - soldToday);
        
        // For POS quantity, use Expected Closing
        const posQuantity = expectedClosing;
        
        console.log(`📊 [POS] Final calculation for ${product.name}:`, {
          openingStock,
          stockAdded,
          soldToday,
          expectedClosing,
          actualStock: todayStock?.actual,
          posQuantity,
          note: 'POS quantity now uses Expected Closing'
        });

        return {
          id: product.id,
          name: product.name,
          price: product.price,
          category: product.category,
          quantity: posQuantity, // This is what POS uses - now from Expected Closing
          expectedClosing: expectedClosing,
          actualStock: todayStock?.actual ?? 0,
          openingStock: openingStock,
          stockAdded: stockAdded,
          soldToday: soldToday
        };
      });

      console.log('✅ [POS] Final products with expected closing quantities:', productsWithStock);
      return productsWithStock;
    },
    enabled: !!selectedStoreId && !!user?.id,
    refetchInterval: 30000, // Refresh every 30 seconds
    staleTime: 10000, // Consider data stale after 10 seconds
    refetchOnWindowFocus: true,
    refetchOnMount: true
  });

  // Set up real-time listener for stock changes
  useEffect(() => {
    if (!selectedStoreId || !user?.id) return;

    console.log('📡 [POS] Setting up real-time stock listener for store:', selectedStoreId);
    
    const channel = supabase
      .channel('stock-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'stocks'
        },
        (payload) => {
          console.log('📡 [POS] Real-time stock change detected:', payload);
          queryClient.invalidateQueries({ queryKey: ['pos-products', selectedStoreId] });
          refetchProducts();
        }
      )
      .subscribe();

    const billChannel = supabase
      .channel('bill-changes')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'bills'
        },
        (payload) => {
          console.log('📡 [POS] Real-time sale detected:', payload);
          queryClient.invalidateQueries({ queryKey: ['pos-products', selectedStoreId] });
          refetchProducts();
        }
      )
      .subscribe();

    return () => {
      console.log('📡 [POS] Cleaning up real-time listeners');
      supabase.removeChannel(channel);
      supabase.removeChannel(billChannel);
    };
  }, [selectedStoreId, user?.id, queryClient, refetchProducts]);

  const handleStockAdded = () => {
    console.log('🔄 [POS] Stock updated, refreshing product data');
    queryClient.invalidateQueries({ queryKey: ['pos-products'] });
    queryClient.invalidateQueries({ queryKey: ['product-stock-management'] });
    queryClient.invalidateQueries({ queryKey: ['stocks'] });
    queryClient.invalidateQueries({ queryKey: ['assigned-products'] });
    
    refetchProducts();
  };

  // Combine loading states and errors
  const isLoading = productsLoading || shopsLoading;
  const error = productsError || shopsError;

  return {
    products,
    shops: shops || [],
    isLoading,
    error,
    productsLoading,
    refetchProducts,
    handleStockAdded
  };
};
