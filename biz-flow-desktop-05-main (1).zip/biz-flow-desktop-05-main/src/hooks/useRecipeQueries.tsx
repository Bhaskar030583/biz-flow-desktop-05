import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/context/AuthContext";
import { toast } from "sonner";
import { Ingredient, Recipe, RecipeIngredient, IngredientStock } from "@/types/recipe";

export const useIngredients = () => {
  const { user } = useAuth();

  return useQuery({
    queryKey: ['ingredients', user?.id],
    queryFn: async (): Promise<Ingredient[]> => {
      if (!user?.id) return [];

      const { data, error } = await supabase
        .from('ingredients')
        .select('*')
        .eq('user_id', user.id)
        .order('name');

      if (error) throw error;
      return data || [];
    },
    enabled: !!user?.id
  });
};

export const useRecipes = () => {
  const { user } = useAuth();

  return useQuery({
    queryKey: ['recipes', user?.id],
    queryFn: async (): Promise<Recipe[]> => {
      if (!user?.id) return [];

      const { data, error } = await supabase
        .from('recipes')
        .select(`
          *,
          products(id, name, price),
          recipe_ingredients(
            *,
            ingredients(*)
          )
        `)
        .eq('user_id', user.id)
        .order('recipe_name');

      if (error) throw error;
      return data || [];
    },
    enabled: !!user?.id
  });
};

export const useIngredientStock = (shopId: string) => {
  const { user } = useAuth();

  return useQuery({
    queryKey: ['ingredient-stock', shopId, user?.id],
    queryFn: async (): Promise<IngredientStock[]> => {
      if (!user?.id || !shopId) return [];

      const today = new Date().toISOString().split('T')[0];

      const { data, error } = await supabase
        .from('ingredient_stock')
        .select(`
          *,
          ingredients(*)
        `)
        .eq('user_id', user.id)
        .eq('hr_shop_id', shopId)
        .eq('stock_date', today)
        .order('created_at');

      if (error) throw error;
      return data || [];
    },
    enabled: !!user?.id && !!shopId
  });
};

export const useCreateIngredient = () => {
  const { user } = useAuth();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (ingredient: Omit<Ingredient, 'id' | 'user_id' | 'created_at' | 'updated_at'>) => {
      if (!user?.id) throw new Error('User not authenticated');

      const { data, error } = await supabase
        .from('ingredients')
        .insert({
          ...ingredient,
          user_id: user.id
        })
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['ingredients'] });
      toast.success('Ingredient created successfully');
    },
    onError: (error) => {
      toast.error(`Failed to create ingredient: ${error.message}`);
    }
  });
};

export const useCreateRecipe = () => {
  const { user } = useAuth();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (recipe: {
      product_id: string;
      recipe_name: string;
      description?: string;
      ingredients: { ingredient_id: string; quantity: number }[];
    }) => {
      if (!user?.id) throw new Error('User not authenticated');

      // Create recipe
      const { data: recipeData, error: recipeError } = await supabase
        .from('recipes')
        .insert({
          product_id: recipe.product_id,
          recipe_name: recipe.recipe_name,
          description: recipe.description,
          user_id: user.id
        })
        .select()
        .single();

      if (recipeError) throw recipeError;

      // Create recipe ingredients
      const ingredientInserts = recipe.ingredients.map(ingredient => ({
        recipe_id: recipeData.id,
        ingredient_id: ingredient.ingredient_id,
        quantity: ingredient.quantity,
        user_id: user.id
      }));

      const { error: ingredientsError } = await supabase
        .from('recipe_ingredients')
        .insert(ingredientInserts);

      if (ingredientsError) throw ingredientsError;

      // Calculate total cost from ingredients
      let totalCost = 0;
      for (const ingredient of recipe.ingredients) {
        const { data: ingredientData } = await supabase
          .from('ingredients')
          .select('cost_per_unit')
          .eq('id', ingredient.ingredient_id)
          .single();
        
        if (ingredientData) {
          totalCost += ingredientData.cost_per_unit * ingredient.quantity;
        }
      }

      // Update product cost_price with calculated value
      const { error: updateError } = await supabase
        .from('products')
        .update({ cost_price: totalCost })
        .eq('id', recipe.product_id)
        .eq('user_id', user.id);

      if (updateError) throw updateError;

      return recipeData;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['recipes'] });
      queryClient.invalidateQueries({ queryKey: ['products'] });
      toast.success('Recipe created and product cost updated');
    },
    onError: (error) => {
      toast.error(`Failed to create recipe: ${error.message}`);
    }
  });
};

export const useUpdateRecipe = () => {
  const { user } = useAuth();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (recipe: {
      id: string;
      product_id: string;
      recipe_name: string;
      description?: string;
      ingredients: { ingredient_id: string; quantity: number }[];
    }) => {
      if (!user?.id) throw new Error('User not authenticated');

      // Update recipe
      const { error: recipeError } = await supabase
        .from('recipes')
        .update({
          recipe_name: recipe.recipe_name,
          description: recipe.description
        })
        .eq('id', recipe.id)
        .eq('user_id', user.id);

      if (recipeError) throw recipeError;

      // Delete existing recipe ingredients
      const { error: deleteError } = await supabase
        .from('recipe_ingredients')
        .delete()
        .eq('recipe_id', recipe.id)
        .eq('user_id', user.id);

      if (deleteError) throw deleteError;

      // Insert updated recipe ingredients
      const ingredientInserts = recipe.ingredients.map(ingredient => ({
        recipe_id: recipe.id,
        ingredient_id: ingredient.ingredient_id,
        quantity: ingredient.quantity,
        user_id: user.id
      }));

      const { error: ingredientsError } = await supabase
        .from('recipe_ingredients')
        .insert(ingredientInserts);

      if (ingredientsError) throw ingredientsError;

      // Recalculate total cost from ingredients
      let totalCost = 0;
      for (const ingredient of recipe.ingredients) {
        const { data: ingredientData } = await supabase
          .from('ingredients')
          .select('cost_per_unit')
          .eq('id', ingredient.ingredient_id)
          .single();
        
        if (ingredientData) {
          totalCost += ingredientData.cost_per_unit * ingredient.quantity;
        }
      }

      // Update product cost_price with calculated value
      const { error: updateError } = await supabase
        .from('products')
        .update({ cost_price: totalCost })
        .eq('id', recipe.product_id)
        .eq('user_id', user.id);

      if (updateError) throw updateError;

      return recipe;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['recipes'] });
      queryClient.invalidateQueries({ queryKey: ['products'] });
      toast.success('Recipe updated and product cost recalculated');
    },
    onError: (error) => {
      toast.error(`Failed to update recipe: ${error.message}`);
    }
  });
};

export const useUpdateIngredient = () => {
  const { user } = useAuth();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (ingredient: { id: string; name: string; unit: string; cost_per_unit: number }) => {
      if (!user?.id) throw new Error('User not authenticated');

      const { data, error } = await supabase
        .from('ingredients')
        .update({
          name: ingredient.name,
          unit: ingredient.unit,
          cost_per_unit: ingredient.cost_per_unit
        })
        .eq('id', ingredient.id)
        .eq('user_id', user.id)
        .select()
        .single();

      if (error) throw error;

      // Recalculate cost for all products that use this ingredient
      await recalculateProductCosts(ingredient.id, user.id);

      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['ingredients'] });
      queryClient.invalidateQueries({ queryKey: ['products'] });
      toast.success('Ingredient updated and product costs recalculated');
    },
    onError: (error) => {
      toast.error(`Failed to update ingredient: ${error.message}`);
    }
  });
};

const recalculateProductCosts = async (ingredientId: string, userId: string) => {
  // Get all recipes that use this ingredient
  const { data: recipeIngredients } = await supabase
    .from('recipe_ingredients')
    .select(`
      recipe_id,
      quantity,
      recipes(product_id)
    `)
    .eq('ingredient_id', ingredientId)
    .eq('user_id', userId);

  if (!recipeIngredients) return;

  // For each recipe, recalculate the total cost
  for (const ri of recipeIngredients) {
    if (ri.recipes) {
      const { data: allRecipeIngredients } = await supabase
        .from('recipe_ingredients')
        .select(`
          quantity,
          ingredients(cost_per_unit)
        `)
        .eq('recipe_id', ri.recipe_id)
        .eq('user_id', userId);

      if (allRecipeIngredients) {
        let totalCost = 0;
        for (const recipeIngredient of allRecipeIngredients) {
          if (recipeIngredient.ingredients) {
            totalCost += recipeIngredient.ingredients.cost_per_unit * recipeIngredient.quantity;
          }
        }

        // Update the product's cost_price
        await supabase
          .from('products')
          .update({ cost_price: totalCost })
          .eq('id', ri.recipes.product_id)
          .eq('user_id', userId);
      }
    }
  }
};

export const useDeleteIngredient = () => {
  const { user } = useAuth();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (ingredientId: string) => {
      if (!user?.id) throw new Error('User not authenticated');

      const { error } = await supabase
        .from('ingredients')
        .delete()
        .eq('id', ingredientId)
        .eq('user_id', user.id);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['ingredients'] });
      toast.success('Ingredient deleted successfully');
    },
    onError: (error) => {
      toast.error(`Failed to delete ingredient: ${error.message}`);
    }
  });
};

export const useUpdateIngredientStock = () => {
  const { user } = useAuth();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (stockUpdate: {
      ingredient_id: string;
      hr_shop_id: string;
      opening_stock?: number;
      stock_added?: number;
    }) => {
      if (!user?.id) throw new Error('User not authenticated');

      const today = new Date().toISOString().split('T')[0];

      const { data, error } = await supabase
        .from('ingredient_stock')
        .upsert({
          ingredient_id: stockUpdate.ingredient_id,
          hr_shop_id: stockUpdate.hr_shop_id,
          stock_date: today,
          opening_stock: stockUpdate.opening_stock || 0,
          stock_added: stockUpdate.stock_added || 0,
          actual_stock: (stockUpdate.opening_stock || 0) + (stockUpdate.stock_added || 0),
          user_id: user.id
        })
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['ingredient-stock'] });
      toast.success('Ingredient stock updated successfully');
    },
    onError: (error) => {
      toast.error(`Failed to update ingredient stock: ${error.message}`);
    }
  });
};

export const useConsumeRecipeIngredients = () => {
  const { user } = useAuth();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (consumption: {
      product_id: string;
      quantity: number;
      shop_id: string;
    }) => {
      if (!user?.id) throw new Error('User not authenticated');

      const { data, error } = await supabase.rpc('consume_recipe_ingredients', {
        p_product_id: consumption.product_id,
        p_quantity: consumption.quantity,
        p_shop_id: consumption.shop_id,
        p_user_id: user.id
      });

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['ingredient-stock'] });
      queryClient.invalidateQueries({ queryKey: ['pos-products'] });
    },
    onError: (error) => {
      console.error('Failed to consume recipe ingredients:', error);
    }
  });
};

export const useDeleteRecipe = () => {
  const { user } = useAuth();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (recipeId: string) => {
      if (!user?.id) throw new Error('User not authenticated');

      // First get the recipe to find the product_id
      const { data: recipe, error: fetchError } = await supabase
        .from('recipes')
        .select('product_id')
        .eq('id', recipeId)
        .eq('user_id', user.id)
        .single();

      if (fetchError) throw fetchError;

      // Delete the recipe (this will cascade delete recipe_ingredients)
      const { error: deleteError } = await supabase
        .from('recipes')
        .delete()
        .eq('id', recipeId)
        .eq('user_id', user.id);

      if (deleteError) throw deleteError;

      // Reset the product's cost_price to null (manual mode)
      if (recipe?.product_id) {
        const { error: updateError } = await supabase
          .from('products')
          .update({ cost_price: null })
          .eq('id', recipe.product_id)
          .eq('user_id', user.id);

        if (updateError) throw updateError;
      }

      return recipeId;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['recipes'] });
      queryClient.invalidateQueries({ queryKey: ['products'] });
      toast.success('Recipe deleted and product cost reset to manual mode');
    },
    onError: (error) => {
      toast.error(`Failed to delete recipe: ${error.message}`);
    }
  });
};
