
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

export const useAdvanceCalculations = (employeeId: string) => {
  return useQuery({
    queryKey: ['employee-advances', employeeId],
    queryFn: async () => {
      if (!employeeId) return [];

      const { data, error } = await supabase
        .from('hr_advances')
        .select('*')
        .eq('employee_id', employeeId)
        .eq('status', 'approved')
        .is('deducted_in_payslip', null);

      if (error) throw error;
      return data || [];
    },
    enabled: !!employeeId,
  });
};
