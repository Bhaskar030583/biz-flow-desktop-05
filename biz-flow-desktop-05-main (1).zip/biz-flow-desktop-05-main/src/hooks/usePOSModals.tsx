
import { useState } from "react";

export interface POSModalStates {
  showCashModal: boolean;
  showCreditModal: boolean;
  showSplitModal: boolean;
  showPendingModal: boolean;
  showQuickStockModal: boolean;
  showStoreInfoModal: boolean;
  showMobileCart: boolean;
}

export interface POSModalActions {
  openCashModal: () => void;
  closeCashModal: () => void;
  openCreditModal: () => void;
  closeCreditModal: () => void;
  openSplitModal: () => void;
  closeSplitModal: () => void;
  openPendingModal: () => void;
  closePendingModal: () => void;
  openQuickStockModal: () => void;
  closeQuickStockModal: () => void;
  openStoreInfoModal: () => void;
  closeStoreInfoModal: () => void;
  toggleMobileCart: () => void;
  closeAllPaymentModals: () => void;
  closeAllModals: () => void;
}

const initialModalStates: POSModalStates = {
  showCashModal: false,
  showCreditModal: false,
  showSplitModal: false,
  showPendingModal: false,
  showQuickStockModal: false,
  showStoreInfoModal: false,
  showMobileCart: false,
};

export const usePOSModals = () => {
  const [modalStates, setModalStates] = useState<POSModalStates>(initialModalStates);

  const actions: POSModalActions = {
    openCashModal: () => setModalStates(prev => ({ ...prev, showCashModal: true })),
    closeCashModal: () => setModalStates(prev => ({ ...prev, showCashModal: false })),
    
    openCreditModal: () => setModalStates(prev => ({ ...prev, showCreditModal: true })),
    closeCreditModal: () => setModalStates(prev => ({ ...prev, showCreditModal: false })),
    
    openSplitModal: () => setModalStates(prev => ({ ...prev, showSplitModal: true })),
    closeSplitModal: () => setModalStates(prev => ({ ...prev, showSplitModal: false })),
    
    openPendingModal: () => setModalStates(prev => ({ ...prev, showPendingModal: true })),
    closePendingModal: () => setModalStates(prev => ({ ...prev, showPendingModal: false })),
    
    openQuickStockModal: () => setModalStates(prev => ({ ...prev, showQuickStockModal: true })),
    closeQuickStockModal: () => setModalStates(prev => ({ ...prev, showQuickStockModal: false })),
    
    openStoreInfoModal: () => setModalStates(prev => ({ ...prev, showStoreInfoModal: true })),
    closeStoreInfoModal: () => setModalStates(prev => ({ ...prev, showStoreInfoModal: false })),
    
    toggleMobileCart: () => setModalStates(prev => ({ ...prev, showMobileCart: !prev.showMobileCart })),
    
    closeAllPaymentModals: () => setModalStates(prev => ({
      ...prev,
      showCashModal: false,
      showCreditModal: false,
      showSplitModal: false,
      showPendingModal: false,
    })),
    
    closeAllModals: () => setModalStates(initialModalStates),
  };

  return {
    modalStates,
    ...actions
  };
};
