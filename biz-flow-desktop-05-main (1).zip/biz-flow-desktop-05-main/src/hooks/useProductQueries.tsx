
import { useSupabaseQuery } from "./useSupabaseQuery";
import { useAuth } from "@/context/AuthContext";

export interface Product {
  id: string;
  name: string;
  price: number;
  cost_price?: number;
  category: string;
  quantity?: number;
  sku?: string;
  user_id: string;
  created_at: string;
  updated_at: string;
}

export const useProducts = (options?: {
  category?: string;
  enabled?: boolean;
  staleTime?: number;
}) => {
  const { user } = useAuth();

  const filters = [
    { column: 'user_id', operator: 'eq' as const, value: user?.id }
  ];

  if (options?.category) {
    filters.push({ 
      column: 'category', 
      operator: 'eq' as const, 
      value: options.category 
    });
  }

  return useSupabaseQuery<Product>({
    queryKey: ['products', user?.id, options?.category],
    table: 'products',
    filters,
    orderBy: { column: 'name', ascending: true },
    enabled: options?.enabled,
    staleTime: options?.staleTime
  });
};

export const useProduct = (productId: string, enabled = true) => {
  const { user } = useAuth();

  return useSupabaseQuery<Product>({
    queryKey: ['product', productId],
    table: 'products',
    filters: [
      { column: 'id', operator: 'eq' as const, value: productId },
      { column: 'user_id', operator: 'eq' as const, value: user?.id }
    ],
    single: true,
    enabled: enabled && !!productId && !!user?.id
  });
};

export const useProductsByIds = (productIds: string[], enabled = true) => {
  const { user } = useAuth();

  return useSupabaseQuery<Product>({
    queryKey: ['products-by-ids', productIds, user?.id],
    table: 'products',
    filters: [
      { column: 'id', operator: 'in' as const, value: productIds },
      { column: 'user_id', operator: 'eq' as const, value: user?.id }
    ],
    enabled: enabled && productIds.length > 0 && !!user?.id
  });
};
