
import { useState, useCallback } from 'react';

export interface LoadingStates {
  [key: string]: boolean;
}

export interface LoadingStatesActions {
  setLoading: (key: string, loading: boolean) => void;
  isLoading: (key: string) => boolean;
  hasAnyLoading: () => boolean;
  clearAll: () => void;
  withLoading: <T>(key: string, asyncFn: () => Promise<T>) => Promise<T>;
}

export interface LoadingStatesReturn extends LoadingStatesActions {
  loadingStates: LoadingStates;
}

export const useLoadingStates = (initialStates: LoadingStates = {}): LoadingStatesReturn => {
  const [loadingStates, setLoadingStates] = useState<LoadingStates>(initialStates);

  const setLoading = useCallback((key: string, loading: boolean) => {
    setLoadingStates(prev => ({
      ...prev,
      [key]: loading
    }));
  }, []);

  const isLoading = useCallback((key: string) => {
    return loadingStates[key] || false;
  }, [loadingStates]);

  const hasAnyLoading = useCallback(() => {
    return Object.values(loadingStates).some(loading => loading);
  }, [loadingStates]);

  const clearAll = useCallback(() => {
    setLoadingStates({});
  }, []);

  const withLoading = useCallback(async <T,>(key: string, asyncFn: () => Promise<T>): Promise<T> => {
    try {
      setLoading(key, true);
      return await asyncFn();
    } finally {
      setLoading(key, false);
    }
  }, [setLoading]);

  return {
    loadingStates,
    setLoading,
    isLoading,
    hasAnyLoading,
    clearAll,
    withLoading
  };
};
