
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { AttendanceRecord } from '@/types/hrms';

export const useRealtimeAttendance = () => {
  const [attendanceRecords, setAttendanceRecords] = useState<AttendanceRecord[]>([]);
  const [onlineEmployees, setOnlineEmployees] = useState<string[]>([]);

  useEffect(() => {
    // Subscribe to attendance changes
    const attendanceChannel = supabase
      .channel('attendance-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'hr_attendance'
        },
        (payload) => {
          console.log('Attendance change:', payload);
          if (payload.eventType === 'INSERT' || payload.eventType === 'UPDATE') {
            setAttendanceRecords(prev => {
              const existing = prev.find(record => record.id === payload.new.id);
              if (existing) {
                return prev.map(record => 
                  record.id === payload.new.id ? { ...record, ...payload.new } : record
                );
              } else {
                return [...prev, payload.new as AttendanceRecord];
              }
            });
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(attendanceChannel);
    };
  }, []);

  const trackOnlineStatus = (employeeId: string, isOnline: boolean) => {
    setOnlineEmployees(prev => {
      if (isOnline) {
        return prev.includes(employeeId) ? prev : [...prev, employeeId];
      } else {
        return prev.filter(id => id !== employeeId);
      }
    });
  };

  return {
    attendanceRecords,
    onlineEmployees,
    trackOnlineStatus
  };
};
