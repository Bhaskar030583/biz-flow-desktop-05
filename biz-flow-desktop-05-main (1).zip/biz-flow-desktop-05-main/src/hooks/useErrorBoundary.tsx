
import { useState, useCallback } from 'react';

export interface ErrorBoundaryState {
  hasError: boolean;
  error: Error | null;
  errorInfo: any;
}

export interface ErrorBoundaryActions {
  captureError: (error: Error, errorInfo?: any) => void;
  resetError: () => void;
  withErrorBoundary: <T>(fn: () => T) => T | null;
}

export const useErrorBoundary = (): ErrorBoundaryState & ErrorBoundaryActions => {
  const [errorState, setErrorState] = useState<ErrorBoundaryState>({
    hasError: false,
    error: null,
    errorInfo: null
  });

  const captureError = useCallback((error: Error, errorInfo?: any) => {
    console.error('Error captured by error boundary:', error, errorInfo);
    setErrorState({
      hasError: true,
      error,
      errorInfo
    });
  }, []);

  const resetError = useCallback(() => {
    setErrorState({
      hasError: false,
      error: null,
      errorInfo: null
    });
  }, []);

  const withErrorBoundary = useCallback(<T,>(fn: () => T): T | null => {
    try {
      return fn();
    } catch (error) {
      captureError(error instanceof Error ? error : new Error('Unknown error'));
      return null;
    }
  }, [captureError]);

  return {
    ...errorState,
    captureError,
    resetError,
    withErrorBoundary
  };
};
