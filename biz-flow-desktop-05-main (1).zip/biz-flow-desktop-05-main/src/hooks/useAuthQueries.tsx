
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/context/AuthContext";

export interface Profile {
  id: string;
  full_name?: string;
  avatar_url?: string;
  role: string;
  code?: string;
  page_access?: string[];
  created_at: string;
  updated_at: string;
}

export const useProfile = (userId?: string) => {
  const { user } = useAuth();
  const targetUserId = userId || user?.id;

  return useQuery({
    queryKey: ['profile', targetUserId],
    queryFn: async (): Promise<Profile | null> => {
      if (!targetUserId) return null;

      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', targetUserId)
        .single();

      if (error) throw error;
      return data;
    },
    enabled: !!targetUserId,
    staleTime: 10 * 60 * 1000 // 10 minutes
  });
};

export const useProfiles = (options?: {
  role?: string;
  enabled?: boolean;
}) => {
  return useQuery({
    queryKey: ['profiles', options?.role],
    queryFn: async (): Promise<Profile[]> => {
      let query = supabase
        .from('profiles')
        .select('*')
        .order('full_name');

      if (options?.role) {
        query = query.eq('role', options.role);
      }

      const { data, error } = await query;

      if (error) throw error;
      return data || [];
    },
    enabled: options?.enabled,
    staleTime: 15 * 60 * 1000 // 15 minutes
  });
};

export const useCurrentUserPermissions = () => {
  const { user } = useAuth();
  const { data: profile } = useProfile();

  return useQuery({
    queryKey: ['user-permissions', user?.id],
    queryFn: async () => {
      if (!profile) return { role: 'user', pageAccess: ['dashboard'] };

      return {
        role: profile.role || 'user',
        pageAccess: profile.page_access || ['dashboard']
      };
    },
    enabled: !!user?.id && !!profile,
    staleTime: 15 * 60 * 1000
  });
};
