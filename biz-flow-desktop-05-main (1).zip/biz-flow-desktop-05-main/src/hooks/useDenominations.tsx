
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/context/AuthContext';
import { toast } from 'sonner';

interface Denominations {
  [key: string]: number;
}

interface DenominationTransaction {
  id: string;
  hr_shop_id: string;
  user_id: string;
  terminal_id: string;
  transaction_type: string;
  transaction_date: string;
  transaction_time: string;
  denominations: Denominations;
  amount_change: number;
  reference_bill_id?: string;
  notes?: string;
}

interface DayClosing {
  id: string;
  hr_shop_id: string;
  closing_date: string;
  opening_denominations: Denominations;
  closing_denominations: Denominations;
  total_cash_sales: number;
  total_change_given: number;
  variance_amount: number;
  closed_by: string;
  closed_at: string;
  notes?: string;
}

export const useDenominations = (storeId?: string, terminalId: string = 'main') => {
  const { user } = useAuth();
  const [currentDenominations, setCurrentDenominations] = useState<Denominations>({});
  const [transactions, setTransactions] = useState<DenominationTransaction[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  // Fetch current denominations using the database function
  const fetchCurrentDenominations = async () => {
    if (!storeId || !user?.id) return;

    try {
      setIsLoading(true);
      const { data, error } = await supabase.rpc('get_current_denominations', {
        store_id: storeId,
        terminal_id_param: terminalId,
        date_param: new Date().toISOString().split('T')[0]
      });

      if (error) {
        console.error('Error fetching current denominations:', error);
        toast.error('Failed to fetch current denominations');
        return;
      }

      // Cast the returned Json to Denominations
      const denominationsData = data as Denominations || {};
      setCurrentDenominations(denominationsData);
    } catch (error) {
      console.error('Error in fetchCurrentDenominations:', error);
      toast.error('Failed to fetch current denominations');
    } finally {
      setIsLoading(false);
    }
  };

  // Record a denomination transaction
  const recordTransaction = async (
    transactionType: string,
    denominations: Denominations,
    amountChange: number,
    billId?: string,
    notes?: string
  ) => {
    if (!storeId || !user?.id) return false;

    try {
      const { error } = await supabase
        .from('denomination_transactions')
        .insert({
          hr_shop_id: storeId,
          user_id: user.id,
          terminal_id: terminalId,
          transaction_type: transactionType,
          denominations,
          amount_change: amountChange,
          reference_bill_id: billId,
          notes
        });

      if (error) {
        console.error('Error recording denomination transaction:', error);
        toast.error('Failed to record denomination transaction');
        return false;
      }

      // Refresh current denominations
      await fetchCurrentDenominations();
      return true;
    } catch (error) {
      console.error('Error in recordTransaction:', error);
      toast.error('Failed to record denomination transaction');
      return false;
    }
  };

  // Record cash received (when customer pays)
  const recordCashReceived = async (denominations: Denominations, billId?: string) => {
    const totalAmount = Object.entries(denominations).reduce((sum, [denom, count]) => {
      return sum + (parseInt(denom) * count);
    }, 0);

    return recordTransaction('cash_received', denominations, totalAmount, billId, 'Cash payment received');
  };

  // Record change given (when giving change to customer)
  const recordChangeGiven = async (denominations: Denominations, billId?: string) => {
    const totalAmount = Object.entries(denominations).reduce((sum, [denom, count]) => {
      return sum + (parseInt(denom) * count);
    }, 0);

    return recordTransaction('change_given', denominations, -totalAmount, billId, 'Change given to customer');
  };

  // Get optimal change breakdown
  const getOptimalChange = (changeAmount: number): Denominations => {
    const denominationValues = [500, 200, 100, 50, 20, 10, 5, 2, 1];
    const changeBreakdown: Denominations = {};
    let remainingAmount = Math.round(changeAmount);

    for (const value of denominationValues) {
      const availableCount = currentDenominations[value.toString()] || 0;
      if (remainingAmount >= value && availableCount > 0) {
        const neededCount = Math.floor(remainingAmount / value);
        const actualCount = Math.min(neededCount, availableCount);
        
        if (actualCount > 0) {
          changeBreakdown[value.toString()] = actualCount;
          remainingAmount -= value * actualCount;
        }
      }
    }

    return changeBreakdown;
  };

  // Check if we can give exact change
  const canGiveExactChange = (changeAmount: number): boolean => {
    const breakdown = getOptimalChange(changeAmount);
    const totalFromBreakdown = Object.entries(breakdown).reduce((sum, [denom, count]) => {
      return sum + (parseInt(denom) * count);
    }, 0);

    return totalFromBreakdown === Math.round(changeAmount);
  };

  // Close day with final denomination count
  const closeDayDenominations = async (
    closingDenominations: Denominations,
    totalCashSales: number,
    totalChangeGiven: number,
    notes?: string
  ) => {
    if (!storeId || !user?.id) return false;

    try {
      // Get morning denominations
      const { data: morningData } = await supabase
        .from('store_denominations')
        .select('denominations')
        .eq('hr_shop_id', storeId)
        .eq('terminal_id', terminalId)
        .eq('date', new Date().toISOString().split('T')[0])
        .eq('user_id', user.id)
        .single();

      const openingDenominations = (morningData?.denominations as Denominations) || {};

      // Calculate variance
      const expectedTotal = Object.entries(currentDenominations).reduce((sum, [denom, count]) => {
        return sum + (parseInt(denom) * count);
      }, 0);

      const actualTotal = Object.entries(closingDenominations).reduce((sum, [denom, count]) => {
        return sum + (parseInt(denom) * count);
      }, 0);

      const variance = actualTotal - expectedTotal;

      const { error } = await supabase
        .from('store_day_closing')
        .insert({
          hr_shop_id: storeId,
          user_id: user.id,
          opening_denominations: openingDenominations,
          closing_denominations: closingDenominations,
          total_cash_sales: totalCashSales,
          total_change_given: totalChangeGiven,
          variance_amount: variance,
          closed_by: user.id,
          notes
        });

      if (error) {
        console.error('Error closing day denominations:', error);
        toast.error('Failed to close day denominations');
        return false;
      }

      toast.success('Day closing recorded successfully');
      return true;
    } catch (error) {
      console.error('Error in closeDayDenominations:', error);
      toast.error('Failed to close day denominations');
      return false;
    }
  };

  // Fetch transactions for the day
  const fetchTransactions = async () => {
    if (!storeId || !user?.id) return;

    try {
      const { data, error } = await supabase
        .from('denomination_transactions')
        .select('*')
        .eq('hr_shop_id', storeId)
        .eq('terminal_id', terminalId)
        .eq('transaction_date', new Date().toISOString().split('T')[0])
        .order('transaction_time', { ascending: false });

      if (error) {
        console.error('Error fetching transactions:', error);
        return;
      }

      // Cast the transactions data to our interface
      const transactionsData = (data || []).map(tx => ({
        ...tx,
        denominations: tx.denominations as Denominations
      })) as DenominationTransaction[];

      setTransactions(transactionsData);
    } catch (error) {
      console.error('Error in fetchTransactions:', error);
    }
  };

  useEffect(() => {
    if (storeId && user?.id) {
      fetchCurrentDenominations();
      fetchTransactions();
    }
  }, [storeId, user?.id, terminalId]);

  return {
    currentDenominations,
    transactions,
    isLoading,
    recordCashReceived,
    recordChangeGiven,
    getOptimalChange,
    canGiveExactChange,
    closeDayDenominations,
    fetchCurrentDenominations,
    fetchTransactions
  };
};
