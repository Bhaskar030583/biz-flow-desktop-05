
import { useSupabaseQuery } from "./useSupabaseQuery";

export interface Store {
  id: string;
  store_name: string;
  store_code?: string;
  address: string;
  manager_id?: string;
  latitude?: number;
  longitude?: number;
  geo_fence_radius?: number;
  created_at: string;
  updated_at: string;
}

export const useHRStores = (options?: {
  enabled?: boolean;
  staleTime?: number;
}) => {
  return useSupabaseQuery<Store>({
    queryKey: ['hr-stores'],
    table: 'hr_stores',
    orderBy: { column: 'store_name', ascending: true },
    enabled: options?.enabled,
    staleTime: options?.staleTime ?? 15 * 60 * 1000 // 15 minutes for stores
  });
};

export const useHRStore = (storeId: string, enabled = true) => {
  return useSupabaseQuery<Store>({
    queryKey: ['hr-store', storeId],
    table: 'hr_stores',
    filters: [
      { column: 'id', operator: 'eq' as const, value: storeId }
    ],
    single: true,
    enabled: enabled && !!storeId
  });
};
