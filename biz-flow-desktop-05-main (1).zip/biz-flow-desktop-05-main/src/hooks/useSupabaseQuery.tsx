
import { useState, useEffect } from 'react';
import { useQuery, QueryKey } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

type FilterOperator = 'eq' | 'neq' | 'gt' | 'gte' | 'lt' | 'lte' | 'like' | 'ilike' | 'in' | 'contains' | 'containedBy';

export interface SupabaseFilter {
  column: string;
  operator: FilterOperator;
  value: any;
}

export interface UseSupabaseQueryConfig<T> {
  queryKey: QueryKey;
  table: string;
  select?: string;
  filters?: SupabaseFilter[];
  orderBy?: {
    column: string;
    ascending?: boolean;
  };
  limit?: number;
  single?: boolean;
  enabled?: boolean;
  staleTime?: number;
}

export const useSupabaseQuery = <T = any>({
  queryKey,
  table,
  select = '*',
  filters = [],
  orderBy,
  limit,
  single = false,
  enabled = true,
  staleTime = 5 * 60 * 1000 // 5 minutes
}: UseSupabaseQueryConfig<T>) => {
  const queryFn = async (): Promise<T | T[]> => {
    let query = supabase.from(table as any).select(select);

    // Apply filters
    filters.forEach(filter => {
      if (filter.operator === 'in') {
        query = query.in(filter.column, filter.value);
      } else if (filter.operator === 'contains') {
        query = query.contains(filter.column, filter.value);
      } else if (filter.operator === 'containedBy') {
        query = query.containedBy(filter.column, filter.value);
      } else {
        query = query.filter(filter.column, filter.operator, filter.value);
      }
    });

    // Apply ordering
    if (orderBy) {
      query = query.order(orderBy.column, { ascending: orderBy.ascending ?? true });
    }

    // Apply limit
    if (limit) {
      query = query.limit(limit);
    }

    // Execute query
    if (single) {
      const { data, error } = await query.maybeSingle();
      if (error) throw error;
      return data as T;
    } else {
      const { data, error } = await query;
      if (error) throw error;
      return data as T[];
    }
  };

  return useQuery({
    queryKey,
    queryFn,
    enabled,
    staleTime
  });
};
